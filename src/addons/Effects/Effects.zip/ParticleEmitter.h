
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#ifndef ParticleEmitter_h__
#define ParticleEmitter_h__

#include "FxPrerequisites.h"
#include "Particle.h"
#include "DynamicAttribute.h"
#include "DynamicAttributeFactory.h"

namespace Demi
{
	class DEMI_FX_API DiParticleEmitter
	{
	public:
		static const bool		DEFAULT_ENABLED;
		static const DiVec3		DEFAULT_POSITION;
		static const bool		DEFAULT_KEEP_LOCAL;
		static const DiVec3 	DEFAULT_DIRECTION;
		static const DiQuat 	DEFAULT_ORIENTATION;
		static const DiQuat 	DEFAULT_ORIENTATION_RANGE_START;
		static const DiQuat 	DEFAULT_ORIENTATION_RANGE_END;
		static const DiParticle::ParticleType DEFAULT_EMITS;
		static const uint16 	DEFAULT_START_TEXTURE_COORDS;
		static const uint16 	DEFAULT_END_TEXTURE_COORDS;
		static const uint16 	DEFAULT_TEXTURE_COORDS;
		static const DiColor 	DEFAULT_START_COLOUR_RANGE;
		static const DiColor 	DEFAULT_END_COLOUR_RANGE;
		static const DiColor 	DEFAULT_COLOUR;
		static const bool 		DEFAULT_AUTO_DIRECTION;
		static const bool 		DEFAULT_FORCE_EMISSION;
		static const float 		DEFAULT_EMISSION_RATE;
		static const float 		DEFAULT_TIME_TO_LIVE;
		static const float 		DEFAULT_MASS;
		static const float 		DEFAULT_VELOCITY;
		static const float 		DEFAULT_DURATION;
		static const float 		DEFAULT_REPEAT_DELAY;
		static const float 		DEFAULT_ANGLE;
		static const float 		DEFAULT_DIMENSIONS;
		static const float 		DEFAULT_WIDTH;
		static const float 		DEFAULT_HEIGHT;
		static const float 		DEFAULT_DEPTH;

	public:

		DiParticleEmitter(void);
		
		virtual						~DiParticleEmitter(void);

		inline DiParticleElement*	GetParentElement(void) const {return m_pkParentElement;};
		void						SetParentElement(DiParticleElement* parentTechnique);

		inline const DiString&		GetEmitterType(void) const {return m_kEmitterType;};
		void						SetEmitterType(const DiString& emitterType) {m_kEmitterType = emitterType;};

		inline const DiString&		GetName(void) const {return m_kName;};
		void						SetName(const DiString& name) {m_kName = name;};

		inline DiDynamicAttribute*	GetDynAngle(void) const {return m_pkDynAngle;};
		void						SetDynAngle(DiDynamicAttribute* dynAngle);

		inline DiDynamicAttribute*	GetDynEmissionRate(void) const {return m_pkDynEmissionRate;};
		void						SetDynEmissionRate(DiDynamicAttribute* dynEmissionRate);

		inline DiDynamicAttribute*	GetDynTotalTimeToLive(void) const {return m_pkDynTotalTimeToLive;};
		void						SetDynTotalTimeToLive(DiDynamicAttribute* dynTotalTimeToLive);

		inline DiDynamicAttribute*	GetDynParticleMass(void) const {return m_pkDynParticleMass;};
		void						SetDynParticleMass(DiDynamicAttribute* dynParticleMass);

		inline DiDynamicAttribute*	GetDynVelocity(void) const {return m_pkDynVelocity;};
		void						SetDynVelocity(DiDynamicAttribute* dynVelocity);

		inline DiDynamicAttribute*	GetDynDuration(void) const {return m_pkDynDuration;};
		void 						SetDynDuration(DiDynamicAttribute* dynDuration);
		void 						SetDynDurationSet(bool durationSet);

		inline DiDynamicAttribute*	GetDynRepeatDelay(void) const {return m_pkDynRepeatDelay;};
		void 						SetDynRepeatDelay(DiDynamicAttribute* dynRepeatDelay);
		void 						SetDynRepeatDelaySet(bool repeatDelaySet);

		inline DiDynamicAttribute*	GetDynParticleAllDimensions(void) const {return m_pkDynParticleAllDimensions;};
		void 						SetDynParticleAllDimensions(DiDynamicAttribute* dynParticleAllDimensions);
		void 						SetDynParticleAllDimensionsSet(bool particleAllDimensionsSet);

		inline DiDynamicAttribute*	GetDynParticleWidth(void) const {return m_pkDynParticleWidth;};
		void 						SetDynParticleWidth(DiDynamicAttribute* dynParticleWidth);
		void 						SetDynParticleWidthSet(bool particleWidthSet);

		inline DiDynamicAttribute*	GetDynParticleHeight(void) const {return m_pkDynParticleHeight;};
		void 						SetDynParticleHeight(DiDynamicAttribute* dynParticleHeight);
		void 						SetDynParticleHeightSet(bool particleHeightSet);

		inline DiDynamicAttribute*	GetDynParticleDepth(void) const {return m_pkDynParticleDepth;};
		void 						SetDynParticleDepth(DiDynamicAttribute* dynParticleDepth);
		void 						SetDynParticleDepthSet(bool particleDepthSet);

		inline DiParticle::ParticleType	GetEmitsType(void) const {return m_eEmitsType;}
		void						SetEmitsType(DiParticle::ParticleType emitsType) {m_eEmitsType = emitsType;}

		inline const DiString&		GetEmitsName(void) const {return m_kEmitsName;}
		void						SetEmitsName(const DiString& emitsName){m_kEmitsName=emitsName;}

		virtual const DiVec3&		GetParticleDirection(void) const;

		const DiVec3& 				GetOriginalParticleDirection(void) const;

		const DiQuat& 				GetParticleOrientation(void) const;

		void						SetParticleOrientation(const DiQuat& orientation);

		const DiQuat&				GetParticleOrientationRangeStart(void) const;

		void						SetParticleOrientationRangeStart(const DiQuat& orientationRangeStart);

		const DiQuat&				GetParticleOrientationRangeEnd(void) const;

		void						SetParticleOrientationRangeEnd(const DiQuat& orientationRangeEnd);

		virtual void				SetEnabled (bool enabled);

		bool						IsEnabled()const{return m_bEnabled;}
	
		virtual void				SetParticleDirection(const DiVec3& direction);

		bool 						IsAutoDirection(void) const;

		void 						SetAutoDirection(bool autoDirection);

		bool 						IsForceEmission(void) const;

		void 						SetForceEmission(bool forceEmission);

		virtual void 				InitParticlePosition(DiParticle* particle);

		virtual void 				InitParticleForEmission(DiParticle* particle);

		virtual void 				InitParticleDirection(DiParticle* particle);

		virtual void				InitParticleOrientation(DiParticle* particle);

		void						GenerateAngle(DiRadian& angle);

		virtual void 				InitParticleVelocity(DiParticle* particle);

		virtual void 				InitParticleMass(DiParticle* particle);

		virtual void 				InitParticleColour(DiParticle* particle);

		virtual void				InitParticleTextureCoords(DiParticle* particle);

		inline float				InitParticleTimeToLive(void);

		// ����ʵ��Ҫ���������
		virtual unsigned short		CalculateRequestedParticles(float timeElapsed);

		// ��ʼ�����ӳߴ�
		inline void					InitParticleDimensions(DiParticle* particle);

		// ��ʼ��һЩ��ʱ����ص�����
		inline void					InitTimeBased(void);

		// DiParticleSystem����scale����Ӧ
		virtual void 				NotifyRescaled(const DiVec3& scale);

		virtual void 				CopyTo (DiParticleEmitter* emitter);

		virtual void 				CopyParentTo (DiParticleEmitter* emitter);

		const DiColor&				GetParticleColour(void) const;

		void						SetParticleColour(const DiColor& particleColour);

		const uint16&				GetParticleTextureCoords(void) const;

		void 						SetParticleTextureCoords(const uint16& particleTextureCoords);

		bool 						IsKeepLocal(void) const;

		// ���ӵ�λ���Ƿ���Է���������
		void						SetKeepLocal(bool keepLocal);

		// �任���ӵ�λ�õ�����ڷ������ı�������
		bool						MakeParticleLocal(DiParticle* particle);

		DiVec3						GetDerivedPosition();

	protected:

		
		DiParticleElement*			m_pkParentElement;

		// ������������
		DiVec3						m_kEmitterScale;

		// ����������
		DiString					m_kEmitterType;

		// �����������ɲ�����
		DiString					m_kName;

		// �������ӵ��ٶȺͷ���,ע�����ӷ���ͷ�����������һ����
		DiVec3						m_kParticleDirection;
		
		// ԭʼ����
		DiVec3						m_kOriginalParticleDirection;

		// ���ӷ���˲��ĳ���ֻ����Ⱦ����2Dʱ��Ч
		DiQuat						m_kParticleOrientation;

		// ����Ƕ�
		DiDynamicAttribute* 		m_pkDynAngle;

		// ������
		DiDynamicAttribute* 		m_pkDynEmissionRate;

		// ��ʱ��
		DiDynamicAttribute* 		m_pkDynTotalTimeToLive;

		// �ܶ�
		DiDynamicAttribute* 		m_pkDynParticleMass;

		// �ٶ�
		DiDynamicAttribute* 		m_pkDynVelocity;

		// ����ʱ��
		DiDynamicAttribute*			m_pkDynDuration;

		// ���������ظ����ӳ�
		DiDynamicAttribute*			m_pkDynRepeatDelay;

		// �ߴ磬ȫ���ߴ����������
		DiDynamicAttribute*			m_pkDynParticleAllDimensions;

		bool						m_bDynParticleAllDimensionsSet;

		// ���ӿ���
		DiDynamicAttribute* 		m_pkDynParticleWidth;

		bool						m_bDynParticleWidthSet;

		// ���Ӹ߶�
		DiDynamicAttribute* 		m_pkDynParticleHeight;

		bool						m_bDynParticleHeightSet;

		// �������
		DiDynamicAttribute*			m_pkDynParticleDepth;

		bool						m_bDynParticleDepthSet;

		// ������
		DiVec3						m_kUpVector;

		// ʣ�෢����
		float						m_fRemainder;

		DiDynamicAttributeFactory	m_kDynamicAttributeFactory;

		DiDynamicAttributeHelper	m_kDynamicAttributeHelper;

		// ʣ�����ʱ��
		float						m_fDurationRemain;

		// �Ƿ�ʹ��duration�������
		bool						m_bDynDurationSet;

		// Repeat/delayʣ����
		float						m_fRepeatDelayRemain;

		// �Ƿ�ʹ��Repeat/Delay����
		bool						m_bDynRepeatDelaySet;

		// �Զ����򣬼����ӵķ��򲢲����������õ�direction���������ɷ���������״����
		// �����϶��Ǵ�ֱ�ڷ���������״
		bool						m_bAutoDirection;

		// ����ǿ�Ʒ��䣬���Ƿ�Ϊһ���Է���
		// �����������Ч�ǳ����ڷ������ӣ�����һЩ������Ч�϶����ǳ����Եģ���Ҫǿ�ƲŻᷢ��
		bool 						m_bForceEmission;

		bool 						m_bOriginalForceEmission;

		bool 						m_bForceEmissionExecuted;

		bool 						m_bOriginalForceEmissionExecuted;

		DiColor						m_kParticleColour;

		bool						m_bKeepLocal;

		bool						m_bEnabled;

		uint16						m_uiParticleTextureCoords;

		DiParticle::ParticleType	m_eEmitsType;

		DiString					m_kEmitsName;
	};
}


#endif // ParticleEmitter_h__
