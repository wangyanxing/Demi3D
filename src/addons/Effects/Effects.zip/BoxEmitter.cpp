
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "BoxEmitter.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"

namespace Demi
{
	const float DiBoxEmitter::DEFAULT_HEIGHT = 100.0f;
	const float DiBoxEmitter::DEFAULT_DEPTH = 100.0f;
	const float DiBoxEmitter::DEFAULT_WIDTH = 100.0f;

	DiBoxEmitter::DiBoxEmitter(void) : 
		DiParticleEmitter(),
		m_fWidth(DEFAULT_WIDTH),
		m_fHeight(DEFAULT_HEIGHT),
		m_fDepth(DEFAULT_DEPTH),
		m_fXRange(0.5f * DEFAULT_WIDTH),
		m_fYRange(0.5f * DEFAULT_HEIGHT),
		m_fZRange(0.5f * DEFAULT_DEPTH)
	{
	}
	
	const float DiBoxEmitter::GetHeight(void) const
	{
		return m_fHeight;
	}
	
	void DiBoxEmitter::SetHeight(const float height)
	{
		m_fHeight = height;
		m_fYRange = 0.5f * height;
	}
	
	const float DiBoxEmitter::GetWidth(void) const
	{
		return m_fWidth;
	}
	
	void DiBoxEmitter::SetWidth(const float width)
	{
		m_fWidth = width;
		m_fXRange = 0.5f * width;
	}
	
	const float DiBoxEmitter::GetDepth(void) const
	{
		return m_fDepth;
	}
	
	void DiBoxEmitter::SetDepth(const float depth)
	{
		m_fDepth = depth;
		m_fZRange = 0.5f * depth;
	}
	
	void DiBoxEmitter::InitParticlePosition(DiParticle* particle)
	{
		DiParticleSystem* sys = m_pkParentElement->GetParentSystem();
		if (sys)
		{
			particle->position = GetDerivedPosition() + 
				sys->GetDerivedOrientation() *
				(m_kEmitterScale *
				DiVec3(DiMath::SymmetricRandom() * m_fXRange,
				DiMath::SymmetricRandom() * m_fYRange,
				DiMath::SymmetricRandom() * m_fZRange));
		}
		else
		{
			particle->position = GetDerivedPosition() + 
				m_kEmitterScale *
				DiVec3(DiMath::SymmetricRandom() * m_fXRange,
				DiMath::SymmetricRandom() * m_fYRange,
				DiMath::SymmetricRandom() * m_fZRange);
		}

		particle->originalPosition = particle->position;
	}
	
	void DiBoxEmitter::CopyTo (DiParticleEmitter* emitter)
	{
		DiParticleEmitter::CopyTo(emitter);

		DiBoxEmitter* boxEmitter = static_cast<DiBoxEmitter*>(emitter);
		boxEmitter->m_fHeight = m_fHeight;
		boxEmitter->m_fWidth = m_fWidth;
		boxEmitter->m_fDepth = m_fDepth;
		boxEmitter->m_fXRange = m_fXRange;
		boxEmitter->m_fYRange = m_fYRange;
		boxEmitter->m_fZRange = m_fZRange;
	}
}

