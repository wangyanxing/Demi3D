
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ParticleEmitter.h"
#include "DynamicAttributeFactory.h"
#include "VisualParticle.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"

namespace Demi
{
	const bool		DiParticleEmitter::DEFAULT_ENABLED = true;
	const DiVec3	DiParticleEmitter::DEFAULT_POSITION = DiVec3::ZERO;
	const bool		DiParticleEmitter::DEFAULT_KEEP_LOCAL = false;
	const DiVec3 	DiParticleEmitter::DEFAULT_DIRECTION = DiVec3::UNIT_Y;
	const DiQuat 	DiParticleEmitter::DEFAULT_ORIENTATION = DiQuat::IDENTITY;
	const DiQuat 	DiParticleEmitter::DEFAULT_ORIENTATION_RANGE_START = DiQuat::IDENTITY;
	const DiQuat 	DiParticleEmitter::DEFAULT_ORIENTATION_RANGE_END = DiQuat::IDENTITY;
	const DiParticle::ParticleType DiParticleEmitter::DEFAULT_EMITS = DiVisualParticle::PT_VISUAL;
	const uint16 	DiParticleEmitter::DEFAULT_START_TEXTURE_COORDS = 0;
	const uint16 	DiParticleEmitter::DEFAULT_END_TEXTURE_COORDS = 0;
	const uint16 	DiParticleEmitter::DEFAULT_TEXTURE_COORDS = 0;
	const DiColor 	DiParticleEmitter::DEFAULT_START_COLOUR_RANGE = DiColor::Black;
	const DiColor 	DiParticleEmitter::DEFAULT_END_COLOUR_RANGE = DiColor::White;
	const DiColor 	DiParticleEmitter::DEFAULT_COLOUR = DiColor::White;
	const bool 		DiParticleEmitter::DEFAULT_AUTO_DIRECTION = false;
	const bool 		DiParticleEmitter::DEFAULT_FORCE_EMISSION = false;
	const float 	DiParticleEmitter::DEFAULT_EMISSION_RATE = 10.0f;
	const float 	DiParticleEmitter::DEFAULT_TIME_TO_LIVE = 3.0f;
	const float 	DiParticleEmitter::DEFAULT_MASS = 1.0f;
	const float 	DiParticleEmitter::DEFAULT_VELOCITY = 100.0f;
	const float 	DiParticleEmitter::DEFAULT_DURATION = 0.0f;
	const float 	DiParticleEmitter::DEFAULT_REPEAT_DELAY = 0.0f;
	const float 	DiParticleEmitter::DEFAULT_ANGLE = 20.0f;
	const float 	DiParticleEmitter::DEFAULT_DIMENSIONS = 0.0f;
	const float 	DiParticleEmitter::DEFAULT_WIDTH = 0.0f;
	const float 	DiParticleEmitter::DEFAULT_HEIGHT = 0.0f;
	const float 	DiParticleEmitter::DEFAULT_DEPTH = 0.0f;

	DiParticleEmitter::DiParticleEmitter(void) :
		m_pkParentElement(0),
		m_fRemainder(0),
		m_fDurationRemain(0),
		m_fRepeatDelayRemain(0),
		m_bDynDurationSet(false),
		m_bDynRepeatDelaySet(false),
		m_bEnabled(DEFAULT_ENABLED),
		m_kParticleDirection(DEFAULT_DIRECTION),
		m_kOriginalParticleDirection(DEFAULT_DIRECTION),
		m_kParticleOrientation(DiQuat::IDENTITY),
		m_kUpVector(DiVec3::ZERO),
		m_bDynParticleAllDimensionsSet(false),
		m_bDynParticleWidthSet(false),
		m_bDynParticleHeightSet(false),
		m_bDynParticleDepthSet(false),
		m_bAutoDirection(DEFAULT_AUTO_DIRECTION),
		m_bForceEmission(DEFAULT_FORCE_EMISSION),
		m_bOriginalForceEmission(false),
		m_bForceEmissionExecuted(false),
		m_bOriginalForceEmissionExecuted(false),
		m_kName(DiString::BLANK),
		m_kEmitterScale(DiVec3::UNIT_SCALE),
		m_kParticleColour(DEFAULT_COLOUR),
		m_bKeepLocal(false),
		m_uiParticleTextureCoords(DEFAULT_TEXTURE_COORDS),
		m_eEmitsType(DEFAULT_EMITS),
		m_kEmitsName(DiString::BLANK)
	{
		m_pkDynEmissionRate = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynEmissionRate))->SetValue(DEFAULT_EMISSION_RATE);

		m_pkDynTotalTimeToLive = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynTotalTimeToLive))->SetValue(DEFAULT_TIME_TO_LIVE);

		m_pkDynParticleMass = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynParticleMass))->SetValue(DEFAULT_MASS);

		m_pkDynVelocity = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynVelocity))->SetValue(DEFAULT_VELOCITY);

		m_pkDynDuration = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynDuration))->SetValue(DEFAULT_DURATION);

		m_pkDynRepeatDelay = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynRepeatDelay))->SetValue(DEFAULT_REPEAT_DELAY);

		m_pkDynAngle = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynAngle))->SetValue(DEFAULT_ANGLE);

		m_pkDynParticleAllDimensions = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynParticleAllDimensions))->SetValue(DEFAULT_DIMENSIONS);

		m_pkDynParticleWidth = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynParticleWidth))->SetValue(DEFAULT_WIDTH);

		m_pkDynParticleHeight = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynParticleHeight))->SetValue(DEFAULT_HEIGHT);

		m_pkDynParticleDepth = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynParticleDepth))->SetValue(DEFAULT_DEPTH);
	}
	
	DiParticleEmitter::~DiParticleEmitter(void)
	{
		if (m_pkDynEmissionRate)
		{
			DI_DELETE m_pkDynEmissionRate;
		}

		if (m_pkDynTotalTimeToLive)
		{
			DI_DELETE m_pkDynTotalTimeToLive;
		}

		if (m_pkDynParticleMass)
		{
			DI_DELETE m_pkDynParticleMass;
		}

		if (m_pkDynVelocity)
		{
			DI_DELETE m_pkDynVelocity;
		}

		if (m_pkDynDuration)
		{
			DI_DELETE m_pkDynDuration;
		}

		if (m_pkDynRepeatDelay)
		{
			DI_DELETE m_pkDynRepeatDelay;
		}

		if (m_pkDynParticleAllDimensions)
		{
			DI_DELETE m_pkDynParticleAllDimensions;
		}

		if (m_pkDynParticleWidth)
		{
			DI_DELETE m_pkDynParticleWidth;
		}

		if (m_pkDynParticleHeight)
		{
			DI_DELETE m_pkDynParticleHeight;
		}

		if (m_pkDynParticleDepth)
		{
			DI_DELETE m_pkDynParticleDepth;
		}

		if (m_pkDynAngle)
		{
			DI_DELETE m_pkDynAngle;
		}
	}
	
	bool DiParticleEmitter::IsKeepLocal(void) const
	{
		return m_bKeepLocal;
	}
	
	void DiParticleEmitter::SetKeepLocal(bool keepLocal)
	{
		m_bKeepLocal = keepLocal;
	}
	
	bool DiParticleEmitter::MakeParticleLocal(DiParticle* particle)
	{
		if (!particle)
		{
			return true;
		}

		if (!m_bKeepLocal)
		{
			return false;
		}

		
		DiVec3 diff = GetDerivedPosition() - GetDerivedPosition()/*latestPosition*/;
		particle->position += diff;
		return true;
	}
	
	void DiParticleEmitter::NotifyRescaled(const DiVec3& scale)
	{
		m_kEmitterScale = scale;
	}
	
	const DiColor& DiParticleEmitter::GetParticleColour(void) const
	{
		return m_kParticleColour;
	}
	
	void DiParticleEmitter::SetParticleColour(const DiColor& particleColour)
	{
		m_kParticleColour = particleColour;
	}
	
	const uint16& DiParticleEmitter::GetParticleTextureCoords(void) const
	{
		return m_uiParticleTextureCoords;
	}
	
	void DiParticleEmitter::SetParticleTextureCoords(const uint16& particleTextureCoords)
	{
		m_uiParticleTextureCoords = particleTextureCoords;
	}

	void DiParticleEmitter::CopyTo( DiParticleEmitter* emitter )
	{
		CopyParentTo(emitter);
		emitter->SetEmitterType(m_kEmitterType);
	}
	
	void DiParticleEmitter::CopyParentTo(DiParticleEmitter* emitter)
	{
		emitter->SetName(m_kName);
		emitter->m_kParticleDirection = m_kParticleDirection;
		emitter->m_kOriginalParticleDirection = m_kOriginalParticleDirection;
		emitter->m_kParticleOrientation = m_kParticleOrientation;
		emitter->m_pkParentElement = m_pkParentElement;
		emitter->m_bAutoDirection = m_bAutoDirection;
		emitter->m_bForceEmission = m_bForceEmission;
		emitter->m_bOriginalForceEmission = m_bOriginalForceEmission;
		emitter->m_bForceEmissionExecuted = m_bForceEmissionExecuted;
		emitter->m_bOriginalForceEmissionExecuted = m_bOriginalForceEmissionExecuted;
		emitter->m_bDynDurationSet = m_bDynDurationSet;
		emitter->m_bDynRepeatDelaySet = m_bDynRepeatDelaySet;
		emitter->m_bDynParticleAllDimensionsSet = m_bDynParticleAllDimensionsSet;
		emitter->m_bDynParticleWidthSet = m_bDynParticleWidthSet;
		emitter->m_bDynParticleHeightSet = m_bDynParticleHeightSet;
		emitter->m_bDynParticleDepthSet = m_bDynParticleDepthSet;
		emitter->m_kEmitterScale = m_kEmitterScale;
		emitter->m_kParticleColour = m_kParticleColour;
		emitter->m_uiParticleTextureCoords = m_uiParticleTextureCoords;
		emitter->m_bKeepLocal = m_bKeepLocal;

		emitter->SetDynEmissionRate(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynEmissionRate()));

		emitter->SetDynTotalTimeToLive(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynTotalTimeToLive()));

		emitter->SetDynVelocity(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynVelocity()));

		if (m_bDynDurationSet)
		{
			emitter->SetDynDuration(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynDuration()));
		}

		if (m_bDynRepeatDelaySet)
		{
			emitter->SetDynRepeatDelay(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynRepeatDelay()));
		}

		emitter->SetDynParticleMass(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynParticleMass()));

		emitter->SetDynAngle(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynAngle()));

		if (m_bDynParticleAllDimensionsSet)
		{
			emitter->SetDynParticleAllDimensions(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynParticleAllDimensions()));
		}
		if (m_bDynParticleWidthSet)
		{
			emitter->SetDynParticleWidth(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynParticleWidth()));
		}
		if (m_bDynParticleHeightSet)
		{
			emitter->SetDynParticleHeight(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynParticleHeight()));
		}
		if (m_bDynParticleDepthSet)
		{
			emitter->SetDynParticleDepth(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynParticleDepth()));
		}
	}
	
	void DiParticleEmitter::SetParentElement(DiParticleElement* parentTechnique)
	{
		m_pkParentElement = parentTechnique;
	}

	void DiParticleEmitter::SetDynEmissionRate(DiDynamicAttribute* dynEmissionRate)
	{
		if (m_pkDynEmissionRate)
		{
			DI_DELETE m_pkDynEmissionRate;
		}

		m_pkDynEmissionRate = dynEmissionRate;
	}
	
	void DiParticleEmitter::SetDynTotalTimeToLive(DiDynamicAttribute* dynTotalTimeToLive)
	{
		if (m_pkDynTotalTimeToLive)
		{
			DI_DELETE m_pkDynTotalTimeToLive;
		}

		m_pkDynTotalTimeToLive = dynTotalTimeToLive;
	}
	
	void DiParticleEmitter::SetDynParticleMass(DiDynamicAttribute* dynParticleMass)
	{
		if (m_pkDynParticleMass)
		{
			DI_DELETE m_pkDynParticleMass;
		}

		m_pkDynParticleMass = dynParticleMass;
	}
	
	void DiParticleEmitter::SetDynAngle(DiDynamicAttribute* dynAngle)
	{
		if (m_pkDynAngle)
		{
			DI_DELETE m_pkDynAngle;
		}

		m_pkDynAngle = dynAngle;
	}
	
	void DiParticleEmitter::SetDynVelocity(DiDynamicAttribute* dynVelocity)
	{
		if (m_pkDynVelocity)
		{
			DI_DELETE m_pkDynVelocity;
		}

		m_pkDynVelocity = dynVelocity;
	}
	
	void DiParticleEmitter::SetDynDuration(DiDynamicAttribute* dynDuration)
	{
		if (m_pkDynDuration)
		{
			DI_DELETE m_pkDynDuration;
		}

		m_pkDynDuration = dynDuration;
		m_bDynDurationSet = true;
		InitTimeBased();
	}
	
	void DiParticleEmitter::SetDynDurationSet(bool durationSet)
	{
		m_bDynDurationSet = durationSet;
	}
	
	void DiParticleEmitter::SetDynRepeatDelay(DiDynamicAttribute* dynRepeatDelay)
	{
		if (m_pkDynRepeatDelay)
		{
			DI_DELETE m_pkDynRepeatDelay;
		}

		m_pkDynRepeatDelay = dynRepeatDelay;
		m_bDynRepeatDelaySet = true;
		InitTimeBased();
	}
	
	void DiParticleEmitter::SetDynRepeatDelaySet(bool repeatDelaySet)
	{
		m_bDynRepeatDelaySet = repeatDelaySet;
	}
	
	void DiParticleEmitter::SetDynParticleAllDimensions(DiDynamicAttribute* dynParticleAllDimensions)
	{
		if (m_pkDynParticleAllDimensions)
		{
			DI_DELETE m_pkDynParticleAllDimensions;
		}
		m_pkDynParticleAllDimensions = dynParticleAllDimensions;
		m_bDynParticleAllDimensionsSet = true;
	}
	
	void DiParticleEmitter::SetDynParticleAllDimensionsSet(bool particleAllDimensionsSet)
	{
		m_bDynParticleAllDimensionsSet = particleAllDimensionsSet;
	}
	
	void DiParticleEmitter::SetDynParticleWidth(DiDynamicAttribute* dynParticleWidth)
	{
		if (m_pkDynParticleWidth)
		{
			DI_DELETE m_pkDynParticleWidth;
		}

		m_pkDynParticleWidth = dynParticleWidth;
		m_bDynParticleWidthSet = true;
	}
	
	void DiParticleEmitter::SetDynParticleWidthSet(bool particleWidthSet)
	{
		m_bDynParticleWidthSet = particleWidthSet;
	}
	
	void DiParticleEmitter::SetDynParticleHeight(DiDynamicAttribute* dynParticleHeight)
	{
		if (m_pkDynParticleHeight)
		{
			DI_DELETE m_pkDynParticleHeight;
		}

		m_pkDynParticleHeight = dynParticleHeight;
		m_bDynParticleHeightSet = true;
	}
	
	void DiParticleEmitter::SetDynParticleHeightSet(bool particleHeightSet)
	{
		m_bDynParticleHeightSet = particleHeightSet;
	}
	
	void DiParticleEmitter::SetDynParticleDepth(DiDynamicAttribute* dynParticleDepth)
	{
		if (m_pkDynParticleDepth)
		{
			DI_DELETE m_pkDynParticleDepth;
		}

		m_pkDynParticleDepth = dynParticleDepth;
		m_bDynParticleDepthSet = true;
	}
	
	void DiParticleEmitter::SetDynParticleDepthSet(bool particleDepthSet)
	{
		m_bDynParticleDepthSet = particleDepthSet;
	}
	
	void DiParticleEmitter::SetEnabled(bool enabled)
	{
		m_bEnabled = enabled;
		InitTimeBased();
    }
	
	const DiVec3& DiParticleEmitter::GetParticleDirection(void) const
	{
		return m_kParticleDirection;
	}
	
	void DiParticleEmitter::SetParticleDirection(const DiVec3& direction)
	{
		m_kParticleDirection = direction;
		m_kOriginalParticleDirection = direction;
		m_kParticleDirection.normalise();
		m_kUpVector = m_kParticleDirection.perpendicular();
		m_kUpVector.normalise();
    }
	
	const DiVec3& DiParticleEmitter::GetOriginalParticleDirection(void) const
	{
		return m_kOriginalParticleDirection;
	}
	
	const DiQuat& DiParticleEmitter::GetParticleOrientation(void) const
	{
		return m_kParticleOrientation;
	}
	
	void DiParticleEmitter::SetParticleOrientation(const DiQuat& orientation)
	{
		m_kParticleOrientation = orientation;
    }
	
	bool DiParticleEmitter::IsAutoDirection(void) const
	{
		return m_bAutoDirection;
	}
	
	void DiParticleEmitter::SetAutoDirection(bool autoDirection)
	{
		m_bAutoDirection = autoDirection;
    }
	
	bool DiParticleEmitter::IsForceEmission(void) const
	{
		return m_bForceEmission;
	}
	
	void DiParticleEmitter::SetForceEmission(bool forceEmission)
	{
		m_bForceEmission = forceEmission;
		m_bOriginalForceEmission = forceEmission;
		m_bForceEmissionExecuted = false;
		m_bOriginalForceEmissionExecuted = false;
    }
	
	void DiParticleEmitter::InitTimeBased(void)
    {
		if (m_bEnabled)
		{
			if (m_bDynDurationSet && m_pkParentElement)
			{
				m_fDurationRemain = m_kDynamicAttributeHelper.Calculate(
					m_pkDynDuration, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
			}

			if (m_fDurationRemain > 0)
			{
				m_bEnabled = true;
				m_fRepeatDelayRemain = 0;
			}
		}
		else
		{
			if (m_bDynRepeatDelaySet && m_pkParentElement)
			{
				m_fRepeatDelayRemain = m_kDynamicAttributeHelper.Calculate(m_pkDynRepeatDelay, 
					m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
			}
		}
	}

	DiVec3 DiParticleEmitter::GetDerivedPosition() 
	{
		return m_pkParentElement->GetDerivedPosition();
	}

	void DiParticleEmitter::InitParticlePosition(DiParticle* particle)
	{
		particle->position = GetDerivedPosition();
		particle->originalPosition = particle->position;
		particle->latestPosition = particle->position;
	}
	
	void DiParticleEmitter::InitParticleForEmission(DiParticle* particle)
	{
		particle->parentEmitter = this;
		InitParticlePosition(particle);
		InitParticleDirection(particle);
		InitParticleVelocity(particle);
		InitParticleOrientation(particle);
		InitParticleMass(particle);
		InitParticleColour(particle);
		InitParticleTextureCoords(particle);
		particle->totalTimeToLive = InitParticleTimeToLive();
		particle->timeToLive = particle->totalTimeToLive;
		
		InitParticleDimensions(particle);
	}
	
    void DiParticleEmitter::InitParticleDirection(DiParticle* particle)
    {
		DiRadian angle;
		GenerateAngle(angle);
		if (angle != DiRadian(0))
		{
			particle->direction = m_kParticleDirection.randomDeviant(angle, m_kUpVector);
		}
		else
		{
			particle->direction = m_kParticleDirection;
		}
		particle->originalDirection = particle->direction;
		particle->originalDirectionLength = particle->direction.length();
    }
	
	void DiParticleEmitter::GenerateAngle(DiRadian& angle)
	{
		DiRadian a = DiAngle(m_kDynamicAttributeHelper.Calculate(m_pkDynAngle, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart()));
		angle = a;
		if (m_pkDynAngle->GetType() == DiDynamicAttribute::DAT_FIXED)
		{
			angle = DiMath::UnitRandom() * angle;
		}
	}
	
	void DiParticleEmitter::InitParticleVelocity(DiParticle* particle)
    {
		float scalar = m_kDynamicAttributeHelper.Calculate(m_pkDynVelocity, m_pkParentElement->GetParentSystem(
			)->GetTimeElapsedSinceStart(), 1.0f);
		particle->direction *= scalar;
		particle->originalVelocity = scalar;
		particle->originalScaledDirectionLength = particle->direction.length();
    }
	
	void DiParticleEmitter::InitParticleOrientation(DiParticle* particle)
	{
		if (particle->particleType != DiParticle::PT_VISUAL)
			return;

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		visualParticle->orientation = m_kParticleOrientation;

		visualParticle->originalOrientation = visualParticle->orientation;
    }
	
    void DiParticleEmitter::InitParticleMass(DiParticle* particle)
    {
		float mass = m_kDynamicAttributeHelper.Calculate(m_pkDynParticleMass, m_pkParentElement->GetParentSystem(
			)->GetTimeElapsedSinceStart(), DiParticle::DEFAULT_MASS);
		particle->mass = mass;
    }
	
	void DiParticleEmitter::InitParticleColour(DiParticle* particle)
    {
		if (particle->particleType != DiParticle::PT_VISUAL)
			return;

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		visualParticle->colour = m_kParticleColour;

		visualParticle->originalColour = visualParticle->colour;
    }
	
	void DiParticleEmitter::InitParticleTextureCoords(DiParticle* particle)
    {
		if (particle->particleType != DiParticle::PT_VISUAL)
			return;

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		visualParticle->textureCoordsCurrent = m_uiParticleTextureCoords;
    }
	
    float DiParticleEmitter::InitParticleTimeToLive(void)
    {
		return m_kDynamicAttributeHelper.Calculate(m_pkDynTotalTimeToLive, m_pkParentElement->GetParentSystem(
			)->GetTimeElapsedSinceStart(), DiParticle::DEFAULT_TTL);
    }
    
	unsigned short DiParticleEmitter::CalculateRequestedParticles(float timeElapsed)
	{
		unsigned short requestedParticles = 0;
        
		if (m_bEnabled)
		{
			if (m_pkDynEmissionRate && m_pkParentElement && m_pkParentElement->GetParentSystem())
			{
				float rate = m_pkDynEmissionRate->GetValue(m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
				
				if (m_bForceEmission)
				{
					if (m_bForceEmissionExecuted)
					{
						requestedParticles = 0;
					}
					else
					{
						requestedParticles = (unsigned short)rate;
						m_bForceEmissionExecuted = true;
					}
				}
				else
				{
					m_fRemainder += rate * timeElapsed;
					requestedParticles = (unsigned short)m_fRemainder;
				}
				
				m_fRemainder -= requestedParticles;
			}

			if (m_bDynDurationSet)
			{
				m_fDurationRemain -= timeElapsed;
				if (m_fDurationRemain <= 0)
				{
					SetEnabled(false);
				}
			}
		}
		else if (m_bDynRepeatDelaySet)
		{
			m_fRepeatDelayRemain -= timeElapsed;
			if (m_fRepeatDelayRemain <= 0)
			{
				SetEnabled(true);
			}
		}

		return requestedParticles;
	}
	
	void DiParticleEmitter::InitParticleDimensions(DiParticle* particle)
    {
		if (particle->particleType != DiParticle::PT_VISUAL)
		{
			return;
		}

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		if (m_bDynParticleAllDimensionsSet || m_bDynParticleWidthSet || m_bDynParticleHeightSet || m_bDynParticleDepthSet)
		{
			float extend = 0;
			if (m_bDynParticleAllDimensionsSet && m_pkDynParticleAllDimensions)
			{
				extend = m_kDynamicAttributeHelper.Calculate(m_pkDynParticleAllDimensions,
					m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
				visualParticle->SetOwnDimensions(m_kEmitterScale.x * extend,
					m_kEmitterScale.y * extend, m_kEmitterScale.z * extend);
				return;
			}

			float width = 0;
			float height = 0;
			float depth = 0;
			if (m_bDynParticleWidthSet && m_pkDynParticleWidth)
			{
				width = m_kDynamicAttributeHelper.Calculate(m_pkDynParticleWidth, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
			}
			if (m_bDynParticleHeightSet && m_pkDynParticleHeight)
			{
				height = m_kDynamicAttributeHelper.Calculate(m_pkDynParticleHeight, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
			}
			if (m_bDynParticleDepthSet && m_pkDynParticleDepth)
			{
				depth = m_kDynamicAttributeHelper.Calculate(m_pkDynParticleDepth, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
			}

			if (m_bDynParticleWidthSet || m_bDynParticleHeightSet || m_bDynParticleDepthSet)
			{
				visualParticle->SetOwnDimensions(m_kEmitterScale.x * width, m_kEmitterScale.y * height, m_kEmitterScale.z * depth);
			}
		}
		else
		{
			visualParticle->width	= m_kEmitterScale.x * m_pkParentElement->GetDefaultWidth();
			visualParticle->height	= m_kEmitterScale.y * m_pkParentElement->GetDefaultHeight();
			visualParticle->depth	= m_kEmitterScale.z * m_pkParentElement->GetDefaultDepth();
			visualParticle->CalculateBoundingSphereRadius();
		}
	}
}

