
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ParticleSystem.h"
#include "SceneManager.h"
#include "CullNode.h"
#include "RenderWindow.h"
#include "ParticleElement.h"
#include "ParticleEmitter.h"
#include "EffectManager.h"

namespace Demi
{
	const bool		DiParticleSystem::DEFAULT_KEEP_LOCAL					= false;
	const float 	DiParticleSystem::DEFAULT_ITERATION_INTERVAL			= 0.0f;
	const float 	DiParticleSystem::DEFAULT_FIXED_TIMEOUT					= 0.0f;
	const float 	DiParticleSystem::DEFAULT_NON_VISIBLE_UPDATE_TIMEOUT	= 0.0f;
	const bool		DiParticleSystem::DEFAULT_SMOOTH_LOD					= false;
	const float 	DiParticleSystem::DEFAULT_FAST_FORWARD_TIME				= 0.0f;
	const float 	DiParticleSystem::DEFAULT_SCALE_VELOCITY				= 1.0f;
	const float 	DiParticleSystem::DEFAULT_SCALE_TIME					= 1.0f;
	const DiVec3	DiParticleSystem::DEFAULT_SCALE							= DiVec3::UNIT_SCALE;
	const bool		DiParticleSystem::DEFAULT_TIGHT_BOUNDINGBOX				= false;
	
	DiParticleSystem::DiParticleSystem(const DiString& name) :
		m_kAABB(),
		DiTransformUnit(name),
		m_pkSceneManager(0),
		mTimeSinceLastVisible(0.0f),
		mLastVisibleFrame(0),
		m_eState(DiParticleSystem::PSS_STOPPED),
		mNonvisibleUpdateTimeout(DEFAULT_NON_VISIBLE_UPDATE_TIMEOUT),
		mNonvisibleUpdateTimeoutSet(false),
		mSmoothLod(DEFAULT_SMOOTH_LOD),
		mSuppressNotifyEmissionChange(true),
		mIterationInterval(DEFAULT_ITERATION_INTERVAL),
		mIterationIntervalSet(false),
		mTimeSinceLastUpdate(0.0f),
		mFixedTimeout(DEFAULT_FIXED_TIMEOUT),
		mFixedTimeoutSet(false),
		mBoundsAutoUpdate(true),
		mBoundsUpdateTime(10.0f),
		mOriginalBoundsUpdateTime(10.0f),
		m_bFastForwardSet(false),
		m_bOriginalFastForwardSet(false),
		m_fFastForwardTime(DEFAULT_FAST_FORWARD_TIME),
		m_fFastForwardInterval(0.0f),
		m_pkCurrentCamera(0),
		m_kParticleSystemScale(DEFAULT_SCALE),
		m_kParticleSystemScaleVelocity(DEFAULT_SCALE_VELOCITY),
		mParticleSystemScaleTime(DEFAULT_SCALE_TIME),
		mKeepLocal(DEFAULT_KEEP_LOCAL),
		mTightBoundingBox(DEFAULT_TIGHT_BOUNDINGBOX),
		mPauseTime(0.0f),
		mPauseTimeSet(false),
		mPauseTimeElapsed(0.0f),
		mTemplateName(DiString::BLANK),
		mStopFadeSet(false),
		m_kLatestOrientation(DiQuat::IDENTITY),
		m_kRotationOffset(DiQuat::IDENTITY),
		m_kRotationCentre(DiVec3::ZERO),
		mAtLeastOneParticleEmitted(false),
		mLastLodIndex(0)
	{
		particleType = PT_UNUSED;
	}
	
	DiParticleSystem::~DiParticleSystem(void)
	{
		PushSystemEvent(PU_EVT_SYSTEM_DELETING);
		DestroyAllTechniques();
	}
	
	DiParticleSystem& DiParticleSystem::operator=(const DiParticleSystem& ps)
	{
		DestroyAllTechniques();

		// first copy the sceneManager pointer
		m_pkSceneManager = ps.m_pkSceneManager;

		size_t i = 0;
		DiParticleElement* psTechnique = 0;
		DiParticleElement* clonedTechnique = 0;
		for(i = 0; i < ps.GetNumElements(); ++i)
		{
			psTechnique = ps.GetElement(i);
			clonedTechnique = GetEffectManager()->CloneElement(psTechnique);
			AddElement(clonedTechnique);
		}

		mNonvisibleUpdateTimeout = ps.mNonvisibleUpdateTimeout;
		mNonvisibleUpdateTimeoutSet = ps.mNonvisibleUpdateTimeoutSet;
		mLodDistanceList = ps.mLodDistanceList;
		mSmoothLod  = ps.mSmoothLod;
		mIterationIntervalSet = ps.mIterationIntervalSet;
		mIterationInterval = ps.mIterationInterval;
		mTimeSinceLastUpdate = ps.mTimeSinceLastUpdate;
		mFixedTimeout = ps.mFixedTimeout;
		mFixedTimeoutSet = ps.mFixedTimeoutSet;
		m_eState = ps.m_eState;
		mTimeElapsedSinceStart = ps.mTimeElapsedSinceStart;
		mSuppressNotifyEmissionChange = ps.mSuppressNotifyEmissionChange;
		m_bFastForwardSet = ps.m_bFastForwardSet;
		m_bOriginalFastForwardSet = ps.m_bOriginalFastForwardSet;
		m_fFastForwardTime = ps.m_fFastForwardTime;
		m_fFastForwardInterval = ps.m_fFastForwardInterval;
		m_kParticleSystemScale = ps.m_kParticleSystemScale;
		m_kParticleSystemScaleVelocity = ps.m_kParticleSystemScaleVelocity;
		mParticleSystemScaleTime = ps.mParticleSystemScaleTime;
		mKeepLocal = ps.mKeepLocal;
		mTightBoundingBox = ps.mTightBoundingBox;
		mPauseTime = ps.mPauseTime;
		mPauseTimeSet = ps.mPauseTimeSet;
		mPauseTimeElapsed = ps.mPauseTimeElapsed;
		mTemplateName = ps.mTemplateName;
		mStopFadeSet = ps.mStopFadeSet;

		mSuppressNotifyEmissionChange = false;
		NotifyEmissionChange();
		NotifyRescaled();
		NotifyVelocityRescaled();

		return *this;
    }
	
	void DiParticleSystem::AddParticleSystemListener (DiParticleSystemListener* particleSystemListener)
	{
		mParticleSystemListenerList.push_back(particleSystemListener);
	}
	
	void DiParticleSystem::RemoveParticleSystemListener (DiParticleSystemListener* particleSystemListener)
	{
		assert(particleSystemListener && "ParticleSystemListener is null!");
		ParticleSystemListenerIterator it;
		ParticleSystemListenerIterator itEnd = mParticleSystemListenerList.end();
		for (it = mParticleSystemListenerList.begin(); it != itEnd; ++it)
		{
			if (*it == particleSystemListener)
			{
				mParticleSystemListenerList.erase(it);
				break;
			}
		}
	}
	
	void DiParticleSystem::PushSystemEvent(EventType eventType)
	{
		ParticleUniverseEvent evt;
		evt.eventType = eventType;
		evt.componentType = CT_SYSTEM;
		evt.componentName = GetName();
		evt.technique = 0;
		evt.emitter = 0;
		PushEvent(evt);
	}
	
	void DiParticleSystem::PushEvent(ParticleUniverseEvent& particleUniverseEvent)
	{
		if (mParticleSystemListenerList.empty())
		{
			return;
		}

		ParticleSystemListenerIterator it;
		ParticleSystemListenerIterator itEnd = mParticleSystemListenerList.end();
		for (it = mParticleSystemListenerList.begin(); it != itEnd; ++it)
		{
			(*it)->HandleParticleSystemEvent(this, particleUniverseEvent);
		}
	}
	
	bool DiParticleSystem::HasTightBoundingBox(void) const
	{
		return mTightBoundingBox;
	}
	
	void DiParticleSystem::SetTightBoundingBox(bool tightBoundingBox)
	{
		mTightBoundingBox = tightBoundingBox;
	}
	
	float DiParticleSystem::GetPauseTime(void) const
	{
		return mPauseTime;
	}
	
	void DiParticleSystem::SetPauseTime(float pauseTime)
	{
		mPauseTime = pauseTime;
		mPauseTimeSet = true;
	}
	
	const DiString& DiParticleSystem::GetTemplateName(void) const
	{
		return mTemplateName;
	}
	
	void DiParticleSystem::SetTemplateName(const DiString& templateName)
	{
		mTemplateName = templateName;
	}
	
	void DiParticleSystem::SetEnabled(bool enabled)
	{
		DiParticle::SetEnabled(enabled);
		if (enabled && m_eState != PSS_STARTED)
		{
			Start();
		}
		else
		{
			Stop();
		}
	}
	
	DiSceneManager* DiParticleSystem::GetSceneManager(void)
	{
		return m_pkSceneManager;
	}
	
	void DiParticleSystem::SetSceneManager(DiSceneManager* sceneManager)
	{
		m_pkSceneManager = sceneManager;
	}
	
	bool DiParticleSystem::IsKeepLocal(void) const
	{
		return mKeepLocal;
	}
	
	void DiParticleSystem::SetKeepLocal(bool keepLocal)
	{
		mKeepLocal = keepLocal;
	}
	
	bool DiParticleSystem::MakeParticleLocal(DiParticle* particle)
	{
		if (!particle)
		{
			return true;
		}

		if (!mKeepLocal || HasEventFlags(DiParticle::PEF_EXPIRED))
		{
			return false;
		}

		DiVec3 diff = GetDerivedPosition() - latestPosition;
		particle->position += diff;
		return true;
	}
	
	const DiVec3& DiParticleSystem::GetDerivedPosition(void)
	{
		if (m_bMarkedForEmission)
		{
			// ��Ϊ���ӷ���
			m_kDerivedPosition = position;
		}
		else
		{
			if (m_pkParentNode)
			{
				m_kDerivedPosition = m_pkParentNode->GetDerivedPosition();
			}
			else
			{
				m_kDerivedPosition = DiVec3::ZERO;
			}
		}
		return m_kDerivedPosition;
	}
	
	const DiQuat& DiParticleSystem::GetDerivedOrientation(void) const
	{
		if (m_bMarkedForEmission)
		{
			if (parentEmitter)
			{
				return parentEmitter->GetParentElement()->GetParentSystem()->GetDerivedOrientation();
			}
			else
			{
				return DiQuat::IDENTITY;
			}
		}
		else
		{
			if (m_pkParentNode)
			{
				return m_pkParentNode->GetDerivedOrientation();
			}
			else
			{
				return DiQuat::IDENTITY;
			}
		}
	}
	
	const DiQuat& DiParticleSystem::GetLatestOrientation(void) const
	{
		return m_kLatestOrientation;
	}
	
	bool DiParticleSystem::HasRotatedBetweenUpdates(void) const
	{
		return m_kLatestOrientation != GetDerivedOrientation();
	}
	
	void DiParticleSystem::CalulateRotationOffset(void)
	{
		if (m_bMarkedForEmission)
		{
			// ʹ�÷������ps�ķ������ĸ�ps����������
			m_kRotationCentre = parentEmitter->GetParentElement()->GetParentSystem()->GetDerivedPosition();
		}
		else
		{
			// ʹ���Լ���λ��
			m_kRotationCentre = GetDerivedPosition();
		}

		// ������תƫ��
		m_kRotationOffset = GetDerivedOrientation() * m_kLatestOrientation.Inverse();
	}
	
	void DiParticleSystem::RotationOffset(DiVec3& pos)
	{
		pos = m_kRotationCentre + m_kRotationOffset * (pos - m_kRotationCentre);
	}
	
	DiParticleElement* DiParticleSystem::CreateElement(void)
	{
		DiParticleElement* technique = GetEffectManager()->CreateElement();
		AddElement(technique);
		return technique;
	}
	
	void DiParticleSystem::AddElement(DiParticleElement* element)
	{
		m_kElements.push_back(element);
		element->SetParentSystem(this);
		element->NotifyRescaled(m_kParticleSystemScale);
		element->NotifyVelocityRescaled(m_kParticleSystemScaleVelocity);
		NotifyEmissionChange();
	}
	
	void DiParticleSystem::RemoveElement(DiParticleElement* element)
	{
		MT_ASSERT(element);
		ParticleTechniqueIterator it;
		for (it = m_kElements.begin(); it != m_kElements.end(); ++it)
		{
			if ((*it) == element)
			{
				m_kElements.erase(it);
				break;
			}
		}

		element->SetParentSystem(NULL);

		NotifyEmissionChange();
	}
	
	DiParticleElement* DiParticleSystem::GetElement (size_t index) const
	{
		MT_ASSERT(index < m_kElements.size());
		return m_kElements[index];
	}
	
	DiParticleElement* DiParticleSystem::GetElement (const DiString& techniqueName) const
	{
		if (techniqueName == DiString::BLANK)
		{
			return 0;
		}

		ParticleTechniqueConstIterator it;
		ParticleTechniqueConstIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			if ((*it)->GetName() == techniqueName)
			{
				return *it;
			}
		}

		return 0;
	}
	
	size_t DiParticleSystem::GetNumElements (void) const
	{
		return m_kElements.size();
	}
	
	void DiParticleSystem::DestroyElement(DiParticleElement* element)
	{
		MT_ASSERT(element);
		ParticleTechniqueIterator it;
		for (it = m_kElements.begin(); it != m_kElements.end(); ++it)
		{
			if ((*it) == element)
			{
				GetEffectManager()->DestroyElement(*it);
				m_kElements.erase(it);
				break;
			}
		}

		NotifyEmissionChange();
	}
	
	void DiParticleSystem::DestroyElement (size_t index)
	{
		DestroyElement(GetElement(index));
	}
	
	void DiParticleSystem::DestroyAllTechniques (void)
	{
		ParticleTechniqueIterator it;
		for (it = m_kElements.begin(); it != m_kElements.end(); ++it)
		{
			GetEffectManager()->DestroyElement(*it);
		}
		m_kElements.clear();
	}
	
	const float DiParticleSystem::GetFastForwardTime(void) const
	{
		return m_fFastForwardTime;
	}
	
	const float DiParticleSystem::GetFastForwardInterval(void) const
	{
		return m_fFastForwardInterval;
	}
	
	void DiParticleSystem::SetFastForward(float time, float interval)
	{
		m_bFastForwardSet = true;
		m_bOriginalFastForwardSet = true;
		m_fFastForwardTime = time;
		m_fFastForwardInterval = interval;
	}

	DiCamera* DiParticleSystem::GetMainCamera(void)
	{
		if (m_pkSceneManager)
		{
			m_pkCurrentCamera = m_pkSceneManager->GetCamera();
			return m_pkCurrentCamera;
		}
		return NULL;
	}
	
	void DiParticleSystem::SetMainCamera(DiCamera* camera)
	{
		if (!camera)
		{
			return;
		}
		
		m_pkCurrentCamera = camera;
	}
	
	DiCamera* DiParticleSystem::GetCurrentCamera(void)
	{
		return m_pkCurrentCamera;
	}
	
	void DiParticleSystem::FastForward(void)
	{
		if (!m_bFastForwardSet)
		{
			return;
		}

		for (float ftime = 0; ftime < m_fFastForwardTime; ftime += m_fFastForwardInterval)
		{
			Update(m_fFastForwardInterval);
		}
		
		m_bFastForwardSet = false;
	}
	
	void DiParticleSystem::NotifyAttached(DiNode* parent)
	{
		PushSystemEvent(PU_EVT_SYSTEM_ATTACHING);

		DiTransformUnit::NotifyAttached(parent);
		
		if (parent)
		{
			mTimeSinceLastVisible = 0;
			mLastVisibleFrame = m_pkSceneManager->GetRenderWindow()->GetFrameNum();
		}

		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->NotifyAttached(parent);
		}

		PushSystemEvent(PU_EVT_SYSTEM_ATTACHED);
	}
	
	void DiParticleSystem::NotifyCurrentCamera(DiCamera* cam)
	{
		m_pkCurrentCamera = cam;
		DiTransformUnit::NotifyCurrentCamera(cam);
		mLastVisibleFrame = m_pkSceneManager->GetRenderWindow()->GetFrameNum();
		mTimeSinceLastVisible = 0.0f;

		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		DiVec3 vec = DiVec3::ZERO;
		float squareDistance = 0;
		DiVec3 vecCameraParentNode = cam->GetDerivedPosition() - GetParentNode()->GetDerivedPosition();
		float squareDistanceCameraParentNode = vecCameraParentNode.squaredLength();
		unsigned short index = 0;
		bool doCamera = true;

		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			if ((*it)->IsMarkedForEmission())
			{
				vec = cam->GetDerivedPosition() - (*it)->position;
				squareDistance = vec.squaredLength();
			}
			else
			{
				vec = vecCameraParentNode;
				squareDistance = squareDistanceCameraParentNode;
			}

			if (doCamera)
			{
				(*it)->SetCameraSquareDistance(squareDistance);
			}

			// ���LOD�б����Ƿ���LOD��Ҫ
			if (!mLodDistanceList.empty())
			{
				if (doCamera)
				{
					index = GetLodIndexSquaredDistance(squareDistance);
					if ((*it)->GetLodIndex() == index)
					{
						(*it)->SetEnabled(true);

						if (index != mLastLodIndex)
						{
							ParticleUniverseEvent evt;
							evt.eventType = PU_EVT_LOD_TRANSITION;
							evt.componentType = CT_TECHNIQUE;
							evt.componentName = (*it)->GetName();
							evt.technique = *it;
							evt.emitter = 0;
							PushEvent(evt);
						}
						mLastLodIndex = index;
					}
					else
					{
						(*it)->SetEnabled(false);
					}
				}
			}

			(*it)->NotifyCurrentCamera(cam);
		}
	}

	const DiAABB& DiParticleSystem::GetBoundingBox(void) const
	{
		return m_kAABB;
	}
	
	void DiParticleSystem::CullingUpdate(DiRenderBatchGroup* g, DiCamera* c)
	{
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->UpdateBatchGroup(g,c);
		}
	}
	
	void DiParticleSystem::SetBatchGroup(DiBatchGroupType gt)
	{
		DiTransformUnit::SetBatchGroup(gt);

		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			// ʵ�����Ǹ�renderer����
			(*it)->SetBatchGroupID((uint8)gt);
		}
	}
	
	void DiParticleSystem::Update(float timeElapsed)
	{
		if (!m_pkParentNode)
		{
			return;
		}

		// Only update if the particle system is started or prepare the particle system before starting.
		if (m_eState == DiParticleSystem::PSS_STARTED)
		{
			if (mNonvisibleUpdateTimeoutSet)
			{
				long frameDiff = m_pkSceneManager->GetRenderWindow()->GetFrameNum() - mLastVisibleFrame;
				if (frameDiff > 1 || frameDiff < 0)
				{
					mTimeSinceLastVisible += timeElapsed;
					if (mTimeSinceLastVisible >= mNonvisibleUpdateTimeout)
					{
						return;
					}
				}
			}

			// Speedup or slowdown
			timeElapsed *= mParticleSystemScaleTime;

			// Only update the time since start if the DiParticleSystem is in the 'start' state.
			// Stop the DiParticleSystem if the fixed timeout has been reached (if applicable).
			mTimeElapsedSinceStart += timeElapsed;
			if (mFixedTimeoutSet)
			{
				if (mTimeElapsedSinceStart >= mFixedTimeout)
				{
					// ֹͣ����
					if (mStopFadeSet)
					{
						StopFade();
						mFixedTimeoutSet = false;
					}
					else
					{
						Stop();
						return;
					}
				}
			}

			// Update bound timer (if not auto updated)
			if (!mBoundsAutoUpdate && mBoundsUpdateTime > 0.0f)
			{
				mBoundsUpdateTime -= timeElapsed;
			}

			// Calculate rotation of the node
			CalulateRotationOffset();

			// Determine whether timeElapsed or iterationInterval is used
			size_t particlesLeft = 0;
			if (mIterationIntervalSet)
			{
				// Update time since last update
				mTimeSinceLastUpdate += timeElapsed;
				while (mTimeSinceLastUpdate >= mIterationInterval)
				{
					// Update all techniques using the iteration interval value
					particlesLeft = UpdateTechniques(mIterationInterval);
					mTimeSinceLastUpdate -= mIterationInterval;
				}
			}
			else
			{
				// Update all techniques using the time elapsed (since last frame)
				particlesLeft = UpdateTechniques(timeElapsed);
			}

			// Handle situation when no particles are emitted anymore
			if (particlesLeft == 0)
			{
				if (mAtLeastOneParticleEmitted)
				{
					// Generate the event
					PushSystemEvent(PU_EVT_NO_PARTICLES_LEFT);
					mAtLeastOneParticleEmitted = false;
				}

				// Determine whether the particle system should be stopped because of a fade out
				if (mStopFadeSet)
				{
					if (!mFixedTimeoutSet || (mFixedTimeoutSet && mTimeElapsedSinceStart >= mFixedTimeout))
					{
						Stop();
						return;
					}
				}
			}
			else
			{
				// At least one particle was emitted, so if 'particlesLef' becomes 0, it concerns the period after the last emitted particle.
				mAtLeastOneParticleEmitted = true;
			}
		}
		else if (m_eState == DiParticleSystem::PSS_PREPARED)
		{
			// Generate the event
			PushSystemEvent(PU_EVT_SYSTEM_PREPARING);

			// Prepare all techniques (perform some initialisation in advance)
			ParticleTechniqueIterator it;
			ParticleTechniqueIterator itEnd = m_kElements.end();
			for (it = m_kElements.begin(); it != itEnd; ++it)
			{
				(*it)->Prepare();
			}

			// Only do it once.
			m_eState = DiParticleSystem::PSS_STOPPED;

			// Generate the event
			PushSystemEvent(PU_EVT_SYSTEM_PREPARED);
		}
		else if (m_eState == DiParticleSystem::PSS_PAUSED)
		{
			// Determine whether there is a limit to the pause
			if (mPauseTimeSet)
			{
				mPauseTimeElapsed += timeElapsed;
				if (mPauseTimeElapsed > mPauseTime)
				{
					mPauseTimeElapsed = 0.0f;
					Resume();
				}
			}
		}

		// Set the latest position. This value is always needed, whether the Particle System is emitted or not.
		latestPosition = GetDerivedPosition();
		m_kLatestOrientation = GetDerivedOrientation();
	}
	
	size_t DiParticleSystem::UpdateTechniques(float timeElapsed)
	{
		/** Update all techniques if particle system is started (only if the techniques aren't emitted 
			themselves) and return the total number of emitted particles.
			Note, that emitted techniques are updated by the technique that is responsible for emitting 
			them. The technique that is emitting pooled techniques is also responsible to take the 
			(world)AABB of that pooled technique into account.
		*/
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		size_t particlesLeft = 0;
		bool mAABBUpdate = m_pkParentNode && (mBoundsAutoUpdate || mBoundsUpdateTime > 0.0f);
		bool merge = mAABBUpdate;
		DiAABB worldAABB(m_pkParentNode->GetDerivedPosition(), m_pkParentNode->GetDerivedPosition());
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			if (!(*it)->IsMarkedForEmission())
			{
				// Only call this if update bounds is needed.
				if (merge)
				{
					// Call NotifyUpdateBounds() for each Particle Technique, so the mWorldAABB in the 
					// DiParticleElement::_update() function is (re)calculated.
					(*it)->NotifyUpdateBounds();
				}

				// Always update the ParticleTechniques
				(*it)->Update(timeElapsed);

				// Merge worldAABB's of all ParticleTechniques
				if (merge)
				{
					// Get the WorldAABB from each technique and merge it with the worldAABB.
					worldAABB.Merge((*it)->GetWorldBoundingBox());

					// If worldAABB is infinite, ignore the other Particle Techniques.
					if (worldAABB.IsInfinite())
					{
						merge = false;
					}
				}

				// Count all left particles, used for anyone who needs it.
				particlesLeft += (*it)->GetNumberOfEmittedParticles();
			}
		}

		if (m_eState == DiParticleSystem::PSS_STOPPED)
		{
			/** Don't bother to update the mAABB, because the system is stopped in one of the techniques.
				The bounds must be reset, because even though the stop() has been called (which alread resets the
				bounds) another technique in the list might set the bounds again.
			*/
			ResetBounds();
		}
		else if (mAABBUpdate)
		{
			// If needed, update mAABB
			if (!worldAABB.IsNull())
			{
				if (mTightBoundingBox)
				{
					// Wrap the bounding box tight around the particle system
					m_kAABB = worldAABB;
					m_kAABB.TransformAffine(m_pkParentNode->GetFullTransform().inverseAffine());
				}
				else
				{
					// Merge with the current bounding box
					// Note, that the mAABB must in localspace, so transformation of the worldAABB is required.
					DiAABB newAABB(worldAABB);
					newAABB.TransformAffine(m_pkParentNode->GetFullTransform().inverseAffine());
	
					// Merge calculated box with current AABB.
					m_kAABB.Merge(newAABB);
				}
			}
			else
			{
				ResetBounds();
			}

			// Notify the parent node that the bounds are changed
			m_pkParentNode->NeedUpdate();
		}

		return particlesLeft;
	}
	
	void DiParticleSystem::ResetBounds(void)
	{
		// Reset the bounds to zero
		if (!m_kAABB.IsNull())
		{
			m_kAABB.SetNull();
		}
		if (m_pkParentNode)
		{
			m_pkParentNode->NeedUpdate();
		}
	}
	
	void DiParticleSystem::SetBoundsAutoUpdated(bool autoUpdate, float stopIn)
	{
		mBoundsAutoUpdate = autoUpdate;
		mBoundsUpdateTime = stopIn;
		mOriginalBoundsUpdateTime = stopIn;
	}
	
	const DiVec3& DiParticleSystem::GetScale(void) const
	{
		return m_kParticleSystemScale;
	}
	
	void DiParticleSystem::SetScale(const DiVec3& scale)
	{
		// Set the scale and notify the particle techniques
		m_kParticleSystemScale = scale;
		NotifyRescaled();
	}
	
	void DiParticleSystem::NotifyRescaled(void)
	{
		// Notify the particle techniques
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->NotifyRescaled(m_kParticleSystemScale);
		}
	}
	
	const float& DiParticleSystem::GetScaleVelocity(void) const
	{
		return m_kParticleSystemScaleVelocity;
	}
	
	void DiParticleSystem::SetScaleVelocity(const float& scaleVelocity)
	{
		// Set the scale and notify the particle techniques
		m_kParticleSystemScaleVelocity = scaleVelocity;
		NotifyVelocityRescaled();
	}
	
	void DiParticleSystem::NotifyVelocityRescaled(void)
	{
		// Notify the particle techniques
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->NotifyVelocityRescaled(m_kParticleSystemScaleVelocity);
		}
	}
	
	const float& DiParticleSystem::GetScaleTime(void) const
	{
		return mParticleSystemScaleTime;
	}
	
	void DiParticleSystem::SetScaleTime(const float& scaleTime)
	{
		mParticleSystemScaleTime = scaleTime;
	}
	
	void DiParticleSystem::InitForEmission(void)
	{
		DiParticle::InitForEmission();

		Start();
	}
	
	void DiParticleSystem::InitForExpiration(DiParticleElement* technique, float timeElapsed)
	{
		DiParticle::InitForExpiration(technique, timeElapsed);

		Stop();
	}
	
	void DiParticleSystem::Process(DiParticleElement* technique, float timeElapsed)
	{
		// Inherited from the Particle class and is only called if the Particle System is emitted.
		// Update node position.
		DiParticle::Process(technique, timeElapsed);
		DiNode* node = technique->GetParentSystem()->GetParentNode();
		if (m_pkParentNode && node)
		{
			// position attribute is derived, but the the parentNode position must be set in relation to its parent.
			m_pkParentNode->SetPosition(position - node->GetPosition());
		}
	}
	
	const float DiParticleSystem::GetNonVisibleUpdateTimeout(void) const
	{
		return mNonvisibleUpdateTimeout;
	}
	
	void DiParticleSystem::SetNonVisibleUpdateTimeout(float timeout)
	{
		if (timeout > 0)
		{
			mNonvisibleUpdateTimeout = timeout;
			mNonvisibleUpdateTimeoutSet = true;
		}
		else
		{
			mNonvisibleUpdateTimeout = 0;
			mNonvisibleUpdateTimeoutSet = false;
		}
	}
	
	const DiParticleSystem::LodDistanceList& DiParticleSystem::GetLodDistances(void) const
	{
		return mLodDistanceList;
	}

	void DiParticleSystem::ClearLodDistances(void)
	{
		mLodDistanceList.clear();
	}
	
	void DiParticleSystem::AddLodDistance(float distance)
	{
		mLodDistanceList.push_back(distance * distance);
	}
	
	void DiParticleSystem::SetLodDistances(const LodDistanceList& lodDistances)
	{
		LodDistanceConstIterator it, itEnd;
		itEnd = lodDistances.end();
		mLodDistanceList.clear();
		for (it = lodDistances.begin(); it != itEnd; ++it)
		{
			mLodDistanceList.push_back((*it) * (*it));
		}
	}
	
	unsigned short DiParticleSystem::GetLodIndex(float distance) const
	{
		return GetLodIndexSquaredDistance(distance * distance);
	}
	
	unsigned short DiParticleSystem::GetLodIndexSquaredDistance(float squaredDistance) const
	{
		LodDistanceConstIterator it, itEnd;
		itEnd = mLodDistanceList.end();
		unsigned short index = 0;
		for (it = mLodDistanceList.begin(); it != itEnd; ++it, ++index)
		{
			if (squaredDistance < (*it))
			{
				return index;
			}
		}

		return static_cast<unsigned short>(mLodDistanceList.size());
	}
	
	size_t DiParticleSystem::GetNumEmittedTechniques (void) const
	{
		ParticleTechniqueConstIterator it;
		ParticleTechniqueConstIterator itEnd = m_kElements.end();
		size_t count = 0;
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			if ((*it)->IsMarkedForEmission())
			{
				count++;
			}
		}

		return count;
	}
	
	void DiParticleSystem::MarkForEmission(void)
	{
		// Reset the marks on all techniques.
		ResetMarkForEmission();

		/** Force techniques to be enabled to mark the emitted objects. Do this first for all techniques, before
			the techniques perform their marking. The reason for this is, that one technique might mark 
			another technique.
		*/
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->SuppressNotifyEmissionChange(false);
		}

		// Mark the emitted objects.
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->MarkForEmission();
		}
	}
	
	void DiParticleSystem::ResetMarkForEmission(void)
	{
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->SetMarkedForEmission(false);
		}
	}
	
	void DiParticleSystem::SuppressNotifyEmissionChange(bool suppress)
	{
		mSuppressNotifyEmissionChange = suppress;
	}
	
	void DiParticleSystem::NotifyEmissionChange(void)
	{
		if (mSuppressNotifyEmissionChange)
		{
			return;
		}

		// Mark all emitted techniques, which on their turn mark other techniques, emitters and affectors.
		MarkForEmission();
	}
	
	const float DiParticleSystem::GetIterationInterval(void) const
	{
		return mIterationInterval;
	}
	
	void DiParticleSystem::SetIterationInterval(const float iterationInterval)
	{
		if (iterationInterval > 0)
		{
			mIterationInterval = iterationInterval;
			mIterationIntervalSet = true;
		}
		else
		{
			mIterationInterval = 0;
			mIterationIntervalSet = false;
		}
	}
	
	const float DiParticleSystem::GetFixedTimeout(void) const
	{
		return mFixedTimeout;
	}
	
	void DiParticleSystem::SetFixedTimeout(const float fixedTimeout)
	{
		if (fixedTimeout > 0.0f)
		{
			mFixedTimeout = fixedTimeout;
			mFixedTimeoutSet = true;
		}
		else
		{
			mFixedTimeout = 0.0f;
			mFixedTimeoutSet = false;
		}
	}
	
	void DiParticleSystem::Prepare (void)
	{
		m_eState = DiParticleSystem::PSS_PREPARED;
	}
	
	void DiParticleSystem::Start(void)
	{
		PushSystemEvent(PU_EVT_SYSTEM_STARTING);

		SetVisible(true);
		m_eState = DiParticleSystem::PSS_STARTED;
		mTimeElapsedSinceStart = 0;
		mLastVisibleFrame = 0;
		mTimeSinceLastVisible = 0;
		mTimeSinceLastUpdate = 0;
		mBoundsUpdateTime = mOriginalBoundsUpdateTime;
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		m_kAABB.SetExtents(0, 0, 0, 0, 0, 0);
		m_bFastForwardSet = m_bOriginalFastForwardSet;
		position = DiVec3::ZERO;
		m_kDerivedPosition = DiVec3::ZERO;
		latestPosition = GetDerivedPosition();
		m_kLatestOrientation = GetDerivedOrientation();
		m_bEnabled = true;
		mStopFadeSet = false;
		mAtLeastOneParticleEmitted = false;
		mLastLodIndex = 0;

		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			(*it)->NotifyStart();
		}
		
		FastForward();

		PushSystemEvent(PU_EVT_SYSTEM_STARTED);
	}
	
	void DiParticleSystem::Start(float stopTime)
	{
		Start();
		Stop(stopTime);
	}
	
	void DiParticleSystem::StartAndStopFade(float stopTime)
	{
		Start();
		StopFade(stopTime);
	}
	
	void DiParticleSystem::Stop(void)
	{
		/*  Note, that the DiParticleSystem isn't visible anymore, but it is still attached to the
			node and still consumes resources, but it allows fast start/stop iterations if needed.
			An important thing why it keeps attached to the node is that attaching and detaching the 
			DiParticleSystem to/from a node must be done outside of the DiParticleSystem. If the DiParticleSystem
			isn't used anymore you have to detach it from the node yourself.
		*/
		if (m_eState != DiParticleSystem::PSS_STOPPED)
		{
			// Generate the event
			PushSystemEvent(PU_EVT_SYSTEM_STOPPING);

			/** Notify all techniques to stop.
			*/
			SetVisible(false); // Set this movable to invisible
			ParticleTechniqueIterator it;
			ParticleTechniqueIterator itEnd = m_kElements.end();
			for (it = m_kElements.begin(); it != itEnd; ++it)
			{
				(*it)->NotifyStop();
			}

			ResetBounds();
			m_eState = DiParticleSystem::PSS_STOPPED;

			mStopFadeSet = false;
			m_bEnabled = false;

			// Generate the event
			PushSystemEvent(PU_EVT_SYSTEM_STOPPED);
		}
	}
	
	void DiParticleSystem::Stop(float stopTime)
	{
		SetFixedTimeout(stopTime);
	}
	
	void DiParticleSystem::StopFade(void)
	{
		size_t i;
		size_t j;
		size_t numTechniques = GetNumElements();
		size_t numEmitters;
		DiParticleElement* technique;
		DiParticleEmitter* emitter;
		for (i = 0; i < numTechniques; ++i)
		{
			technique = GetElement(i);
			numEmitters = GetElement(i)->GetNumEmitters();
			for (j = 0; j < numEmitters; ++j)
			{
				emitter = technique->GetEmitter(j);
				emitter->SetEnabled(false);
			}
		}
		mStopFadeSet = true;
	}
	
	void DiParticleSystem::StopFade(float stopTime)
	{
		SetFixedTimeout(stopTime);
		mStopFadeSet = true;
	}
	
	void DiParticleSystem::Pause(void)
	{
		if (m_eState != DiParticleSystem::PSS_STOPPED)
		{
			PushSystemEvent(PU_EVT_SYSTEM_PAUSING);

			m_eState = DiParticleSystem::PSS_PAUSED;

			ParticleTechniqueIterator it;
			ParticleTechniqueIterator itEnd = m_kElements.end();
			for (it = m_kElements.begin(); it != itEnd; ++it)
			{
				(*it)->NotifyPause();
			}
		}

		PushSystemEvent(PU_EVT_SYSTEM_PAUSED);
	}
	
	void DiParticleSystem::Pause(float pauseTime)
	{
		Pause();
		SetPauseTime(pauseTime);
	}
	
	void DiParticleSystem::Resume(void)
	{
		if (m_eState != DiParticleSystem::PSS_STOPPED)
		{
			PushSystemEvent(PU_EVT_SYSTEM_RESUMING);

			m_eState = DiParticleSystem::PSS_STARTED;

			ParticleTechniqueIterator it;
			ParticleTechniqueIterator itEnd = m_kElements.end();
			for (it = m_kElements.begin(); it != itEnd; ++it)
			{
				(*it)->NotifyResume();
			}

			PushSystemEvent(PU_EVT_SYSTEM_RESUMED);
		}
	}
	
	size_t DiParticleSystem::GetNumberOfEmittedParticles(void)
	{
		size_t total = 0;
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			total += (*it)->GetNumberOfEmittedParticles();
		}
		return total;
	}
	
	size_t DiParticleSystem::GetNumberOfEmittedParticles(DiParticle::ParticleType particleType)
	{
		size_t total = 0;
		ParticleTechniqueIterator it;
		ParticleTechniqueIterator itEnd = m_kElements.end();
		for (it = m_kElements.begin(); it != itEnd; ++it)
		{
			total += (*it)->GetNumberOfEmittedParticles(particleType);
		}
		return total;
	}

	DiEffectManager* DiParticleSystem::GetEffectManager()
	{
		return m_pkSceneManager->GetEffectManager();
	}

	DiString& DiParticleSystem::GetType()
	{
		static DiString type = "Particle";
		return type;
	}
}


