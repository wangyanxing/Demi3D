
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "RotationSpline.h"

namespace Demi
{
	RotationalSpline::RotationalSpline()
		: m_bAutoCalc(true)
	{
	}
	
	RotationalSpline::~RotationalSpline()
	{
	}
	
	void RotationalSpline::AddPoint(const DiQuat& p)
	{
		m_kPoints.push_back(p);
		if (m_bAutoCalc)
		{
			RecalcTangents();
		}
	}
	
	DiQuat RotationalSpline::Interpolate(float t, bool useShortestPath)
	{
		float fSeg = t * (m_kPoints.size() - 1);
		unsigned int segIdx = (unsigned int)fSeg;
		t = fSeg - segIdx;

		return Interpolate(segIdx, t, useShortestPath);
	}
	
	DiQuat RotationalSpline::Interpolate(unsigned int fromIndex, float t,
		bool useShortestPath)
	{
		Assert (fromIndex >= 0 && fromIndex < m_kPoints.size());

		if ((fromIndex + 1) == m_kPoints.size())
		{
			return m_kPoints[fromIndex];

		}
		if (t == 0.0f)
		{
			return m_kPoints[fromIndex];
		}
		else if(t == 1.0f)
		{
			return m_kPoints[fromIndex + 1];
		}

		DiQuat &p = m_kPoints[fromIndex];
		DiQuat &q = m_kPoints[fromIndex+1];
		DiQuat &a = m_kTangents[fromIndex];
		DiQuat &b = m_kTangents[fromIndex+1];

		return DiQuat::Squad(t, p, a, b, q, useShortestPath);

	}
	
	void RotationalSpline::RecalcTangents(void)
	{
		unsigned int i, numPoints;
		bool isClosed;

		numPoints = (unsigned int)m_kPoints.size();

		if (numPoints < 2)
		{
			return;
		}

		m_kTangents.resize(numPoints);

		if (m_kPoints[0] == m_kPoints[numPoints-1])
		{
			isClosed = true;
		}
		else
		{
			isClosed = false;
		}

		DiQuat invp, part1, part2, preExp;
		for(i = 0; i < numPoints; ++i)
		{
			DiQuat &p = m_kPoints[i];
			invp = p.Inverse();

			if (i ==0)
			{
				part1 = (invp * m_kPoints[i+1]).Log();
				if (isClosed)
				{
					part2 = (invp * m_kPoints[numPoints-2]).Log();
				}
				else
				{
					part2 = (invp * p).Log();
				}
			}
			else if (i == numPoints-1)
			{
				if (isClosed)
				{
					part1 = (invp * m_kPoints[1]).Log();
				}
				else
				{
					part1 = (invp * p).Log();
				}
				part2 = (invp * m_kPoints[i-1]).Log();
			}
			else
			{
				part1 = (invp * m_kPoints[i+1]).Log();
				part2 = (invp * m_kPoints[i-1]).Log();
			}

			preExp = -0.25 * (part1 + part2);
			m_kTangents[i] = p * preExp.Exp();
		}
	}
	
	const DiQuat& RotationalSpline::GetPoint(unsigned short index) const
	{
		Assert (index < m_kPoints.size());

		return m_kPoints[index];
	}
	
	unsigned short RotationalSpline::GetNumPoints(void) const
	{
		return (unsigned short)m_kPoints.size();
	}
	
	void RotationalSpline::Clear(void)
	{
		m_kPoints.clear();
		m_kTangents.clear();
	}
	
	void RotationalSpline::UpdatePoint(unsigned short index, const DiQuat& value)
	{
		Assert (index < m_kPoints.size());

		m_kPoints[index] = value;
		if (m_bAutoCalc)
		{
			RecalcTangents();
		}
	}
	
	void RotationalSpline::SetAutoCalculate(bool autoCalc)
	{
		m_bAutoCalc = autoCalc;
	}
}

