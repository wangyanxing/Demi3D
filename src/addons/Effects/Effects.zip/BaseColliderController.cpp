
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "BaseColliderController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const float DiBaseColliderController::DEFAULT_BOUNCYNESS = 1.0f;
	const float DiBaseColliderController::DEFAULT_FRICTION = 0.0f;
	const DiBaseColliderController::IntersectionType DiBaseColliderController::DEFAULT_INTERSECTION_TYPE = DiBaseColliderController::IT_POINT;
	const DiBaseColliderController::CollisionType DiBaseColliderController::DEFAULT_COLLISION_TYPE = DiBaseColliderController::CT_BOUNCE;

	DiBaseColliderController::DiBaseColliderController(void) :
		DiParticleController(),
		m_fBouncyness(DEFAULT_BOUNCYNESS),
		m_fFriction(DEFAULT_FRICTION),
		m_eIntersectionType(DEFAULT_INTERSECTION_TYPE),
		m_eCollisionType(DEFAULT_COLLISION_TYPE),
		m_fVelocityScale(1.0f)
	{
	}
	
	void DiBaseColliderController::PreProcessParticles(DiParticleElement* particleTechnique, float timeElapsed)
	{
		m_fVelocityScale = 1.0f;
		if (m_pkParentElement)
		{
			m_fVelocityScale = timeElapsed * m_pkParentElement->GetParticleSystemScaleVelocity();
		}
	}
	
	const DiBaseColliderController::IntersectionType DiBaseColliderController::GetIntersectionType(void) const
	{
		return m_eIntersectionType;
	}
	
	void DiBaseColliderController::SetIntersectionType(const DiBaseColliderController::IntersectionType& intersectionType)
	{
		m_eIntersectionType = intersectionType;
	}
	
	const DiBaseColliderController::CollisionType DiBaseColliderController::GetCollisionType(void) const
	{
		return m_eCollisionType;
	}
	
	void DiBaseColliderController::SetCollisionType(const DiBaseColliderController::CollisionType& collisionType)
	{
		m_eCollisionType = collisionType;
	}
	
	const float DiBaseColliderController::GetFriction(void) const
	{
		return m_fFriction;
	}
	
	void DiBaseColliderController::SetFriction(const float friction)
	{
		m_fFriction = friction;
	}
	
	const float DiBaseColliderController::GetBouncyness(void) const
	{
		return m_fBouncyness;
	}
	
	void DiBaseColliderController::SetBouncyness(const float bouncyness)
	{
		m_fBouncyness = bouncyness;
	}
	
	void DiBaseColliderController::PopulateAlignedBox(DiAABB& box,
		const DiVec3& position, 
		const float width,
		const float height,
		const float depth)
	{
		float halfWidth = 0.5f * width;
		float halfHeight = 0.5f * height;
		float halfDepth = 0.5f * depth;
		box.SetMinimum(position.x - halfWidth, 
			position.y - halfHeight, 
			position.z - halfDepth);
		box.SetMaximum(position.x + halfWidth, 
			position.y + halfHeight, 
			position.z + halfDepth);
	}
	
	void DiBaseColliderController::CalculateRotationSpeedAfterCollision(DiParticle* particle)
	{
		if (particle->particleType != DiParticle::PT_VISUAL)
			return;

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		float signedFriction = DiMath::UnitRandom() > 0.5 ? -(m_fFriction - 1) : (m_fFriction - 1);
		visualParticle->rotationSpeed *= signedFriction;
		visualParticle->zRotationSpeed *= signedFriction;
	}
	
	void DiBaseColliderController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiBaseColliderController* baseCollider = static_cast<DiBaseColliderController*>(affector);
		baseCollider->m_fBouncyness = m_fBouncyness;
		baseCollider->m_fFriction = m_fFriction;
		baseCollider->m_eIntersectionType = m_eIntersectionType;
		baseCollider->m_eCollisionType = m_eCollisionType;
	}
}

