
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "CircleEmitter.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"

namespace Demi
{
	const float 	DiCircleEmitter::DEFAULT_RADIUS = 100.0f;
	const float 	DiCircleEmitter::DEFAULT_STEP = 0.1f;
	const float 	DiCircleEmitter::DEFAULT_ANGLE = 0.0f;
	const bool		DiCircleEmitter::DEFAULT_RANDOM = true;
	const DiVec3	DiCircleEmitter::DEFAULT_NORMAL = DiVec3::ZERO;

	
	DiCircleEmitter::DiCircleEmitter(void) : 
		DiParticleEmitter(),
		m_fRadius(DEFAULT_RADIUS),
		m_fCircleAngle(DEFAULT_ANGLE),
		m_fOriginalCircleAngle(DEFAULT_ANGLE),
		m_fStep(DEFAULT_STEP),
		m_bRandom(DEFAULT_RANDOM),
		m_kOrientation(DiQuat::IDENTITY),
		m_kNormal(DEFAULT_NORMAL),
		m_fX(0.0f),
		m_fZ(0.0f)
	{
	}
	
	const float DiCircleEmitter::GetRadius(void) const
	{
		return m_fRadius;
	}
	
	void DiCircleEmitter::SetRadius(const float radius)
	{
		m_fRadius = radius;
	}
	
	const float DiCircleEmitter::GetCircleAngle(void) const
	{
		return m_fOriginalCircleAngle;
	}
	
	void DiCircleEmitter::SetCircleAngle(const float circleAngle)
	{
		m_fOriginalCircleAngle = circleAngle;
		m_fCircleAngle = circleAngle;
	}
	
	const float DiCircleEmitter::GetStep(void) const
	{
		return m_fStep;
	}
	
	void DiCircleEmitter::SetStep(const float step)
	{
		m_fStep = step;
	}
	
	const bool DiCircleEmitter::IsRandom(void) const
	{
		return m_bRandom;
	}
	
	void DiCircleEmitter::SetRandom(const bool random)
	{
		m_bRandom = random;
	}
	
	const DiQuat& DiCircleEmitter::GetOrientation(void) const
	{
		return m_kOrientation;
	}
	 
	const DiVec3& DiCircleEmitter::GetNormal(void) const
	{ 
		return m_kNormal;
	} 
	 
	void DiCircleEmitter::SetNormal(const DiVec3& normal) 
	{ 
		m_kOrientation = DiVec3::UNIT_Y.getRotationTo(normal, DiVec3::UNIT_X);
		m_kNormal = normal;
	}
	
	void DiCircleEmitter::NotifyStart (void)
	{
		m_fCircleAngle = m_fOriginalCircleAngle;
	}
	 
	void DiCircleEmitter::InitParticlePosition(DiParticle* particle)
	{
		float angle = 0;
		if (m_bRandom)
		{
			angle = DiMath::RangeRandom(0, DiMath::TWO_PI);
		}
		else
		{
			m_fCircleAngle += m_fStep;
			m_fCircleAngle = m_fCircleAngle > DiMath::TWO_PI ? m_fCircleAngle - DiMath::TWO_PI : m_fCircleAngle;
			angle = m_fCircleAngle;
		}

		m_fX = DiMath::Cos(angle);
		m_fZ = DiMath::Sin(angle);
		DiParticleSystem* sys = m_pkParentElement->GetParentSystem();
		if (sys)
		{
			particle->position = GetDerivedPosition() + 
				sys->GetDerivedOrientation() * m_kOrientation * (m_kEmitterScale * DiVec3(m_fX * m_fRadius, 0, m_fZ * m_fRadius));
		}
		else
		{
			particle->position = GetDerivedPosition() + m_kEmitterScale * ( m_kOrientation * DiVec3(m_fX * m_fRadius, 0, m_fZ * m_fRadius) );
		}
		particle->originalPosition = particle->position;
	}
	
	void DiCircleEmitter::InitParticleDirection(DiParticle* particle)
	{
		if (m_bAutoDirection)
		{
			DiRadian angle;
			GenerateAngle(angle);
			if (angle != DiRadian(0))
			{
				particle->direction = (m_kOrientation * DiVec3(m_fX, 0, m_fZ) ).randomDeviant(angle, m_kUpVector);
				particle->originalDirection = particle->direction;
			}
			else
			{
				particle->direction = DiVec3(m_fX, 0, m_fZ);
				particle->direction = m_kOrientation * DiVec3(m_fX, 0, m_fZ);
			}
		}
		else
		{
			DiParticleEmitter::InitParticleDirection(particle);
		}
	}
	
	void DiCircleEmitter::CopyTo (DiParticleEmitter* emitter)
	{
		DiParticleEmitter::CopyTo(emitter);

		DiCircleEmitter* circleEmitter = static_cast<DiCircleEmitter*>(emitter);
		circleEmitter->m_fRadius = m_fRadius;
		circleEmitter->m_fCircleAngle = m_fCircleAngle;
		circleEmitter->m_fOriginalCircleAngle = m_fOriginalCircleAngle;
		circleEmitter->m_fStep = m_fStep;
		circleEmitter->m_bRandom = m_bRandom;
		circleEmitter->m_kNormal = m_kNormal;
		circleEmitter->m_kOrientation = m_kOrientation; 
	}
}

