
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ParticleRenderer.h"
#include "RenderBatchGroup.h"

namespace Demi
{
	const uint8 DiParticleRenderer::DEFAULT_RENDER_QUEUE_GROUP = BATCH_EFFECT;
	const bool DiParticleRenderer::DEFAULT_SORTED = false;
	const UCHAR DiParticleRenderer::DEFAULT_TEXTURECOORDS_ROWS = 1;
	const UCHAR DiParticleRenderer::DEFAULT_TEXTURECOORDS_COLUMNS = 1;
	const bool DiParticleRenderer::DEFAULT_USE_SOFT_PARTICLES = false;
	const float DiParticleRenderer::DEFAULT_SOFT_PARTICLES_CONTRAST_POWER = 0.8f;
	const float DiParticleRenderer::DEFAULT_SOFT_PARTICLES_SCALE = 1.0f;
	const float DiParticleRenderer::DEFAULT_SOFT_PARTICLES_DELTA = -1.0f;
	const DiString SOFT_PREFIX = "NewSoft_";

	
	DiParticleRenderer::DiParticleRenderer(void) : 
		m_pkParentTechnique(0),
		m_bCullIndividual(false),
		m_fHeight(100),
		m_fWidth(100),
		m_fDepth(100),
		m_bSorted(DEFAULT_SORTED),
		m_ucQueueId(DEFAULT_RENDER_QUEUE_GROUP),
		m_bRendererInitialised(false),
		m_kRendererScale(DiVec3::UNIT_SCALE),
		m_ucTextureCoordsRows(DEFAULT_TEXTURECOORDS_ROWS),
		m_ucTextureCoordsColumns(DEFAULT_TEXTURECOORDS_COLUMNS),
		m_bTextureCoordsSet(false),
		m_bUseSoftParticles(DEFAULT_USE_SOFT_PARTICLES),
		m_fSoftParticlesContrastPower(DEFAULT_SOFT_PARTICLES_CONTRAST_POWER),
		m_fSoftParticlesScale(DEFAULT_SOFT_PARTICLES_SCALE),
		m_fSoftParticlesDelta(DEFAULT_SOFT_PARTICLES_DELTA),
		m_bNotifiedDepthMap(false),
		m_bTextureCoordsRowsAndColumnsSet(false),
		m_bVisible(true)
	{
	}
	
	DiParticleRenderer::~DiParticleRenderer(void)
	{
		DiVector<DiFloatRect*>::iterator it;
		DiVector<DiFloatRect*>::iterator itEnd = m_kUVList.end();
		for (it = m_kUVList.begin(); it != itEnd; ++it)
		{
			delete *it;
		}

		if (m_bUseSoftParticles)
		{
			//ParticleSystemManager::getSingleton().unregisterSoftParticlesRenderer(this);
		}
	}
	
	void DiParticleRenderer::NotifyStart(void)
	{
		SetVisible(true);
	}
	
	void DiParticleRenderer::NotifyStop(void)
	{
		SetVisible(false);
	}
	
	const DiString& DiParticleRenderer::GetRendererType(void) const
	{
		return m_kRendererType;
	}
	
	void DiParticleRenderer::SetRendererType(DiString rendererType)
	{
		m_kRendererType = rendererType;
	}
	
	DiParticleElement* DiParticleRenderer::GetParentElement(void) const
	{
		return m_pkParentTechnique;
	}
	
	void DiParticleRenderer::SetParentElement(DiParticleElement* parentTechnique)
	{
		m_pkParentTechnique = parentTechnique;
	}
	
	bool DiParticleRenderer::IsRendererInitialised(void) const
	{
		return m_bRendererInitialised;
	}
	
	void DiParticleRenderer::SetRendererInitialised(bool rendererInitialised)
	{
		m_bRendererInitialised = rendererInitialised;
	}
	
	uint8 DiParticleRenderer::GetBatchGroupID(void) const
	{
		return m_ucQueueId;
	}
	
	void DiParticleRenderer::SetBatchGroupID(uint8 queueId)
	{
		m_ucQueueId = queueId;
	}
	
	const bool DiParticleRenderer::IsSorted(void) const
	{
		return m_bSorted;
	}
	
	void DiParticleRenderer::SetSorted(bool sorted)
	{
		m_bSorted = sorted;
	}
	
	const UCHAR DiParticleRenderer::GetTextureCoordsRows(void) const
	{
		return m_ucTextureCoordsRows;
	}
	
	void DiParticleRenderer::SetTextureCoordsRows(UCHAR const textureCoordsRows)
	{
		m_ucTextureCoordsRows = textureCoordsRows;
		m_bTextureCoordsRowsAndColumnsSet = true;
	}
	
	const UCHAR DiParticleRenderer::GetTextureCoordsColumns(void) const
	{
		return m_ucTextureCoordsColumns;
	}
	
	void DiParticleRenderer::SetTextureCoordsColumns(UCHAR const textureCoordsColumns)
	{
		m_ucTextureCoordsColumns = textureCoordsColumns;
		m_bTextureCoordsRowsAndColumnsSet = true;
	}
	
	size_t DiParticleRenderer::GetNumTextureCoords(void)
	{
		if (m_bTextureCoordsRowsAndColumnsSet)
		{
			return m_ucTextureCoordsRows * m_ucTextureCoordsColumns;
		}
		else
		{
			return m_kUVList.size();
		}
	}
	
	void DiParticleRenderer::NotifyRescaled(const DiVec3& scale)
	{
		m_kRendererScale = scale;
	}
	
	void DiParticleRenderer::AddTextureCoords(const float u, 
		const float v, 
		const float width, 
		const float height)
	{
		m_kUVList.push_back(new DiFloatRect(u, v, u+width, v+height));
		m_bTextureCoordsSet = true;
	}
	
	const DiVector<DiFloatRect*>& DiParticleRenderer::GetTextureCoords(void) const
	{
		return m_kUVList;
	}
	
	void DiParticleRenderer::UpdateBatchGroup(DiRenderBatchGroup*, DiCamera*, DiParticlePool*)
	{
		// TODO: soft particle
	}
	
	bool DiParticleRenderer::GetUseSoftParticles(void) const
	{
		return m_bUseSoftParticles;
	}
	
	void DiParticleRenderer::SetUseSoftParticles(bool useSoftParticles)
	{
		m_bUseSoftParticles = useSoftParticles;
		if (!m_bUseSoftParticles)
		{
			
		}
	}
	
	void DiParticleRenderer::StripNameFromSoftPrefix(DiString& name)
	{
// 		if (name.find(SOFT_PREFIX) != DiString::npos)
// 		{
// 			name.erase(0, SOFT_PREFIX.length());
// 		}
	}
	
	float DiParticleRenderer::GetSoftParticlesContrastPower(void) const
	{
		return m_fSoftParticlesContrastPower;
	}
	
	float DiParticleRenderer::GetSoftParticlesScale(void) const
	{
		return m_fSoftParticlesScale;
	}
	
	float DiParticleRenderer::GetSoftParticlesDelta(void) const
	{
		return m_fSoftParticlesDelta;
	}
	
	void DiParticleRenderer::SetSoftParticlesContrastPower(float softParticlesContrastPower)
	{
		
	}
	
	void DiParticleRenderer::SetSoftParticlesScale(float softParticlesScale)
	{
		
	}
	
	void DiParticleRenderer::SetSoftParticlesDelta(float softParticlesDelta)
	{
		
	}
	
	void DiParticleRenderer::CreateSoftMaterial(void)
	{
		
	}
	
	void DiParticleRenderer::CopyTo (DiParticleRenderer* renderer)
	{
		CopyParentTo(renderer);
	}
	
	void DiParticleRenderer::CopyParentTo (DiParticleRenderer* renderer)
	{
		renderer->SetBatchGroupID(m_ucQueueId);
		renderer->SetSorted(m_bSorted);
		renderer->m_ucTextureCoordsRows = m_ucTextureCoordsRows;
		renderer->m_ucTextureCoordsColumns = m_ucTextureCoordsColumns;
		renderer->m_bTextureCoordsRowsAndColumnsSet = m_bTextureCoordsRowsAndColumnsSet;
		renderer->m_bTextureCoordsSet = m_bTextureCoordsSet;
		renderer->m_bUseSoftParticles = m_bUseSoftParticles;
		renderer->m_fSoftParticlesContrastPower = m_fSoftParticlesContrastPower;
		renderer->m_fSoftParticlesScale = m_fSoftParticlesScale;
		renderer->m_fSoftParticlesDelta = m_fSoftParticlesDelta;
		renderer->m_bNotifiedDepthMap = m_bNotifiedDepthMap;
		renderer->m_kRendererScale = m_kRendererScale;

		if (m_kUVList.empty())
		{
			return;
		}
		DiVector<DiFloatRect*>::iterator it;
		DiVector<DiFloatRect*>::iterator itEnd = m_kUVList.end();
		for (it = m_kUVList.begin(); it != itEnd; ++it)
		{
			renderer->AddTextureCoords((*it)->left, (*it)->top, (*it)->Width(), (*it)->Height());
		}

	}
}

