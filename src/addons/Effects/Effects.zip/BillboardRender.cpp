
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "BillboardRender.h"
#include "Billboard.h"
#include "VisualParticle.h"
#include "ParticlePool.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"
#include "RenderBatchGroup.h"

#pragma warning(disable:4706)

namespace Demi
{
	const BillboardType			DiBillboardRenderer::DEFAULT_BILLBOARD_TYPE = BBT_POINT;
	const bool					DiBillboardRenderer::DEFAULT_ACCURATE_FACING = false;
	const BillboardOrigin		DiBillboardRenderer::DEFAULT_ORIGIN = BBO_CENTER;
	const BillboardRotationType	DiBillboardRenderer::DEFAULT_ROTATION_TYPE = BBR_TEXCOORD;
	const DiVec3 				DiBillboardRenderer::DEFAULT_COMMON_DIRECTION = DiVec3::UNIT_Z;
	const DiVec3 				DiBillboardRenderer::DEFAULT_COMMON_UP_VECTOR = DiVec3::UNIT_Y;
	const bool					DiBillboardRenderer::DEFAULT_POINT_RENDERING = false;

	
	DiBillboardRenderer::DiBillboardRenderer(void) : 
		DiParticleRenderer(),
		m_eBillboardType(DEFAULT_BILLBOARD_TYPE)
	{
		m_pkBillboardSet = DI_NEW DiBillboardSet("", 0, true);
		m_pkBillboardSet->SetBillboardsInWorldSpace(true);
		autoRotate = false;
	}
	
	DiBillboardRenderer::~DiBillboardRenderer(void)
	{
		SAFE_DELETE(m_pkBillboardSet);
	}
	
	void DiBillboardRenderer::Prepare(DiParticleElement* element)
	{
		if (!element || m_bRendererInitialised)
		{
			return;
		}

		NotifyParticleQuota(element->GetVisualParticleQuota());

		if (element->GetParentSystem()->GetParentNode())
		{		
			NotifyAttached(element->GetParentSystem()->GetParentNode());
		}
		NotifyDefaultDimensions(m_kRendererScale.x * element->GetDefaultWidth(),
			m_kRendererScale.y * element->GetDefaultHeight(),
			m_kRendererScale.z * element->GetDefaultDepth());
		SetMaterialName(element->GetMaterialName());
		m_pkBillboardSet->SetBatchGroup((DiBatchGroupType)m_ucQueueId);

		if (m_bTextureCoordsSet)
		{
			m_pkBillboardSet->SetTextureCoords(*m_kUVList.begin(), static_cast<uint16>(m_kUVList.size()));
		}
		else if (m_bTextureCoordsRowsAndColumnsSet)
		{
			m_pkBillboardSet->SetTextureStacksAndSlices(m_ucTextureCoordsRows, m_ucTextureCoordsColumns);
		}

		m_bRendererInitialised = true;
	}
	
	void DiBillboardRenderer::Unprepare(DiParticleElement*)
	{
	}
	
	void DiBillboardRenderer::SetBillboardType(BillboardType bbt)
	{
		m_eBillboardType = bbt;
		m_pkBillboardSet->SetBillboardType(bbt);
	}
	
	BillboardType DiBillboardRenderer::GetBillboardType(void) const
	{
		return m_eBillboardType;
	}
	
	void DiBillboardRenderer::SetBillboardRotationType(BillboardRotationType rotationType)
	{
		m_pkBillboardSet->SetBillboardRotationType(rotationType);
	}
	
	BillboardRotationType DiBillboardRenderer::GetBillboardRotationType(void) const
	{
		return m_pkBillboardSet->GetBillboardRotationType();
	}
	
	void DiBillboardRenderer::SetCommonDirection(const DiVec3& vec)
	{
		m_pkBillboardSet->SetCommonDirection(vec);
	}
	
	const DiVec3& DiBillboardRenderer::GetCommonDirection(void) const
	{
		return m_pkBillboardSet->GetCommonDirection();
	}
	
	void DiBillboardRenderer::SetCommonUpVector(const DiVec3& vec)
	{
		m_pkBillboardSet->SetCommonUpVector(vec);
	}
	
	const DiVec3& DiBillboardRenderer::GetCommonUpVector(void) const
	{
		return m_pkBillboardSet->GetCommonUpVector();
	}
	
	void DiBillboardRenderer::UpdateBatchGroup(DiRenderBatchGroup* group, DiCamera* cam, DiParticlePool* pool)
	{
		DiParticleRenderer::UpdateBatchGroup(group, cam, pool);

		if (!m_bVisible)
		{
			return;
		}

		if (pool->IsEmpty(DiParticle::PT_VISUAL))
		{
			return;
		}

		m_pkBillboardSet->BeginBillboards();
		DiBillboard bb;

		DiVisualParticle* particle = static_cast<DiVisualParticle*>(pool->GetFirst(DiParticle::PT_VISUAL));
		while (!pool->End(DiParticle::PT_VISUAL))
		{
			if (particle)
			{
				bb.m_kPosition = particle->position;

				if (m_eBillboardType == BBT_ORIENTED_SELF || m_eBillboardType == BBT_PERPENDICULAR_SELF)
				{
					bb.m_kDirection = particle->direction;
					bb.m_kDirection.normalise();
				}
				else if (m_eBillboardType == BBT_ORIENTED_SHAPE)
				{
					bb.m_kDirection = DiVec3(particle->orientation.x, particle->orientation.y, particle->orientation.z);
					bb.m_kDirection.normalise();
				}


				bb.m_kColour	= particle->colour;
				bb.m_kRotation	= particle->zRotation;

				// �Ⱥ��ǹ���ģ�����д��
				if (bb.m_bOwnDimensions = particle->ownDimensions)
				{
					bb.m_bOwnDimensions = true;
					bb.m_fWidth = particle->width;
					bb.m_fHeight = particle->height;
				}

				bb.SetTexcoordIndex(particle->textureCoordsCurrent);

				m_pkBillboardSet->InjectBillboard(bb);
			}

			particle = static_cast<DiVisualParticle*>(pool->GetNext(DiParticle::PT_VISUAL));
		}

		m_pkBillboardSet->EndBillboards();

		m_pkBillboardSet->CullingUpdate(group,cam);
	}
	
	void DiBillboardRenderer::NotifyAttached(DiNode* parent)
	{
		m_pkBillboardSet->NotifyAttached(parent);
	}
	
	void DiBillboardRenderer::SetMaterialName(const DiString& materialName)
	{
		m_pkBillboardSet->SetMaterial(materialName);
	}
	
	void DiBillboardRenderer::NotifyCurrentCamera(DiCamera* cam)
	{
		m_pkBillboardSet->NotifyCurrentCamera(cam);
	}
	
	void DiBillboardRenderer::NotifyParticleQuota(size_t quota)
	{
		m_pkBillboardSet->SetPoolSize(static_cast<unsigned int>(quota));
	}
	
	void DiBillboardRenderer::NotifyDefaultDimensions(float width, float height, float depth)
	{
		m_pkBillboardSet->SetDefaultDimensions(width, height);
	}
	
	void DiBillboardRenderer::NotifyParticleResized(void)
	{
		m_pkBillboardSet->NotifyBillboardResized();
	}
	
	void DiBillboardRenderer::NotifyParticleZRotated(void)
	{
		m_pkBillboardSet->NotifyBillboardRotated();
	}
	
	void DiBillboardRenderer::SetBatchGroupID(uint8 queueId)
	{
		m_ucQueueId = queueId;
		m_pkBillboardSet->SetBatchGroup(DiBatchGroupType(m_ucQueueId));
	}

	DiSortMode DiBillboardRenderer::GetSortMode(void) const
	{
		return m_pkBillboardSet->GetSortMode();
	}
	
	void DiBillboardRenderer::SetVisible(bool visible)
	{
		DiParticleRenderer::SetVisible(visible);
		m_pkBillboardSet->SetVisible(visible);
	}
	
	void DiBillboardRenderer::CopyTo (DiParticleRenderer* renderer)
	{
		DiParticleRenderer::CopyTo(renderer);

		DiBillboardRenderer* billboardRenderer = static_cast<DiBillboardRenderer*>(renderer);

		if (!billboardRenderer->GetBillboardSet())
		{
			return;
		}

		billboardRenderer->SetBillboardType(GetBillboardType());
		billboardRenderer->SetBillboardOrigin(GetBillboardOrigin());
		billboardRenderer->SetBillboardRotationType(GetBillboardRotationType());
		billboardRenderer->SetCommonDirection(GetCommonDirection());
		billboardRenderer->SetCommonUpVector(GetCommonUpVector());
	}

	void DiBillboardRenderer::SetBillboardOrigin( BillboardOrigin origin )
	{
		m_pkBillboardSet->SetBillboardOrigin(origin);
	}

	Demi::BillboardOrigin DiBillboardRenderer::GetBillboardOrigin( void ) const
	{
		return m_pkBillboardSet->GetBillboardOrigin();
	}

}

