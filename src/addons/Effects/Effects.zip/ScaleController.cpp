
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ScaleController.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"
#include "VisualParticle.h"

namespace Demi
{
	const float DiScaleController::DEFAULT_X_SCALE = 1.0f;
	const float DiScaleController::DEFAULT_Y_SCALE = 1.0f;
	const float DiScaleController::DEFAULT_Z_SCALE = 1.0f;
	const float DiScaleController::DEFAULT_XYZ_SCALE = 1.0f;

	DiScaleController::DiScaleController(void) : 
		DiParticleController(),
		m_bDynScaleXSet(false),
		m_bDynScaleYSet(false),
		m_bDynScaleZSet(false),
		m_bDynScaleXYZSet(false),
		m_bSinceStartSystem(false)
	{
		m_pkDynScaleX = DI_NEW DiAttributeFixed();
		m_pkDynScaleY = DI_NEW DiAttributeFixed();
		m_pkDynScaleZ = DI_NEW DiAttributeFixed();
		m_pkDynScaleXYZ = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynScaleX))->SetValue(DEFAULT_X_SCALE);
		(static_cast<DiAttributeFixed*>(m_pkDynScaleY))->SetValue(DEFAULT_Y_SCALE);
		(static_cast<DiAttributeFixed*>(m_pkDynScaleZ))->SetValue(DEFAULT_Z_SCALE);
		(static_cast<DiAttributeFixed*>(m_pkDynScaleXYZ))->SetValue(DEFAULT_XYZ_SCALE);
		m_fLatestTimeElapsed = 1.0f;
	}
	
	DiScaleController::~DiScaleController(void)
	{
		SAFE_DELETE(m_pkDynScaleX);
		SAFE_DELETE(m_pkDynScaleY);
		SAFE_DELETE(m_pkDynScaleZ);
		SAFE_DELETE(m_pkDynScaleXYZ);
	}
	
	void DiScaleController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		if (particle->particleType != DiParticle::PT_VISUAL)
		{
			return;
		}

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		float ds = 0;
		float width = 0;
		float height = 0;
		float depth = 0;

		if (m_bDynScaleXYZSet)
		{
			ds = CalculateScale(m_pkDynScaleXYZ, particle) * timeElapsed * CalculateAffectSpecialisationFactor(particle);
			if (visualParticle->width > 0)
			{
				width = visualParticle->width + ds * m_kControllerScale.x;
			}
			if (visualParticle->height > 0)
			{
				height = visualParticle->height + ds * m_kControllerScale.y;
			}
			if (visualParticle->depth > 0)
			{
				depth = visualParticle->depth + ds * m_kControllerScale.z;
			}
			visualParticle->SetOwnDimensions(width, height, depth);
		}
		else
		{
			if (m_bDynScaleXSet)
			{
				ds = CalculateScale(m_pkDynScaleX, particle) * timeElapsed;
				if (visualParticle->width > 0)
				{
					width = visualParticle->width + ds * m_kControllerScale.x;
				}
			}
			if (m_bDynScaleYSet)
			{
				ds = CalculateScale(m_pkDynScaleY, particle) * timeElapsed;
				if (visualParticle->height > 0)
				{
					height = visualParticle->height + ds * m_kControllerScale.y;
				}
			}
			if (m_bDynScaleZSet)
			{
				ds = CalculateScale(m_pkDynScaleZ, particle) * timeElapsed;
				if (visualParticle->depth > 0)
				{
					depth = visualParticle->depth + ds * m_kControllerScale.z;
				}
			}
			visualParticle->SetOwnDimensions(width, height, depth);
		}
	}
	
	void DiScaleController::SetDynScaleX(DiDynamicAttribute* dynScaleX)
	{
		SAFE_DELETE(m_pkDynScaleX);

		m_pkDynScaleX = dynScaleX;
		m_bDynScaleXSet = true;
	}
	
	void DiScaleController::ResetDynScaleX(bool resetToDefault)
	{
		if (resetToDefault)
		{
			SAFE_DELETE(m_pkDynScaleX);
			m_pkDynScaleX = DI_NEW DiAttributeFixed();
			(static_cast<DiAttributeFixed*>(m_pkDynScaleX))->SetValue(DEFAULT_X_SCALE);
			m_bDynScaleXSet = false;
		}
		else
		{
			m_bDynScaleXSet = true;
		}
	}
	
	void DiScaleController::SetDynScaleY(DiDynamicAttribute* dynScaleY)
	{
		SAFE_DELETE(m_pkDynScaleY);
		m_pkDynScaleY = dynScaleY;
		m_bDynScaleYSet = true;
	}
	
	void DiScaleController::ResetDynScaleY(bool resetToDefault)
	{
		if (resetToDefault)
		{
			SAFE_DELETE(m_pkDynScaleY);
			m_pkDynScaleY = DI_NEW DiAttributeFixed();
			(static_cast<DiAttributeFixed*>(m_pkDynScaleY))->SetValue(DEFAULT_X_SCALE);
			m_bDynScaleYSet = false;
		}
		else
		{
			m_bDynScaleYSet = true;
		}
	}
	
	void DiScaleController::SetDynScaleZ(DiDynamicAttribute* dynScaleZ)
	{
		SAFE_DELETE(m_pkDynScaleZ);

		m_pkDynScaleZ = dynScaleZ;
		m_bDynScaleZSet = true;
	}
	
	void DiScaleController::ResetDynScaleZ(bool resetToDefault)
	{
		if (resetToDefault)
		{
			SAFE_DELETE(m_pkDynScaleZ);
			m_pkDynScaleZ = DI_NEW DiAttributeFixed();
			(static_cast<DiAttributeFixed*>(m_pkDynScaleZ))->SetValue(DEFAULT_X_SCALE);
			m_bDynScaleYSet = false;
		}
		else
		{
			m_bDynScaleYSet = true;
		}
	}
	
	void DiScaleController::SetDynScaleXYZ(DiDynamicAttribute* dynScaleXYZ)
	{
		SAFE_DELETE(m_pkDynScaleXYZ);

		m_pkDynScaleXYZ = dynScaleXYZ;
		m_bDynScaleXYZSet = true;
	}
	
	void DiScaleController::ResetDynScaleXYZ(bool resetToDefault)
	{
		if (resetToDefault)
		{
			SAFE_DELETE(m_pkDynScaleXYZ);
			m_pkDynScaleXYZ = DI_NEW DiAttributeFixed();
			(static_cast<DiAttributeFixed*>(m_pkDynScaleXYZ))->SetValue(DEFAULT_XYZ_SCALE);
			m_bDynScaleXYZSet = false;
		}
		else
		{
			m_bDynScaleXYZSet = true;
		}
	}
	
	float DiScaleController::CalculateScale(DiDynamicAttribute* dynScale, DiParticle* particle)
	{
		if (!particle)
			return 0.0f;

		if (m_bSinceStartSystem)
		{
			return m_kDynamicAttributeHelper.Calculate(dynScale, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart());
		}
		else
		{
			return m_kDynamicAttributeHelper.Calculate(dynScale, particle->timeFraction);
		}
	}
	
	void DiScaleController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiScaleController* scaleAffector = static_cast<DiScaleController*>(affector);
		scaleAffector->SetDynScaleX(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynScaleX()));
		scaleAffector->SetDynScaleY(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynScaleY()));
		scaleAffector->SetDynScaleZ(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynScaleZ()));
		scaleAffector->SetDynScaleXYZ(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetDynScaleXYZ()));
		scaleAffector->m_bDynScaleXSet 		= m_bDynScaleXSet;
		scaleAffector->m_bDynScaleYSet 		= m_bDynScaleYSet;
		scaleAffector->m_bDynScaleZSet 		= m_bDynScaleZSet;
		scaleAffector->m_bDynScaleXYZSet	= m_bDynScaleXYZSet;
		scaleAffector->m_bSinceStartSystem	= m_bSinceStartSystem;
	}
}

