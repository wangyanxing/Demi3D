
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "LineEmitter.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"

namespace Demi
{
	const DiVec3 DiLineEmitter::DEFAULT_END				= DiVec3::ZERO;
	const float	DiLineEmitter::DEFAULT_MIN_INCREMENT 	= 0.0f;
	const float	DiLineEmitter::DEFAULT_MAX_INCREMENT 	= 0.0f;
	const float	DiLineEmitter::DEFAULT_MAX_DEVIATION 	= 0.0f;

	
	DiLineEmitter::DiLineEmitter(void) : 
		DiParticleEmitter(),
		m_kEnd(DEFAULT_END),
		m_kPerpendicular(DiVec3::ZERO),
		m_fMaxDeviation(DEFAULT_MAX_DEVIATION),
		m_fMinIncrement(DEFAULT_MIN_INCREMENT),
		m_fMaxIncrement(DEFAULT_MAX_INCREMENT),
		m_fIncrement(0.0f),
		m_fLength(0.0f),
		m_bIncrementsLeft(true),
		m_bFirst(true),
		m_kScaledEnd(DiVec3::ZERO),
		m_fScaledMaxDeviation(0.0f),
		m_fScaledMinIncrement(0.0f),
		m_fScaledMaxIncrement(0.0f),
		m_fScaledLength(0.0f)
	{
	}
	
	void DiLineEmitter::NotifyRescaled(const DiVec3& scale)
	{
		DiParticleEmitter::NotifyRescaled(scale);
		float scaleLength = scale.length();
		m_kScaledEnd = m_kEnd * scale;
		m_fScaledMaxDeviation = m_fMaxDeviation * scaleLength;
		m_fScaledMinIncrement = m_fMinIncrement * scaleLength;
		m_fScaledMaxIncrement = (m_fMaxIncrement - m_fMinIncrement) * scaleLength;
		m_fScaledLength = m_kScaledEnd.length();
	}
	
	unsigned short DiLineEmitter::CalculateRequestedParticles(float timeElapsed)
	{
		unsigned short requested = DiParticleEmitter::CalculateRequestedParticles(timeElapsed);

		if (m_fScaledMaxIncrement > 0)
		{
			// Do not create particles if there are no increments left
			if (!m_bIncrementsLeft)
			{
				// Set back to 0 again
				requested = 0;
			}

			// For duration + repeat/delay: Clear the particles and start all over again.
			if (!m_bEnabled)
			{
				NotifyStart();
				m_pkParentElement->LockAllParticles(); // Needed to set the first generated particle also first in the list with particles
			}
		}

		return requested;
	}
	
	const DiVec3& DiLineEmitter::GetEnd(void) const
	{
		return m_kEnd;
	}
	
	void DiLineEmitter::SetEnd(const DiVec3& end)
	{
		m_kEnd = end;
		m_kScaledEnd = m_kEnd * m_kEmitterScale;
		m_fLength = m_kEnd.length();
	}
	
	float DiLineEmitter::GetMaxIncrement(void) const
	{
		return m_fMaxIncrement;
	}
	
	void DiLineEmitter::SetMaxIncrement(float maxIncrement)
	{
		m_fMaxIncrement = maxIncrement;
		m_fScaledMaxIncrement = m_fMaxIncrement * m_kEmitterScale.length();
	}
	
	float DiLineEmitter::GetMinIncrement(void) const
	{
		return m_fMinIncrement;
	}
	
	void DiLineEmitter::SetMinIncrement(float minIncrement)
	{
		m_fMinIncrement = minIncrement;
		m_fScaledMinIncrement = m_fMinIncrement * m_kEmitterScale.length();
	}
	
	float DiLineEmitter::GetMaxDeviation(void) const
	{
		return m_fMaxDeviation;
	}
	
	void DiLineEmitter::SetMaxDeviation(float maxDeviation)
	{
		m_fMaxDeviation = maxDeviation;
		m_fScaledMaxDeviation = m_fMaxDeviation * m_kEmitterScale.length();
	}
	
	void DiLineEmitter::InitParticlePosition(DiParticle* particle)
	{
		// Remark: Don't take the orientation of the node into account. The mEnd position is leading.
		if (m_bAutoDirection || (m_fScaledMaxDeviation > 0.0f && !m_bFirst))
		{
			// Generate a random vector perpendicular on the line if this is required
			m_kPerpendicular = m_kEnd.crossProduct(DiVec3(DiMath::RangeRandom(-1, 1), 
				DiMath::RangeRandom(-1, 1), 
				DiMath::RangeRandom(-1, 1)));
			m_kPerpendicular.normalise();
		}

		// If mMaxIncrement has been set, the particle emission follows a trajectory path along the line
		float fraction = 0.0f;
		if (m_fScaledMaxIncrement > 0.0f)
		{
			if (!m_bFirst)
			{
				m_fIncrement += (m_fScaledMinIncrement + DiMath::UnitRandom() * m_fScaledMaxIncrement);
				if (m_fIncrement >= m_fScaledLength)
				{
					m_bIncrementsLeft = false;
				}
				fraction = m_fIncrement / m_fScaledLength;
			}
		}
		else
		{
			fraction = DiMath::UnitRandom();
		}

		// If the deviation has been set, generate a position with a certain distance from the line
		DiVec3 dp = GetDerivedPosition();
		if (m_fScaledMaxDeviation > 0.0f && m_bIncrementsLeft)
		{
			if (!m_bFirst)
			{
				DiVec3 basePosition = dp + fraction * m_kScaledEnd;
				particle->position = basePosition + m_fScaledMaxDeviation * DiMath::UnitRandom() * m_kPerpendicular;
				particle->originalPosition = basePosition;	// Position is without deviation from the line,
				// to make affectors a bit faster/easier.
			}
			else
			{
				particle->position = dp;
				particle->originalPosition = particle->position;
			}
		}
		else
		{
			particle->position = dp + fraction * m_kScaledEnd;
			particle->originalPosition = particle->position;
		}

		m_bFirst = false;
	}
	
	void DiLineEmitter::InitParticleDirection(DiParticle* particle)
	{
		if (m_bAutoDirection)
		{
			DiRadian angle;
			GenerateAngle(angle);
			if (angle != DiRadian(0))
			{
				particle->direction = m_kPerpendicular.randomDeviant(angle, m_kUpVector);
				particle->originalDirection = particle->direction;
			}
			else
			{
				particle->direction = m_kPerpendicular;
				particle->originalDirection = particle->direction;
			}
		}
		else
		{
			DiParticleEmitter::InitParticleDirection(particle);
		}
	}
	
	void DiLineEmitter::CopyTo (DiParticleEmitter* emitter)
	{
		DiParticleEmitter::CopyTo(emitter);

		DiLineEmitter* lineEmitter = static_cast<DiLineEmitter*>(emitter);
		lineEmitter->SetEnd(m_kEnd);
		lineEmitter->m_fLength = m_fLength;
		lineEmitter->SetMinIncrement(m_fMinIncrement);
		lineEmitter->SetMaxIncrement(m_fMaxIncrement);
		lineEmitter->SetMaxDeviation(m_fMaxDeviation);
	}

	void DiLineEmitter::NotifyStart()
	{
		m_fIncrement = 0.0f;
		m_bIncrementsLeft = true;
		m_bFirst = true;
	}

}

