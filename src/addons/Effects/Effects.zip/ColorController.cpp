
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ColorController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const DiColorController::ColourOperation DiColorController::DEFAULT_COLOUR_OPERATION = DiColorController::CAO_SET;

	DiColorController::DiColorController(void) : 
		DiParticleController(),
		m_eColourOperation(DEFAULT_COLOUR_OPERATION)
	{
	}
	
	void DiColorController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiColorController* colourAffector		= static_cast<DiColorController*>(affector);
		colourAffector->m_kColourMap		= m_kColourMap;
		colourAffector->m_eColourOperation	= m_eColourOperation;
	}
	
	const DiColorController::ColourOperation& DiColorController::GetColourOperation (void) const
	{
		return m_eColourOperation;
	}
	
	void DiColorController::SetColourOperation (const DiColorController::ColourOperation& colourOperation)
	{
		m_eColourOperation = colourOperation;
	}
	
	void DiColorController::AddColour (float timeFraction, const DiColor& colour)
	{
		m_kColourMap[timeFraction] = colour;
	}
	
	const DiColorController::ColorMap& DiColorController::GetTimeAndColour(void) const
	{
		return m_kColourMap;
	}
	
	void DiColorController::ClearColourMap (void)
	{
		m_kColourMap.clear();
	}
	
	void DiColorController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		if (m_kColourMap.empty())
		{
			return;
		}

		if (particle->particleType != DiParticle::PT_VISUAL)
		{
			return;
		}

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);

		DiColor colour = DiColor::White;
		float timeFraction = (visualParticle->totalTimeToLive - visualParticle->timeToLive) / visualParticle->totalTimeToLive;
		ColourMapIterator it1 = FindNearestColourMapIterator(timeFraction);
		ColourMapIterator it2 = it1;
		it2++;
		if (it2 != m_kColourMap.end())
		{
			colour = it1->second + ((it2->second - it1->second) * ((timeFraction - it1->first)/(it2->first - it1->first)));
		}
		else
		{
			colour = it1->second;
		}

		if (m_eColourOperation == CAO_SET)
		{
			visualParticle->colour = colour;
		}
		else
		{
			visualParticle->colour = colour * visualParticle->originalColour;
		}
	}
	
	DiColorController::ColourMapIterator DiColorController::FindNearestColourMapIterator(float timeFraction)
	{
		ColourMapIterator it;
		for (it = m_kColourMap.begin(); it != m_kColourMap.end(); ++it)
		{
			if (timeFraction < it->first)
			{
				if (it == m_kColourMap.begin())
				{
					return it;
				}
				else
				{
					return --it;
				}
			}
		}

		return --it;
	}
}

