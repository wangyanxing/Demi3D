
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "EffectManager.h"
#include "ParticleElement.h"
#include "ParticleEmitter.h"
#include "ParticleController.h"
#include "ParticleSystem.h"
#include "ParticleEmitterFactory.h"
#include "ParticleControllerFactory.h"
#include "ParticleRendererFactory.h"

#include "BillboardRender.h"

#include "PointEmitter.h"
#include "LineEmitter.h"
#include "CircleEmitter.h"

#include "BoxColliderController.h"
#include "ColorController.h"
#include "GeometryRotatorController.h"
#include "GravityController.h"
#include "JetController.h"
#include "LinearForceController.h"
#include "PlaneColliderController.h"
#include "RandomiserController.h"
#include "ScaleController.h"
#include "SineForceController.h"
#include "SphereColliderController.h"
#include "VortexController.h"

#include "SceneManager.h"
#include "RenderWindow.h"

namespace Demi
{
	DiEffectManager::DiEffectManager (DiSceneManager* sm) :
		m_kLastCreatedTemplateName(DiString::BLANK),
		m_pkSceneManager(sm)
	{
		InitFactories();
	}
	
	DiEffectManager::~DiEffectManager ()
	{
		DestroyAllParticleSystemTemplates();

		ReleaseFactories();
	}

	void DiEffectManager::DestroyAllParticleSystemTemplates() 
	{
		ParticleSystemTemplateMap::iterator t;
		for (t = m_kParticleSystemTemplates.begin(); t != m_kParticleSystemTemplates.end(); ++t)
		{
			SAFE_DELETE(t->second);
		}
		m_kParticleSystemTemplates.clear();
	}
	
	void DiEffectManager::AddEmitterFactory(DiParticleEmitterFactory* factory)
	{
		DiString type = factory->GetEmitterType();
		m_kEmitterFactories[type] = factory;
	}
	
	DiParticleEmitterFactory* DiEffectManager::GetEmitterFactory(const DiString& emitterType)
	{
		EmitterFactoryMap::iterator it = m_kEmitterFactories.find(emitterType);
		if (it != m_kEmitterFactories.end())
		{
			return it->second;
		}
		return 0;
	}
	
	void DiEffectManager::RemoveEmitterFactory(const DiString& emitterType)
	{
		EmitterFactoryMap::iterator it = m_kEmitterFactories.find(emitterType);
		if (it == m_kEmitterFactories.end())
		{
			DiError("�Ҳ�������������:%s",emitterType.c_str());
		}

		m_kEmitterFactories.erase(it);
	}
	
	void DiEffectManager::DestroyEmitterFactory(const DiString& emitterType)
	{
		EmitterFactoryMap::iterator it = m_kEmitterFactories.find(emitterType);
		if (it == m_kEmitterFactories.end())
		{
			DiError("�Ҳ�������������:%s",emitterType.c_str());
		}

		SAFE_DELETE(it->second);
		m_kEmitterFactories.erase(it);
	}
	
	DiParticleEmitter* DiEffectManager::CreateEmitter(const DiString& emitterType)
	{
		EmitterFactoryMap::iterator it = m_kEmitterFactories.find(emitterType);

		if (it == m_kEmitterFactories.end())
		{
			DiError("�Ҳ�������������:%s",emitterType.c_str());
		}

		return it->second->CreateEmitter();
	}
	
	DiParticleEmitter* DiEffectManager::CloneEmitter(DiParticleEmitter* emitter)
	{
		if (!emitter)
		{
			return 0;
		}

		DiParticleEmitter* clonedEmitter = CreateEmitter(emitter->GetEmitterType());
		emitter->CopyTo(clonedEmitter);
		return clonedEmitter;
	}
	
	void DiEffectManager::DestroyEmitter(DiParticleEmitter* emitter)
	{
		EmitterFactoryMap::iterator it = m_kEmitterFactories.find(emitter->GetEmitterType());

		if (it == m_kEmitterFactories.end())
		{
			DiError("�Ҳ�������������:%s",emitter->GetEmitterType().c_str());
		}

		it->second->DestroyEmitter(emitter);
	}
	
	DiParticleElement* DiEffectManager::CreateElement(void)
	{
		DiParticleElement* technique = DI_NEW DiParticleElement();
		technique->SetRenderer(CreateRenderer("Billboard"));
		return technique;
	}
	
	DiParticleElement* DiEffectManager::CloneElement(DiParticleElement* element)
	{
		if (!element)
		{
			return 0;
		}

		DiParticleElement* clonedTechnique = CreateElement();
		element->CopyTo(clonedTechnique);
		return clonedTechnique;
	}
	
	void DiEffectManager::DestroyElement(DiParticleElement* element)
	{
		DI_DELETE element;
	}
	
	void DiEffectManager::AddControllerFactory(DiParticleControllerFactory* factory)
	{
		DiString type = factory->GetControllerType();
		m_kControllerFactories[type] = factory;
	}
	
	DiParticleControllerFactory* DiEffectManager::GetControllerFactory(const DiString& affectorType)
	{
		ControllerFactoryMap::iterator it = m_kControllerFactories.find(affectorType);
		if (it != m_kControllerFactories.end())
		{
			return it->second;
		}
		return 0;
	}
	
	void DiEffectManager::RemoveControllerFactory(const DiString& controllerType)
	{
		ControllerFactoryMap::iterator it = m_kControllerFactories.find(controllerType);
		if (it == m_kControllerFactories.end())
		{
			DiError("�Ҳ�������������:%s",controllerType.c_str());
		}

		m_kControllerFactories.erase(it);
	}
	
	void DiEffectManager::DestroyControllerFactory(const DiString& controllerType)
	{
		ControllerFactoryMap::iterator it = m_kControllerFactories.find(controllerType);
		if (it == m_kControllerFactories.end())
		{
			DiError("�Ҳ�������������:%s",controllerType.c_str());
		}

		SAFE_DELETE(it->second);
		m_kControllerFactories.erase(it);
	}
	
	DiParticleController* DiEffectManager::CreateController(const DiString& controllerType)
	{
		ControllerFactoryMap::iterator it = m_kControllerFactories.find(controllerType);

		if (it == m_kControllerFactories.end())
		{
			DiError("�Ҳ�������������:%s",controllerType.c_str());
		}

		return it->second->CreateController();
	}
	
	DiParticleController* DiEffectManager::CloneController(DiParticleController* affector)
	{
		if (!affector)
		{
			return NULL;
		}

		DiParticleController* clonedAffector = CreateController(affector->GetControllerType());
		affector->CopyTo(clonedAffector);
		return clonedAffector;
	}
	
	void DiEffectManager::DestroyController(DiParticleController* affector)
	{
		ControllerFactoryMap::iterator it = m_kControllerFactories.find(affector->GetControllerType());

		if (it == m_kControllerFactories.end())
		{
			DiError("�Ҳ�������������:%s",affector->GetControllerType().c_str());
		}

		it->second->DestroyController(affector);
	}
	
	void DiEffectManager::AddRendererFactory(DiParticleRendererFactory* factory)
	{
		DiString type = factory->GetRendererType();
		m_kRendererFactories[type] = factory;
	}
	
	DiParticleRendererFactory* DiEffectManager::GetRendererFactory(const DiString& rendererType)
	{
		RendererFactoryMap::iterator it = m_kRendererFactories.find(rendererType);
		if (it != m_kRendererFactories.end())
		{
			return it->second;
		}
		return 0;
	}
	
	void DiEffectManager::RemoveRendererFactory(const DiString& rendererType)
	{
		RendererFactoryMap::iterator it = m_kRendererFactories.find(rendererType);
		if (it == m_kRendererFactories.end())
		{
			DiError("�Ҳ�����Ⱦ������:%s",rendererType.c_str());
		}

		m_kRendererFactories.erase(it);
	}
	
	void DiEffectManager::DestroyRendererFactory(const DiString& rendererType)
	{
		RendererFactoryMap::iterator it = m_kRendererFactories.find(rendererType);
		if (it == m_kRendererFactories.end())
		{
			DiError("�Ҳ�����Ⱦ������:%s",rendererType.c_str());
		}

		SAFE_DELETE(it->second);
		m_kRendererFactories.erase(it);
	}
	
	DiParticleRenderer* DiEffectManager::CreateRenderer(const DiString& rendererType)
	{
		RendererFactoryMap::iterator it = m_kRendererFactories.find(rendererType);

		if (it == m_kRendererFactories.end())
		{
			DiError("�Ҳ�����Ⱦ������:%s",rendererType.c_str());
		}

		return it->second->CreateRenderer();
	}
	
	DiParticleRenderer* DiEffectManager::CloneRenderer(DiParticleRenderer* renderer)
	{
		if (!renderer)
		{
			return 0;
		}

		DiParticleRenderer* clonedRenderer = CreateRenderer(renderer->GetRendererType());
		renderer->CopyTo(clonedRenderer);
		return clonedRenderer;
	}
	
	void DiEffectManager::DestroyRenderer(DiParticleRenderer* renderer)
	{
		RendererFactoryMap::iterator it = m_kRendererFactories.find(renderer->GetRendererType());

		if (it == m_kRendererFactories.end())
		{
			DiError("�Ҳ�����Ⱦ������:%s",renderer->GetRendererType().c_str());
		}

		it->second->DestroyRenderer(renderer);
	}
	
	DiParticleSystem* DiEffectManager::CreateParticleSystemTemplate(const DiString& name)
	{
		DiString expName = name;
		while (m_kParticleSystemTemplates.find(expName) != m_kParticleSystemTemplates.end())
		{
			expName = DiString("CopyOf") + expName;
		}

		DiParticleSystem* particleSystemTemplate = DI_NEW DiParticleSystem(expName);
		particleSystemTemplate->SetSceneManager(m_pkSceneManager);

		AddParticleSystemTemplate(expName, particleSystemTemplate);
		m_kLastCreatedTemplateName = expName;
		return particleSystemTemplate;
	}
	
	void DiEffectManager::ReplaceParticleSystemTemplate(const DiString& name, DiParticleSystem* system)
	{
		DiParticleSystem* systemTemplate = GetParticleSystemTemplate(name);
		if (systemTemplate)
		{
			*systemTemplate = *system;
			system->CopyTo(systemTemplate);
		}
	}
	
	const DiString& DiEffectManager::GetLastCreatedTemplateName(void)
	{
		return m_kLastCreatedTemplateName;
	}
	
	void DiEffectManager::AddParticleSystemTemplate(const DiString& name, DiParticleSystem* systemTemplate)
	{
		if (m_kParticleSystemTemplates.find(name) != m_kParticleSystemTemplates.end())
		{
			DiError("��Чģ��%s�Ѵ���",name.c_str());
		}

		m_kParticleSystemTemplates[name] = systemTemplate;
	}
	
	DiParticleSystem* DiEffectManager::GetParticleSystemTemplate(const DiString& templateName)
	{
		ParticleSystemTemplateMap::iterator i = m_kParticleSystemTemplates.find(templateName);
		if (i != m_kParticleSystemTemplates.end())
		{
			return i->second;
		}
	
		return 0;
	}
	
	void DiEffectManager::DestroyParticleSystemTemplate(const DiString& templateName)
	{
		ParticleSystemTemplateMap::iterator i = m_kParticleSystemTemplates.find(templateName);
		if (i != m_kParticleSystemTemplates.end())
		{
			SAFE_DELETE(i->second);
			m_kParticleSystemTemplates.erase(i);
		}
	}
	
	void DiEffectManager::ParticleSystemTemplateNames(DiVector<DiString>& v)
	{
		DiVector<DiString>::iterator;
		ParticleSystemTemplateMap::iterator it;
		ParticleSystemTemplateMap::iterator itEnd = m_kParticleSystemTemplates.end();
		for (it = m_kParticleSystemTemplates.begin(); it != itEnd; ++it)
		{
			v.push_back((*it).first);
		}
	}
	
	DiParticleSystem* DiEffectManager::CreateParticleSystem(const DiString& name,
		const DiString& templateName)
	{
		if (m_kParticleSystems.find(name) != m_kParticleSystems.end())
		{
			DiError("��Ϊ%s����Ч�Լ�����,ģ��Ϊ%s",name.c_str(),templateName.c_str());
			return NULL;
		}

		DiParticleSystem* system = CreateSystemImpl(name,templateName);
		system->SetSceneManager(m_pkSceneManager);
		system->SetTemplateName(templateName);
		m_kParticleSystems[name] = system;
		return system;
	}
	
	DiParticleSystem* DiEffectManager::CreateParticleSystem(const DiString& name)
	{
		if (m_kParticleSystems.find(name) != m_kParticleSystems.end())
		{
			DiError("��Ϊ%s����Ч�Լ�����",name.c_str());
			return NULL;
		}

		DiParticleSystem* system = CreateSystemImpl(name);
		system->SetSceneManager(m_pkSceneManager);
		m_kParticleSystems[name] = system;
		return system;
	}
	
	DiParticleSystem* DiEffectManager::GetParticleSystem(const DiString& name)
	{
		if (name == DiString::BLANK)
		{
			return 0;
		}

		ParticleSystemMap::iterator i = m_kParticleSystems.find(name);
		if (i != m_kParticleSystems.end())
		{
			return i->second;
		}
	
		return 0;
	}
	
	void DiEffectManager::DestroyParticleSystem(DiParticleSystem* particleSystem)
	{
		if (!particleSystem)
		{
			return;
		}

		ParticleSystemMap::iterator i = m_kParticleSystems.find(particleSystem->GetName());
		if (i != m_kParticleSystems.end())
		{
			m_kParticleSystems.erase(i);
		}

		DestroySystemImpl(particleSystem);
	}
	
	void DiEffectManager::DestroyParticleSystem(const DiString& particleSystemName)
	{
		DiParticleSystem* ps = NULL;
		ParticleSystemMap::iterator i = m_kParticleSystems.find(particleSystemName);
		if (i != m_kParticleSystems.end())
		{
			m_kParticleSystems.erase(i);
			DestroySystemImpl(ps);
		}
		DiWarning("Cannot find the particle system:%s",particleSystemName.c_str());
	}
	
	void DiEffectManager::DestroyAllParticleSystems()
	{
		ParticleSystemMap::iterator t = m_kParticleSystems.begin();
		while ( t != m_kParticleSystems.end() )
		{
			DiParticleSystem* particleSystem = t->second;
			DestroySystemImpl(particleSystem);
			++t;
		}
		m_kParticleSystems.clear();
	}
	
	DiParticleSystem* DiEffectManager::CreateSystemImpl(const DiString& name)
	{
		DiParticleSystem* sys = DI_NEW DiParticleSystem(name);
		return sys;
	}
	
	DiParticleSystem* DiEffectManager::CreateSystemImpl(const DiString& name, const DiString& templateName)
	{
		DiParticleSystem* pTemplate = GetParticleSystemTemplate(templateName);
		if (!pTemplate)
		{
			DiError("Cannot find particle template��%s",templateName.c_str());
		}

		DiParticleSystem* sys = DI_NEW DiParticleSystem(name);
        
		*sys = *pTemplate;
		pTemplate->CopyTo(sys);
		return sys;
	}
	
	void DiEffectManager::DestroySystemImpl(DiParticleSystem* particleSystem)
	{
		SAFE_DELETE(particleSystem);
	}
	
	DiDynamicAttribute* DiEffectManager::CreateDynamicAttribute(DiDynamicAttribute::DynamicAttributeType type)
	{
		switch (type)
		{
		case DiDynamicAttribute::DAT_FIXED:
			return DI_NEW DiAttributeFixed();
			break;

		case DiDynamicAttribute::DAT_RANDOM:
			return DI_NEW DiAttributeRandom();
			break;

		case DiDynamicAttribute::DAT_CURVED:
			return DI_NEW DiAttributeCurved();
			break;
		}
		return 0;
	}

	void DiEffectManager::InitFactories()
	{
		DiParticleRendererFactory* particleRendererFactory = NULL;
		particleRendererFactory = DI_NEW DiBillboardRendererFactory();
		AddRendererFactory(particleRendererFactory);

		DiParticleEmitterFactory* particleEmitterFactory = NULL;
		particleEmitterFactory = DI_NEW DiPointEmitterFactory();
		AddEmitterFactory(particleEmitterFactory);
		particleEmitterFactory = DI_NEW DiLineEmitterFactory();
		AddEmitterFactory(particleEmitterFactory);
		particleEmitterFactory = DI_NEW DiCircleEmitterFactory();
		AddEmitterFactory(particleEmitterFactory);

		DiParticleControllerFactory* particleControllerFactory = NULL;
		particleControllerFactory = DI_NEW DiBoxColliderControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiColorControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiGeometryRotatorControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiGravityControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiJetControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiLinearForceControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiPlaneColliderControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiRandomiserControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiScaleControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiSineForceControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiSphereColliderControllerFactory();
		AddControllerFactory(particleControllerFactory);
		particleControllerFactory = DI_NEW DiVortexControllerFactory();
		AddControllerFactory(particleControllerFactory);
	}

	void DiEffectManager::ReleaseFactories()
	{
		RendererFactoryMap::iterator rfIt;
		RendererFactoryMap::iterator rfItEnd = m_kRendererFactories.end();
		for (rfIt = m_kRendererFactories.begin(); rfIt != rfItEnd; ++rfIt)
		{
			SAFE_DELETE(rfIt->second);
		}
		m_kRendererFactories.clear();

		//////////////////////////////////////////////////////////////////////////

		EmitterFactoryMap::iterator efIt;
		EmitterFactoryMap::iterator efItEnd = m_kEmitterFactories.end();
		for (efIt = m_kEmitterFactories.begin(); efIt != efItEnd; ++efIt)
		{
			SAFE_DELETE(efIt->second);
		}
		m_kEmitterFactories.clear();

		//////////////////////////////////////////////////////////////////////////

		ControllerFactoryMap::iterator cfIt;
		ControllerFactoryMap::iterator cfItEnd = m_kControllerFactories.end();
		for (cfIt = m_kControllerFactories.begin(); cfIt != cfItEnd; ++cfIt)
		{
			SAFE_DELETE(cfIt->second);
		}
		m_kControllerFactories.clear();
	}

	void DiEffectManager::Update()
	{
		float deltatime = m_pkSceneManager->GetRenderWindow()->GetDeltaSecond();
		ParticleSystemMap::iterator it;
		ParticleSystemMap::iterator itEnd = m_kParticleSystems.end();
		for ( it = m_kParticleSystems.begin(); it != itEnd; ++it)
		{
			it->second->Update(deltatime);
		}
	}

}

