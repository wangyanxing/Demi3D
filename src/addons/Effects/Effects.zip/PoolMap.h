
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#ifndef PoolMap_h__
#define PoolMap_h__

#include "FxPrerequisites.h"

namespace Demi
{
	template <typename T>
	class DEMI_FX_API DiPoolMap
	{
	public:
		typedef std::multimap<DiString, T*> PoolMapMap;
		typedef typename PoolMapMap::iterator PoolMapIterator;
		PoolMapIterator mPoolMapIterator;

		DiPoolMap (bool managed = false) : m_bManaged(managed)
		{
			if (m_bManaged)
			{
			}
		}
		
		virtual ~DiPoolMap (void)
		{
			if (m_bManaged)
			{
			}
		}
	
		inline bool IsEmpty(void)
		{
			return m_kReleased.empty();
		}
		
		inline size_t GetSize(void)
		{
			return m_kReleased.size();
		}
		
		inline void ResetIterator (void)
		{
			mPoolMapIterator = m_kReleased.begin();
		}
		
		inline T* GetFirst (void)
		{
			ResetIterator();
			if (End())
			{
				return 0;
			}

			return mPoolMapIterator->second;
		}
		
		inline T* GetNext (void)
		{
			if (End())
			{
				return 0;
			}

			mPoolMapIterator++;
			if (End())
			{
				return 0;
			}
			
			return mPoolMapIterator->second;
		}
		
		inline bool End (void)
		{
			return mPoolMapIterator == m_kReleased.end();
		}
		
		inline void Clear (void)
		{
			m_kLocked.clear();
			m_kReleased.clear();
		}
	
		inline void AddElement (const DiString& key, T* element)
		{
			if (m_bManaged)
			{
                DI_WARNING("Managing, cannot add new element");
                return;
			}

			m_kLocked.insert(std::make_pair(key, element));
		}

		inline T* ReleaseElement (const DiString& key)
		{
			if (m_kLocked.empty())
			{
				return 0;
			}

			T* t = 0;
			PoolMapIterator it;
			it = m_kLocked.find(key);
			if (it != m_kLocked.end())
			{
				t = it->second;
				m_kReleased.insert(std::make_pair(key, t));
				m_kLocked.erase(it);
			}

			return t;
		}
		
		inline void ReleaseAllElements (void)
		{
			PoolMapIterator it;
			for (it = m_kLocked.begin(); it != m_kLocked.end(); ++it)
			{
				m_kReleased.insert(std::make_pair(it->first, it->second));
			}
			m_kLocked.clear();
			ResetIterator();
		}
	
		inline void LockLatestElement (void)
		{
			m_kLocked.insert(std::make_pair(mPoolMapIterator->first, mPoolMapIterator->second));
			m_kReleased.erase(mPoolMapIterator++); 
			if (mPoolMapIterator != m_kReleased.begin() && mPoolMapIterator != m_kReleased.end())
			{
				mPoolMapIterator--;
			}
		}
		
		inline void LockAllElements (void)
		{
			PoolMapIterator it;
			for (it = m_kReleased.begin(); it != m_kReleased.end(); ++it)
			{
				m_kLocked.insert(std::make_pair(it->first, it->second));
			}
			m_kReleased.clear();
			ResetIterator();
		}

	protected:
		bool		m_bManaged;

		PoolMapMap	m_kReleased;

		PoolMapMap	m_kLocked;
	};
}

#endif // PoolMap_h__
