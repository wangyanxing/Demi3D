
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "PlaneColliderController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const DiVec3 DiPlaneColliderController::DEFAULT_NORMAL = DiVec3::ZERO;

	
	DiPlaneColliderController::DiPlaneColliderController(void) : 
		DiBaseColliderController(),
		m_kPredictedPosition(DiVec3::ZERO),
		m_kNormal(DEFAULT_NORMAL)
	{
	}
	
	const DiVec3 DiPlaneColliderController::GetNormal(void) const
	{
		return m_kNormal;
	}
	
	void DiPlaneColliderController::SetNormal(const DiVec3& normal)
	{
		m_kNormal = normal;
		m_kPlane.redefine(m_kNormal, GetDerivedPosition());
	}
	
	void DiPlaneColliderController::NotifyRescaled(const DiVec3& scale)
	{
		DiParticleController::NotifyRescaled(scale);
		m_kPlane.redefine(m_kNormal, GetDerivedPosition());
	}
	
	void DiPlaneColliderController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		m_kPredictedPosition = particle->position + m_fVelocityScale * particle->direction;
		bool collision = false;

		switch(m_eIntersectionType)
		{
		case DiBaseColliderController::IT_POINT:
			{
				// ��/ƽ���ཻ���(��ƽ���ϻ�����ƽ�汳��)
				if (m_kPlane.getDistance(particle->position) <= 0.0f)
				{
					particle->position -= m_fVelocityScale * particle->direction;
					collision = true;
				}
				else if (m_kPlane.getDistance(m_kPredictedPosition) <= 0.0f)
				{
					collision = true;
				}
			}
			break;

		case DiBaseColliderController::IT_BOX:
			{
				// ������/ƽ���ཻ���
				if (particle->particleType != DiParticle::PT_VISUAL)
				{
					break;
				}

				DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
				DiAABB box;
				PopulateAlignedBox(box,
					visualParticle->position, 
					visualParticle->width, 
					visualParticle->height,
					visualParticle->depth);
				if (box.Intersects(m_kPlane))
				{
					particle->position -= m_fVelocityScale * particle->direction;
					collision = true;
				}
				else 
				{
					PopulateAlignedBox(box,
						m_kPredictedPosition, 
						visualParticle->width, 
						visualParticle->height,
						visualParticle->depth);
					if (box.Intersects(m_kPlane))
					{
						collision = true;
					}
				}
			}
			break;
		}

		if (collision)
		{
			CalculateDirectionAfterCollision(particle, timeElapsed);
			CalculateRotationSpeedAfterCollision(particle);
			particle->AddEventFlags(DiParticle::PEF_COLLIDED);
		}
	}
	
	void DiPlaneColliderController::CalculateDirectionAfterCollision(DiParticle* particle, float timeElapsed)
	{
		float directionLength = particle->direction.length();
		switch (m_eCollisionType)
		{
		case DiBaseColliderController::CT_BOUNCE:
			{
				// ������������ϻ��߱��棬�򷴵�����ʽ��sphere colliderһ��
				particle->direction.normalise();
				particle->direction = 2 * (-particle->direction.dotProduct(-m_kNormal)) * -m_kNormal + particle->direction;

				particle->direction *= directionLength;
				particle->direction *= m_fBouncyness;
			}
			break;
		case DiBaseColliderController::CT_FLOW:
			{
				// �޸�λ��ֵ�����Ƿ��򲻱�
				particle->position += timeElapsed * directionLength * m_kNormal;
			}
			break;
		}
	}
	
	void DiPlaneColliderController::CopyTo (DiParticleController* affector)
	{
		DiBaseColliderController::CopyTo(affector);

		DiPlaneColliderController* planeCollider = static_cast<DiPlaneColliderController*>(affector);
		planeCollider->SetNormal(m_kNormal);
	}
}

