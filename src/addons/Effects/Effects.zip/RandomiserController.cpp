
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "RandomiserController.h"
#include "ParticleElement.h"

namespace Demi
{
	const DiVec3	DiRandomiserController::DEFAULT_MAX_DEVIATION		= DiVec3::ZERO;
	const float		DiRandomiserController::DEFAULT_TIME_STEP			= 0.0f;
	const bool		DiRandomiserController::DEFAULT_RANDOM_DIRECTION	= true;

	DiRandomiserController::DiRandomiserController(void) : 
		DiParticleController(),
		m_fMaxDeviationX(DEFAULT_MAX_DEVIATION.x),
		m_fMaxDeviationY(DEFAULT_MAX_DEVIATION.y),
		m_fMaxDeviationZ(DEFAULT_MAX_DEVIATION.z),
		m_fTimeSinceLastUpdate(0.0f),
		m_fTimeStep(DEFAULT_TIME_STEP),
		m_bUpdate(true),
		m_bRandomDirection(DEFAULT_RANDOM_DIRECTION)
	{
	}
	
	float DiRandomiserController::GetMaxDeviationX(void) const
	{
		return m_fMaxDeviationX;
	}
	
	void DiRandomiserController::SetMaxDeviationX(float maxDeviationX)
	{
		m_fMaxDeviationX = maxDeviationX;
	}
	
	float DiRandomiserController::GetMaxDeviationY(void) const
	{
		return m_fMaxDeviationY;
	}
	
	void DiRandomiserController::SetMaxDeviationY(float maxDeviationY)
	{
		m_fMaxDeviationY = maxDeviationY;
	}
	
	float DiRandomiserController::GetMaxDeviationZ(void) const
	{
		return m_fMaxDeviationZ;
	}
	
	void DiRandomiserController::SetMaxDeviationZ(float maxDeviationZ)
	{
		m_fMaxDeviationZ = maxDeviationZ;
	}
	
	float DiRandomiserController::GetTimeStep(void) const
	{
		return m_fTimeStep;
	}
	
	void DiRandomiserController::SetTimeStep(float timeStep)
	{
		m_fTimeStep = timeStep;
		m_fTimeSinceLastUpdate = timeStep;
	}
	
	bool DiRandomiserController::IsRandomDirection(void) const
	{
		return m_bRandomDirection;
	}
	
	void DiRandomiserController::SetRandomDirection(bool randomDirection)
	{
		m_bRandomDirection = randomDirection;
	}
	
	void DiRandomiserController::PreProcessParticles(DiParticleElement* technique, float timeElapsed)
	{
		if (technique->GetNumberOfEmittedParticles() > 0)
		{
			m_fTimeSinceLastUpdate += timeElapsed;
			if (m_fTimeSinceLastUpdate > m_fTimeStep)
			{
				m_fTimeSinceLastUpdate -= m_fTimeStep;
				m_bUpdate = true;
			}
		}
	}
	
	void DiRandomiserController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		if (m_bUpdate)
		{
			if (m_bRandomDirection)
			{
				// �������
				particle->direction += DiVec3(DiMath::RangeRandom(-m_fMaxDeviationX, m_fMaxDeviationX),
					DiMath::RangeRandom(-m_fMaxDeviationY, m_fMaxDeviationY),
					DiMath::RangeRandom(-m_fMaxDeviationZ, m_fMaxDeviationZ));
			}
			else
			{
				if (particle->IsFreezed())
				{
					return;
				}

				// λ�����
				particle->position += m_kControllerScale * DiVec3(DiMath::RangeRandom(-m_fMaxDeviationX, m_fMaxDeviationX),
					DiMath::RangeRandom(-m_fMaxDeviationY, m_fMaxDeviationY),
					DiMath::RangeRandom(-m_fMaxDeviationZ, m_fMaxDeviationZ));
			}
		}
	}
	
	void DiRandomiserController::PostProcessParticles(DiParticleElement* technique, float timeElapsed)
	{
		m_bUpdate = false;
	}
	
	void DiRandomiserController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiRandomiserController* randomiser = static_cast<DiRandomiserController*>(affector);
		randomiser->m_fMaxDeviationX = m_fMaxDeviationX;
		randomiser->m_fMaxDeviationY = m_fMaxDeviationY;
		randomiser->m_fMaxDeviationZ = m_fMaxDeviationZ;
		randomiser->m_bRandomDirection = m_bRandomDirection;
	}
}

