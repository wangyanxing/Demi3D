
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "Particle.h"

namespace Demi
{


	DiParticle::~DiParticle()
	{

	}

	void DiParticle::InitForEmission( void )
	{
		m_uiEventFlags = 0;
		timeFraction = 0.0f;
		
		AddEventFlags(DiParticle::PEF_EMITTED);

		m_bFreezed = false;
	}

	void DiParticle::InitForExpiration( DiParticleElement* technique, float timeElapsed )
	{
	}

	bool DiParticle::IsEnabled( void ) const
	{
		return m_bEnabled;
	}

	void DiParticle::SetEnabled( bool enabled )
	{
		m_bEnabled = enabled;
		if (!m_bOriginalEnabledSet)
		{
			m_bOriginalEnabled = enabled;
			m_bOriginalEnabledSet = true;
		}
	}

	void DiParticle::SetOriginalEnabled( bool originalEnabled )
	{
		m_bOriginalEnabled = originalEnabled;
		m_bOriginalEnabledSet = true;
	}

	bool DiParticle::GetOriginalEnabled( void ) const
	{
		return m_bOriginalEnabled;
	}

	bool DiParticle::IsFreezed( void ) const
	{
		return m_bFreezed;
	}

	void DiParticle::SetFreezed( bool freezed )
	{
		m_bFreezed = freezed;
	}

	void DiParticle::Process( DiParticleElement* technique, float timeElapsed )
	{
		timeFraction = (totalTimeToLive - timeToLive) / totalTimeToLive;
	}

	float DiParticle::CalculateVelocity( void ) const
	{
		if (originalScaledDirectionLength != 0)
		{
			return originalVelocity * (direction.length() / originalScaledDirectionLength);
		}
		else
		{
			return originalVelocity * direction.length();
		}
	}

	void DiParticle::CopyTo( DiParticle* particle )
	{
		particle->position						= position;
		particle->originalPosition				= originalPosition;
		particle->m_kDerivedPosition				= m_kDerivedPosition;
		particle->direction						= direction;
		particle->originalDirection 			= originalDirection;
		particle->originalDirectionLength		= originalDirectionLength;
		particle->originalScaledDirectionLength = originalScaledDirectionLength;
		particle->originalVelocity				= originalVelocity;
		particle->mass							= mass;
		particle->timeToLive					= timeToLive;
		particle->totalTimeToLive				= totalTimeToLive;
		particle->m_uiEventFlags					= m_uiEventFlags;
		particle->m_bMarkedForEmission			= m_bMarkedForEmission;
		particle->m_bEnabled						= m_bEnabled;
		particle->m_bOriginalEnabled				= m_bOriginalEnabled;
		particle->m_bOriginalEnabledSet			= m_bOriginalEnabledSet;
		particle->m_bFreezed						= m_bFreezed;
		particle->timeFraction					= timeFraction;
	}

	float DiParticle::DEFAULT_MASS = 1.0f;
	float DiParticle::DEFAULT_TTL = 10.0f;

}

