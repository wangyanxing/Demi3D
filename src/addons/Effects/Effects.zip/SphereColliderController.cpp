
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "SphereColliderController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const float DiSphereColliderController::DEFAULT_RADIUS = 100.0f;
	
	DiSphereColliderController::DiSphereColliderController(void) : 
		DiBaseColliderController(),
		m_kPredictedPosition(DiVec3::ZERO),
		m_fRadius(DEFAULT_RADIUS),
		m_bInnerCollision(false)
	{
	}
	
	const float DiSphereColliderController::GetRadius(void) const
	{
		return m_fRadius;
	}
	
	void DiSphereColliderController::SetRadius(const float radius)
	{
		m_fRadius = radius;
		m_kSphere.setRadius(m_fRadius);
	}
	
	bool DiSphereColliderController::IsInnerCollision(void) const
	{
		return m_bInnerCollision;
	}
	
	void DiSphereColliderController::SetInnerCollision(bool innerCollision)
	{
		m_bInnerCollision = innerCollision;
	}
	
	void DiSphereColliderController::PreProcessParticles(DiParticleElement* particleTechnique, float timeElapsed)
	{
		DiBaseColliderController::PreProcessParticles(particleTechnique, timeElapsed);
		m_kSphere.setCenter(GetDerivedPosition());
	}
	
	void DiSphereColliderController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		m_kPredictedPosition = particle->position + m_fVelocityScale * particle->direction;
		bool collision = false;
		DiVec3 distance = particle->position - m_kDerivedPosition;
		float distanceLength = distance.length();
		float scaledRadius = 0.3333f * (m_kControllerScale.x + m_kControllerScale.y + m_kControllerScale.z) * m_fRadius; // Scaling changed in V 1.3.1

		switch(m_eIntersectionType)
		{
			case DiBaseColliderController::IT_POINT:
			{
				if (m_bInnerCollision == (distanceLength > scaledRadius))
				{
					particle->position -= m_fVelocityScale * particle->direction;
					collision = true;
				}
				else
				{
					distance = m_kPredictedPosition - m_kDerivedPosition;
					distanceLength = distance.length();
					if (m_bInnerCollision == (distanceLength > scaledRadius))
					{
						collision = true;
					}
				}
			}
			break;

			case DiBaseColliderController::IT_BOX:
			{
				if (particle->particleType != DiParticle::PT_VISUAL)
				{
					break;
				}

				DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
				DiAABB box;
				PopulateAlignedBox(box,
					visualParticle->position, 
					visualParticle->width, 
					visualParticle->height,
					visualParticle->depth);

					if (m_bInnerCollision != box.Intersects(m_kSphere))
					{
						particle->position -= m_fVelocityScale * particle->direction;
						collision = true;
					}
					else
					{
						DiAABB box;
						PopulateAlignedBox(box,
							m_kPredictedPosition, 
							visualParticle->width, 
							visualParticle->height,
							visualParticle->depth);
						if (m_bInnerCollision != box.Intersects(m_kSphere))
						{
							collision = true;
						}
					}
			}
			break;
		}

		if (collision)
		{
			CalculateDirectionAfterCollision(particle, distance, distanceLength);
			CalculateRotationSpeedAfterCollision(particle);
			particle->AddEventFlags(DiParticle::PEF_COLLIDED);
		}
	}
	
	void DiSphereColliderController::CalculateDirectionAfterCollision(DiParticle* particle, DiVec3 distance, float distanceLength)
	{
		switch (m_eCollisionType)
		{
			case DiBaseColliderController::CT_BOUNCE:
			{
				/** ���������������棨��պô�����������棩�������¹�ʽ����
					��ʽ��R = 2 * (-I dot N) * N + I, ����
					R = �µķ�������
					I = ��ײǰ�ķ�����������λ������
					N = ��ײ�㷢��
				*/
				float directionLength = particle->direction.length();
				particle->direction.normalise();
				distance.normalise();
				particle->direction = 2 * (-particle->direction.dotProduct(distance)) * distance + particle->direction;

				particle->direction *= directionLength;

				// ����ϵ������
				particle->direction *= m_fBouncyness;
			}
			break;
			case DiBaseColliderController::CT_FLOW:
			{
				//particle->position = m_kDerivedPosition + distance * (mRadius / distanceLength);
				float scaledRadius = 0.3333f * (m_kControllerScale.x + m_kControllerScale.y + m_kControllerScale.z) * m_fRadius;
				particle->position = m_kDerivedPosition + distance * (scaledRadius / distanceLength);
			}
			break;
		}
	}
	
	void DiSphereColliderController::CopyTo (DiParticleController* affector)
	{
		DiBaseColliderController::CopyTo(affector);

		DiSphereColliderController* sphereCollider = static_cast<DiSphereColliderController*>(affector);
		sphereCollider->m_fRadius = m_fRadius;
		sphereCollider->m_kSphere = m_kSphere;
		sphereCollider->m_bInnerCollision = m_bInnerCollision;
	}
}

