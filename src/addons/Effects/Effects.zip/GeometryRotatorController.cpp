
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "GeometryRotatorController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const bool DiGeometryRotatorController::DEFAULT_USE_OWN			= false;
	const float DiGeometryRotatorController::DEFAULT_ROTATION_SPEED = 10.0f;
	const DiVec3 DiGeometryRotatorController::DEFAULT_ROTATION_AXIS = DiVec3::ZERO;

	DiGeometryRotatorController::DiGeometryRotatorController(void) : 
	DiParticleController(),
		m_fScaledRotationSpeed(0.0f),
		m_bUseOwnRotationSpeed(DEFAULT_USE_OWN),
		m_kQuat(DiQuat::IDENTITY),
		m_kRotationAxis(DEFAULT_ROTATION_AXIS),
		m_bRotationAxisSet(false)
	{
		m_pkDynRotationSpeed = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynRotationSpeed))->SetValue(DEFAULT_ROTATION_SPEED);
	};
	
	DiGeometryRotatorController::~DiGeometryRotatorController(void)
	{
		SAFE_DELETE(m_pkDynRotationSpeed);
	}
	
	const DiVec3& DiGeometryRotatorController::GetRotationAxis(void) const
	{
		return m_kRotationAxis;
	}
	
	void DiGeometryRotatorController::SetRotationAxis(const DiVec3& rotationAxis)
	{
		m_kRotationAxis = rotationAxis;
		m_bRotationAxisSet = true;
	}
	
	void DiGeometryRotatorController::ResetRotationAxis(void)
	{
		m_pkDynRotationSpeed = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynRotationSpeed))->SetValue(DEFAULT_ROTATION_SPEED);
		m_bRotationAxisSet = false;
	}
	
	DiDynamicAttribute* DiGeometryRotatorController::GetRotationSpeed(void) const
	{
		return m_pkDynRotationSpeed;
	}
	
	void DiGeometryRotatorController::SetRotationSpeed(DiDynamicAttribute* dynRotationSpeed)
	{
		SAFE_DELETE(m_pkDynRotationSpeed);

		m_pkDynRotationSpeed = dynRotationSpeed;
	}
	
	bool DiGeometryRotatorController::UseOwnRotationSpeed (void) const
	{
		return m_bUseOwnRotationSpeed;
	}
	
	void DiGeometryRotatorController::SetUseOwnRotationSpeed (bool useOwnRotationSpeed)
	{
		m_bUseOwnRotationSpeed = useOwnRotationSpeed;
	}
	
	float DiGeometryRotatorController::CalculateRotationSpeed(DiParticle* particle)
	{
		return m_kDynamicAttributeHelper.Calculate(m_pkDynRotationSpeed, particle->timeFraction);
	}
	
	void DiGeometryRotatorController::InitParticleForEmission(DiParticle* particle)
	{
		if (particle->particleType != DiParticle::PT_VISUAL)
			return;

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
		if (!m_bRotationAxisSet)
		{
			visualParticle->orientation.x = DiMath::RangeRandom(-1, 1);
			visualParticle->orientation.y = DiMath::RangeRandom(-1, 1);
			visualParticle->orientation.z = DiMath::RangeRandom(-1, 1);
			visualParticle->orientation.w = DiMath::RangeRandom(-1, 1);
			visualParticle->rotationAxis.x = DiMath::UnitRandom();
			visualParticle->rotationAxis.y = DiMath::UnitRandom();
			visualParticle->rotationAxis.z = DiMath::UnitRandom();
		}
		visualParticle->orientation.normalise();

		if (m_bUseOwnRotationSpeed)
		{
			visualParticle->rotationSpeed = CalculateRotationSpeed(particle);
		}
	}
	
	void DiGeometryRotatorController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		if (particle->particleType != DiParticle::PT_VISUAL)
		{
			return;
		}

		DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);

		if (m_bUseOwnRotationSpeed)
		{
			m_fScaledRotationSpeed = visualParticle->rotationSpeed * timeElapsed;
		}
		else
		{
			m_fScaledRotationSpeed = CalculateRotationSpeed(particle) * timeElapsed;
		}

		m_kQuat = DiQuat::IDENTITY;
		if (m_bRotationAxisSet)
		{
			m_kQuat.FromAngleAxis(DiRadian(m_fScaledRotationSpeed), m_kRotationAxis);
		}
		else
		{
			m_kQuat.FromAngleAxis(DiRadian(m_fScaledRotationSpeed), visualParticle->rotationAxis);
		}

		visualParticle->orientation = m_kQuat * visualParticle->orientation;
	}
	
	void DiGeometryRotatorController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiGeometryRotatorController* geometryRotator = static_cast<DiGeometryRotatorController*>(affector);
		geometryRotator->SetRotationSpeed(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetRotationSpeed()));
		geometryRotator->m_bUseOwnRotationSpeed = m_bUseOwnRotationSpeed;
		geometryRotator->m_kRotationAxis = m_kRotationAxis;
		geometryRotator->m_bRotationAxisSet = m_bRotationAxisSet;
	}
}

