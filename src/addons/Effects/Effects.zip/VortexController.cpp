
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "VortexController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"
#include "ParticleSystem.h"

namespace Demi
{
	const DiVec3 DiVortexController::DEFAULT_ROTATION_VECTOR = DiVec3::ZERO;
	const float DiVortexController::DEFAULT_ROTATION_SPEED = 1.0f;

	
	DiVortexController::DiVortexController(void) : 
		DiParticleController(),
		m_kRotation(DiQuat::IDENTITY),
		m_kRotationVector(DEFAULT_ROTATION_VECTOR)
	{
		m_pkDynRotationSpeed = DI_NEW DiAttributeFixed();
		(static_cast<DiAttributeFixed*>(m_pkDynRotationSpeed))->SetValue(DEFAULT_ROTATION_SPEED);
	}
	
	DiVortexController::~DiVortexController(void)
	{
		SAFE_DELETE(m_pkDynRotationSpeed);
	}
	
	const DiVec3& DiVortexController::GetRotationVector(void) const
	{
		return m_kRotationVector;
	}
	
	void DiVortexController::SetRotationVector(const DiVec3& rotationVector)
	{
		m_kRotationVector = rotationVector;
	}
	
	DiDynamicAttribute* DiVortexController::GetRotationSpeed(void) const
	{
		return m_pkDynRotationSpeed;
	}
	
	void DiVortexController::SetRotationSpeed(DiDynamicAttribute* dynRotationSpeed)
	{
		SAFE_DELETE(m_pkDynRotationSpeed);

		m_pkDynRotationSpeed = dynRotationSpeed;
	}
	
	void DiVortexController::PreProcessParticles(DiParticleElement* particleTechnique, float timeElapsed)
	{
		DiParticleSystem* sys = m_pkParentElement->GetParentSystem();
		if (sys)
		{
			m_kRotation.FromAngleAxis(DiRadian(CalculateRotationSpeed() * timeElapsed), sys->GetDerivedOrientation() * m_kRotationVector);
		}
		else
		{
			m_kRotation.FromAngleAxis(DiRadian(CalculateRotationSpeed() * timeElapsed), m_kRotationVector);
		}
		GetDerivedPosition();
	}
	
	DiRadian DiVortexController::CalculateRotationSpeed(void)
	{
		return DiRadian(m_kDynamicAttributeHelper.Calculate(m_pkDynRotationSpeed, m_pkParentElement->GetParentSystem()->GetTimeElapsedSinceStart()));
	}
	
	void DiVortexController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		if (particle->IsFreezed())
		{
			return;
		}

		DiVec3 local = particle->position - m_kDerivedPosition;
		particle->position = m_kDerivedPosition + m_kRotation * local;
		particle->direction = m_kRotation * particle->direction;

		if (particle->particleType == DiParticle::PT_VISUAL)
		{
			DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
			visualParticle->orientation = m_kRotation * visualParticle->orientation;
		}
	}
	
	void DiVortexController::CopyTo (DiParticleController* affector)
	{
		DiParticleController::CopyTo(affector);

		DiVortexController* vortexAffector = static_cast<DiVortexController*>(affector);
		vortexAffector->m_kRotation = m_kRotation;
		vortexAffector->m_kRotationVector = m_kRotationVector;
		vortexAffector->SetRotationSpeed(m_kDynamicAttributeFactory.CloneDynamicAttribute(GetRotationSpeed()));
	}
}

