
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "BoxColliderController.h"
#include "ParticleElement.h"
#include "VisualParticle.h"

namespace Demi
{
	const float DiBoxColliderController::DEFAULT_WIDTH = 100.0f;
	const float DiBoxColliderController::DEFAULT_HEIGHT = 100.0f;
	const float DiBoxColliderController::DEFAULT_DEPTH = 100.0f;
	
	DiBoxColliderController::DiBoxColliderController(void) : 
		DiBaseColliderController(),
		m_fWidth(DEFAULT_WIDTH),
		m_fHeight(DEFAULT_HEIGHT),
		m_fDepth(DEFAULT_DEPTH),
		m_fXmin(0.0f),
		m_fXmax(0.0f),
		m_fYmin(0.0f),
		m_fYmax(0.0f),
		m_fZmin(0.0f),
		m_fZmax(0.0f),
		m_kPredictedPosition(DiVec3::ZERO),
		m_bInnerCollision(false)
	{
	}
	
	const float DiBoxColliderController::GetWidth(void) const
	{
		return m_fWidth;
	}
	
	void DiBoxColliderController::SetWidth(const float width)
	{
		m_fWidth = width;
	}
	
	const float DiBoxColliderController::GetHeight(void) const
	{
		return m_fHeight;
	}
	
	void DiBoxColliderController::SetHeight(const float height)
	{
		m_fHeight = height;
	}
	
	const float DiBoxColliderController::GetDepth(void) const
	{
		return m_fDepth;
	}
	
	void DiBoxColliderController::SetDepth(const float depth)
	{
		m_fDepth = depth;
	}
	
	bool DiBoxColliderController::IsInnerCollision(void) const
	{
		return m_bInnerCollision;
	}
	
	void DiBoxColliderController::SetInnerCollision(bool innerCollision)
	{
		m_bInnerCollision = innerCollision;
	}
	
	void DiBoxColliderController::PreProcessParticles(DiParticleElement* particleTechnique, float timeElapsed)
	{
		DiBaseColliderController::PreProcessParticles(particleTechnique, timeElapsed);

		PopulateAlignedBox(m_kBox, GetDerivedPosition(), m_kControllerScale.x * m_fWidth,
			m_kControllerScale.y * m_fHeight, m_kControllerScale.z * m_fDepth);
		CalculateBounds();
	}
	
	void DiBoxColliderController::Control(DiParticleElement* particleTechnique, DiParticle* particle, float timeElapsed)
	{
		// Ԥ��λ�ã������շ���͵�ǰλ�ü�����ܵ���һ��λ��
		m_kPredictedPosition = particle->position + m_fVelocityScale * particle->direction;

		bool collision = false;

		// ���ȣ��ж�����Ŀǰ�Ƿ�����ײ״̬��������������¼���λ��
		// ������Ϊ��ʱ����ԭ�������ֵ������������ײ֮ǰһ����������������
		// ������һ��m_kPredictedPosition��������Ԥ�⡱���ܵ���һ��λ��������������ײ�ж�
		switch(m_eIntersectionType)
		{
		case DiBaseColliderController::IT_POINT:
			{
				// �ȼ�����ӵ��Ƿ���box�ڲ�
				if (m_bInnerCollision != m_kBox.Intersects(particle->position))
				{
					// ����ײ�����¼���λ��
					particle->position -= m_fVelocityScale * particle->direction;
					collision = true;
				}
				else if (m_bInnerCollision != m_kBox.Intersects(m_kPredictedPosition))
				{
					// ��ײ�Ѽ��
					collision = true;
				}
			}
			break;

		case DiBaseColliderController::IT_BOX:
			{
				if (particle->particleType != DiParticle::PT_VISUAL)
				{
					break;
				}

				DiVisualParticle* visualParticle = static_cast<DiVisualParticle*>(particle);
				DiAABB box;
				PopulateAlignedBox(box,
					visualParticle->position, 
					visualParticle->width, 
					visualParticle->height,
					visualParticle->depth);

				if (m_bInnerCollision != box.Intersects(m_kBox))
				{
					// ����ײ�����¼���λ��
					particle->position -= m_fVelocityScale * particle->direction;
					collision = true;
				}
				else
				{
					DiAABB box;
					PopulateAlignedBox(box,
						m_kPredictedPosition, 
						visualParticle->width, 
						visualParticle->height,
						visualParticle->depth);
					if (m_bInnerCollision != box.Intersects(m_kBox))
					{
						// ��ײ�Ѽ��
						collision = true;
					}
				}
			}
			break;
		}

		if (collision)
		{
			CalculateDirectionAfterCollision(particle);
			CalculateRotationSpeedAfterCollision(particle);
			particle->AddEventFlags(DiParticle::PEF_COLLIDED);
		}
	}
	
	void DiBoxColliderController::CalculateDirectionAfterCollision(DiParticle* particle)
	{
		switch (m_eCollisionType)
		{
		case DiBaseColliderController::CT_BOUNCE:
			{
				// ��������ߣ���ȡ������
				if (IsSmallestValue (particle->position.x - m_fXmin, particle->position))
				{		
					particle->direction.x *= -1;
				}
				else if (IsSmallestValue (m_fXmax - particle->position.x, particle->position))
				{
					particle->direction.x *= -1;
				}
				else if (IsSmallestValue (particle->position.y - m_fYmin, particle->position))
				{
					particle->direction.y *= -1;
				}
				else if (IsSmallestValue (m_fYmax - particle->position.y, particle->position))
				{
					particle->direction.y *= -1;
				}
				else if (IsSmallestValue (particle->position.z - m_fZmin, particle->position))
				{
					particle->direction.z *= -1;
				}
				else if (IsSmallestValue (m_fZmax - particle->position.z, particle->position))
				{
					particle->direction.z *= -1;
				}
				particle->direction *= m_fBouncyness;
			}
			break;
		case DiBaseColliderController::CT_FLOW:
			{
				if (IsSmallestValue (particle->position.x - m_fXmin, particle->position))
				{		
					particle->direction.x = 0;
				}
				else if (IsSmallestValue (m_fXmax - particle->position.x, particle->position))
				{
					particle->direction.x = 0;
				}
				else if (IsSmallestValue (particle->position.y - m_fYmin, particle->position))
				{
					particle->direction.y = 0;
				}
				else if (IsSmallestValue (m_fYmax - particle->position.y, particle->position))
				{
					particle->direction.y = 0;
				}
				else if (IsSmallestValue (particle->position.z - m_fZmin, particle->position))
				{
					particle->direction.z = 0;
				}
				else if (IsSmallestValue (m_fZmax - particle->position.z, particle->position))
				{
					particle->direction.z = 0;
				}
				particle->direction *= -m_fFriction;
			}
			break;
		}
	}
	
	void DiBoxColliderController::CalculateBounds (void)
	{
		float scaledWidth = m_kControllerScale.x * m_fWidth;
		float scaledHeight = m_kControllerScale.y * m_fHeight;
		float scaledDepth = m_kControllerScale.z * m_fDepth;

		m_fXmin = m_kDerivedPosition.x - 0.5f * scaledWidth;
		m_fXmax = m_kDerivedPosition.x + 0.5f * scaledWidth;
		m_fYmin = m_kDerivedPosition.y - 0.5f * scaledHeight;
		m_fYmax = m_kDerivedPosition.y + 0.5f * scaledHeight;
		m_fZmin = m_kDerivedPosition.z - 0.5f * scaledDepth;
		m_fZmax = m_kDerivedPosition.z + 0.5f * scaledDepth;
	}
    
	bool DiBoxColliderController::IsSmallestValue(float value, const DiVec3& particlePosition)
    {
		float value1 = particlePosition.x - m_fXmin;
		float value2 = m_fXmax - particlePosition.x;
		float value3 = particlePosition.y - m_fYmin;
		float value4 = m_fYmax - particlePosition.y;
		float value5 = particlePosition.z - m_fZmin;
		float value6 = m_fZmax - particlePosition.z;

		return (
			value <= value1 && 
			value <= value2 &&
			value <= value3 && 
			value <= value4 &&
			value <= value5 &&
			value <= value6);
    }
	
	void DiBoxColliderController::CopyTo (DiParticleController* affector)
	{
		DiBaseColliderController::CopyTo(affector);

		DiBoxColliderController* boxCollider = static_cast<DiBoxColliderController*>(affector);
		boxCollider->m_fWidth = m_fWidth;
		boxCollider->m_fHeight = m_fHeight;
		boxCollider->m_fDepth = m_fDepth;
		boxCollider->m_bInnerCollision = m_bInnerCollision;
	}
}

