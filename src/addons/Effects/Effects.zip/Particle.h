
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#ifndef Particle_h__
#define Particle_h__

#include "FxPrerequisites.h"

#if DEMI_PLATFORM == DEMI_PLATFORM_WIN32
#   pragma warning(disable:4800)
#endif

namespace Demi
{
	class DEMI_FX_API DiParticle
	{
	public:

		static float DEFAULT_TTL;
		static float DEFAULT_MASS;
		enum ParticleType
		{
			PT_VISUAL,

			PT_UNUSED
		};

		enum ReservedParticleEventFlags
		{
			PEF_EXPIRED = 1<<0,
			PEF_EMITTED = 1<<1,
			PEF_COLLIDED = 1<<2
		};

	public:

		DiParticle():
		  m_bMarkedForEmission(false),
			  position(DiVec3::ZERO),
			  m_kDerivedPosition(DiVec3::ZERO),
			  direction(DiVec3::ZERO),
			  timeToLive(DEFAULT_TTL),
			  totalTimeToLive(DEFAULT_TTL),
			  timeFraction(0.0f),
			  particleType(PT_VISUAL),
			  mass(DEFAULT_MASS),
			  m_uiEventFlags(0),
			  m_bEnabled(true),
			  m_bFreezed(false),
			  m_bOriginalEnabled(true),
			  m_bOriginalEnabledSet(false),
			  originalPosition(DiVec3::ZERO),
			  latestPosition(DiVec3::ZERO),
			  originalDirection(DiVec3::ZERO),
			  originalDirectionLength(0.0f),
			  originalScaledDirectionLength(0.0f),
			  originalVelocity(0.0f),
			  parentEmitter(0),
			  visualData(0){}

		  virtual ~DiParticle();

	public:

		DiParticleEmitter*	parentEmitter;

		DiVec3 				position;

		DiVec3 				direction;

		// �����������������Ҫ�����������������������
		float				mass;

		// ����ʣ����ʱ��
		float				timeToLive;

		// �ܴ��ʱ��
		float				totalTimeToLive;

		// ʱ�������һ���ɿ�����ʹ��
		float				timeFraction;

		ParticleType		particleType;

		DiIVisualData*		visualData;

		DiVec3 				originalPosition;

		DiVec3 				originalDirection;

		float 				originalVelocity;

		float 				originalDirectionLength;

		float 				originalScaledDirectionLength;

		DiVec3				latestPosition;

	public:

		inline bool			IsMarkedForEmission(void) const {return m_bMarkedForEmission;}

		inline void			SetMarkedForEmission(bool markedForEmission) {m_bMarkedForEmission = markedForEmission;}

		virtual void 		InitForEmission(void);

		virtual void 		InitForExpiration(DiParticleElement* technique, float timeElapsed);

		virtual bool 		IsEnabled(void) const;

		virtual void 		SetEnabled(bool enabled);

		void 				SetOriginalEnabled(bool originalEnabled);

		bool 				GetOriginalEnabled(void) const;

		bool 				IsFreezed(void) const;

		void 				SetFreezed(bool freezed);

		inline void 		SetEventFlags(uint32 flags) {m_uiEventFlags = flags;}

		inline void 		AddEventFlags(uint32 flags) {m_uiEventFlags |= flags;}

		inline void 		RemoveEventFlags(uint32 flags) {m_uiEventFlags &= ~flags;}

		inline uint32		GetEventFlags(void) const {return m_uiEventFlags;}

		inline bool			HasEventFlags(uint32 flags) const {return m_uiEventFlags & flags;}

		virtual void		Process(DiParticleElement* technique, float timeElapsed);

		float				CalculateVelocity(void) const;

		virtual void		CopyTo (DiParticle* particle);

	protected:

		// �¼����
		uint32				m_uiEventFlags;

		// �Ƿ���ı��
		bool 				m_bMarkedForEmission;

		bool 				m_bEnabled;

		bool 				m_bFreezed;

		bool 				m_bOriginalEnabled;

		bool 				m_bOriginalEnabledSet;

		DiVec3				m_kDerivedPosition;
	};
}

#endif // Particle_h__
