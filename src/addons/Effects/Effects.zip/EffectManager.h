
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#ifndef EffectManager_h__
#define EffectManager_h__

#include "FxPrerequisites.h"
#include "DynamicAttribute.h"

namespace Demi
{
	class DEMI_FX_API DiEffectManager : public DiBase
    {
	friend class DiParticleSystemFactory;

	public:
		DiEffectManager (DiSceneManager* sm);

		~DiEffectManager (void);

		void						InitFactories();

		void						ReleaseFactories();

		void						DestroyAllParticleSystemTemplates(void);

		void						AddEmitterFactory(DiParticleEmitterFactory* factory);

		DiParticleEmitterFactory*	GetEmitterFactory(const DiString& emitterType);

		void 						RemoveEmitterFactory(const DiString& emitterType);

		void 						DestroyEmitterFactory(const DiString& emitterType);

		DiParticleEmitter* 			CreateEmitter(const DiString& emitterType);

		DiParticleEmitter* 			CloneEmitter(DiParticleEmitter* emitter);

		void 						DestroyEmitter(DiParticleEmitter* emitter);

		void 						AddControllerFactory(DiParticleControllerFactory* factory);

		DiParticleControllerFactory*GetControllerFactory(const DiString& affectorType);

		void 						RemoveControllerFactory(const DiString& affectorType);

		void 						DestroyControllerFactory(const DiString& affectorType);

		DiParticleController* 		CreateController(const DiString& affectorType);

		DiParticleController* 		CloneController(DiParticleController* affector);

		void						DestroyController(DiParticleController* affector);

		DiParticleElement* 			CreateElement(void);

		DiParticleElement* 			CloneElement(DiParticleElement* technique);

		void 						DestroyElement(DiParticleElement* technique);

		void 						AddRendererFactory(DiParticleRendererFactory* factory);

		DiParticleRendererFactory*	GetRendererFactory(const DiString& rendererType);

		void 						RemoveRendererFactory(const DiString& affectorType);

		void 						DestroyRendererFactory(const DiString& rendererType);

		DiParticleRenderer* 		CreateRenderer(const DiString& rendererType);

		DiParticleRenderer* 		CloneRenderer(DiParticleRenderer* renderer);

		void						DestroyRenderer(DiParticleRenderer* renderer);

		// ��������ϵͳģ�壬һ��ģ����Դ����������Ч
		// ģ�����ձ���Ϊ�ļ�
		DiParticleSystem*			CreateParticleSystemTemplate(const DiString& name);

		void						ReplaceParticleSystemTemplate(const DiString& name, DiParticleSystem* system);

		const DiString&				GetLastCreatedTemplateName(void);

		void						AddParticleSystemTemplate(const DiString& name, DiParticleSystem* systemTemplate);

		DiParticleSystem*			GetParticleSystemTemplate(const DiString& templateName);

		void 						DestroyParticleSystemTemplate(const DiString& templateName);

		void 						ParticleSystemTemplateNames(DiVector<DiString>& v);

		// ��ģ������������Ч
		DiParticleSystem*			CreateParticleSystem(const DiString& name, 
										const DiString& templateName);

		// ����һ��Ĭ�ϵ���Ч
		DiParticleSystem*			CreateParticleSystem(const DiString& name);

		DiParticleSystem*			GetParticleSystem(const DiString& name);

		void 						DestroyParticleSystem(DiParticleSystem* particleSystem);

		void 						DestroyParticleSystem(const DiString& particleSystemName);

		void 						DestroyAllParticleSystems();

		DiDynamicAttribute*			CreateDynamicAttribute(DiDynamicAttribute::DynamicAttributeType type);

		void						Update();
		
	protected:
		
		DiParticleSystem* 			CreateSystemImpl(const DiString& name);

		DiParticleSystem* 			CreateSystemImpl(const DiString& name, const DiString& templateName);

		void						DestroySystemImpl(DiParticleSystem* particleSystem);

	protected:

		typedef DiMap<DiString, DiParticleEmitterFactory*> EmitterFactoryMap;
		EmitterFactoryMap			m_kEmitterFactories;

		typedef DiMap<DiString, DiParticleControllerFactory*> ControllerFactoryMap;
		ControllerFactoryMap		m_kControllerFactories;

		typedef DiMap<DiString, DiParticleRendererFactory*> RendererFactoryMap;
		RendererFactoryMap			m_kRendererFactories;

		typedef DiMap<DiString, DiParticleSystem*> ParticleSystemTemplateMap;
		ParticleSystemTemplateMap	m_kParticleSystemTemplates;

		typedef DiMap<DiString, DiParticleSystem*> ParticleSystemMap;
		ParticleSystemMap			m_kParticleSystems;

		DiParticleSystemFactory*	m_pkParticleSystemFactory;

		DiString					m_kLastCreatedTemplateName;

		DiSceneManager*				m_pkSceneManager;
	};
}

#endif // EffectManager_h__
