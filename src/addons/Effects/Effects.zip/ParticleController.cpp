
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ParticleController.h"
#include "ParticleEmitter.h"
#include "ParticleElement.h"
#include "ParticleSystem.h"

namespace Demi
{
	const bool DiParticleController::DEFAULT_ENABLED = true;
	const DiVec3 DiParticleController::DEFAULT_POSITION = DiVec3::ZERO;
	const DiParticleController::ControlSpecial DiParticleController::DEFAULT_SPECIALISATION = DiParticleController::AFSP_DEFAULT;

	DiParticleController::DiParticleController(void) :
		DiParticle(),
		m_pkParentElement(0),
		m_kName(DiString::BLANK),
		m_kControllerScale(DiVec3::UNIT_SCALE),
		m_kControllerSpecialisation(DiParticleController::AFSP_DEFAULT)
	{
		particleType = PT_UNUSED;
	};
	
	void DiParticleController::NotifyStart (void)
	{
		SetEnabled(m_bOriginalEnabled);
	}
	
	void DiParticleController::NotifyRescaled(const DiVec3& scale)
	{
		m_kControllerScale = scale;
	}
	
	void DiParticleController::InitForEmission(void)
	{
		DiParticle::InitForEmission();
		NotifyStart();
	}
	
	void DiParticleController::InitForExpiration(DiParticleElement* technique, float timeElapsed)
	{
		DiParticle::InitForExpiration(technique, timeElapsed);
		NotifyStop();
	}
	
	void DiParticleController::CopyTo(DiParticleController* affector)
	{
		CopyParentTo(affector);
	}
	
	void DiParticleController::CopyParentTo(DiParticleController* affector)
	{
		DiParticle::CopyTo(affector);

		affector->SetName(m_kName);
		affector->m_pkParentElement = m_pkParentElement;
		affector->m_kControllerScale = m_kControllerScale;
		affector->m_kControllerSpecialisation = m_kControllerSpecialisation;
		affector->m_kExcludedEmitters = DiList<DiString>(m_kExcludedEmitters); // Use copy constructor
	}
	
	void DiParticleController::SetParentElement(DiParticleElement* parentTechnique)
	{
		m_pkParentElement = parentTechnique;
	}
	
	void DiParticleController::ProcessParticle(DiParticleElement* particleTechnique, 
		DiParticle* particle, float timeElapsed, bool firstParticle)
	{
		if (firstParticle)
		{
			FirstParticle(particleTechnique, particle, timeElapsed);
		}

		if (!m_kExcludedEmitters.empty() && particle->parentEmitter)
		{
			DiString emitterName = particle->parentEmitter->GetName();
			DiList<DiString>::iterator it;
			it = std::find(m_kExcludedEmitters.begin(), m_kExcludedEmitters.end(), emitterName);
			if (it != m_kExcludedEmitters.end())
			{
				return;
			}
		}

		Control(particleTechnique, particle, timeElapsed);
	}
	
	void DiParticleController::AddEmitterToExclude(const DiString& emitterName)
	{
		DiList<DiString>::iterator it;
		it = std::find(m_kExcludedEmitters.begin(), m_kExcludedEmitters.end(), emitterName);
		if (it == m_kExcludedEmitters.end())
		{
			m_kExcludedEmitters.push_back(emitterName);
		}
	}
	
	void DiParticleController::RemoveEmitterToExclude(const DiString& emitterName)
	{
		DiList<DiString>::iterator it;
		it = std::find(m_kExcludedEmitters.begin(), m_kExcludedEmitters.end(), emitterName);
		if (it != m_kExcludedEmitters.end())
		{
			m_kExcludedEmitters.erase(it);
		}
	}
	
	void DiParticleController::RemoveAllEmittersToExclude(void)
	{
		m_kExcludedEmitters.clear();
	}
	
	const DiList<DiString>& DiParticleController::GetEmittersToExclude(void) const
	{
		return m_kExcludedEmitters;
	}
	
	bool DiParticleController::HasEmitterToExclude(const DiString& emitterName)
	{
		DiList<DiString>::iterator it;
		it = std::find(m_kExcludedEmitters.begin(), m_kExcludedEmitters.end(), emitterName);
		return (it != m_kExcludedEmitters.end());
	}
	
	const DiVec3& DiParticleController::GetDerivedPosition(void)
	{
		if (m_bMarkedForEmission)
		{
			m_kDerivedPosition = position;
		}
		else
		{
			m_kDerivedPosition = m_pkParentElement->GetDerivedPosition() + 
				(m_pkParentElement->GetParentSystem()->GetDerivedOrientation() * (m_kControllerScale * position));
		}
		return m_kDerivedPosition;
	}
	
	float DiParticleController::CalculateAffectSpecialisationFactor (const DiParticle* particle)
	{
		switch (m_kControllerSpecialisation)
		{
		case AFSP_DEFAULT:
			return 1.0f;
			break;

		case AFSP_TTL_INCREASE:
			{
				if (particle)
				{
					return particle->timeFraction;
				}
				else
				{
					return 1.0f;
				}
			}
			break;

		case AFSP_TTL_DECREASE:
			{
				if (particle)
				{
					return 1.0f - particle->timeFraction;
				}
				else
				{
					return 1.0f;
				}
			}
			break;

		default:
			return 1.0f;
			break;
		}
	}

	void DiParticleController::SetControllerSpecialisation( const ControlSpecial& affectSpecialisation )
	{
		m_kControllerSpecialisation = affectSpecialisation;
	}

}

