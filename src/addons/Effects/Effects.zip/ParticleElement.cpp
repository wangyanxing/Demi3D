
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#include "FxPch.h"
#include "ParticleElement.h"
#include "ParticleEmitter.h"
#include "ParticleRenderer.h"
#include "ParticleController.h"
#include "ParticleSystem.h"
#include "VisualParticle.h"
#include "AssetManager.h"
#include "EffectManager.h"

namespace Demi
{
	DiRadixSort<DiParticlePoolBase<DiVisualParticle>::PoolList, DiParticle*, float> DiParticleElement::m_kRadixSorter;
	
	const bool				DiParticleElement::DEFAULT_ENABLED						= true;
	const DiVec3			DiParticleElement::DEFAULT_POSITION						= DiVec3::ZERO;
	const bool				DiParticleElement::DEFAULT_KEEP_LOCAL					= false;
	const size_t 			DiParticleElement::DEFAULT_VISUAL_PARTICLE_QUOTA 		= 500;
	const size_t 			DiParticleElement::DEFAULT_EMITTED_EMITTER_QUOTA 		= 50;
	const size_t 			DiParticleElement::DEFAULT_EMITTED_TECHNIQUE_QUOTA		= 10;
	const size_t 			DiParticleElement::DEFAULT_EMITTED_AFFECTOR_QUOTA		= 10;
	const size_t 			DiParticleElement::DEFAULT_EMITTED_SYSTEM_QUOTA			= 10;
	const unsigned short	DiParticleElement::DEFAULT_LOD_INDEX					= 0;
	const float 			DiParticleElement::DEFAULT_DEFAULT_WIDTH				= 50;
	const float 			DiParticleElement::DEFAULT_DEFAULT_HEIGHT				= 50;
	const float 			DiParticleElement::DEFAULT_DEFAULT_DEPTH				= 50;
	const unsigned short 	DiParticleElement::DEFAULT_SPATIAL_HASHING_CELL_DIM 	= 15;
	const unsigned short 	DiParticleElement::DEFAULT_SPATIAL_HASHING_CELL_OVERLAP = 0;
	const size_t			DiParticleElement::DEFAULT_SPATIAL_HASHING_TABLE_SIZE	= 50;
	const float 			DiParticleElement::DEFAULT_SPATIAL_HASHING_INTERVAL		= 0.05f;
	const float 			DiParticleElement::DEFAULT_MAX_VELOCITY					= 9999.0f;

	DiParticleElement::DiParticleElement(void) : 
		DiParticle(),
		m_pkParentSystem(NULL),
		m_kName(DiString::BLANK),
		m_pkRenderer(NULL),
		m_uiVisualParticleQuota(DEFAULT_VISUAL_PARTICLE_QUOTA),
		m_uiEmittedEmitterQuota(DEFAULT_EMITTED_EMITTER_QUOTA),
		m_uiEmittedTechniqueQuota(DEFAULT_EMITTED_TECHNIQUE_QUOTA),
		m_uiEmittedAffectorQuota(DEFAULT_EMITTED_AFFECTOR_QUOTA),
		m_uiEmittedSystemQuota(DEFAULT_EMITTED_SYSTEM_QUOTA),
		m_bVisualParticlePoolIncreased(false),
		m_bSuppressNotifyEmissionChange(true),
		m_fDefaultWidth(DEFAULT_DEFAULT_WIDTH),
		m_fDefaultHeight(DEFAULT_DEFAULT_HEIGHT),
		m_fDefaultDepth(DEFAULT_DEFAULT_DEPTH),
		m_sMaterialName(DiString::BLANK),
		m_usLodIndex(DEFAULT_LOD_INDEX),
		m_fCameraSquareDistance(0),
		m_bPrepareController(false),
		m_bPrepareEmitter(false),
		m_kWorldAABB(),
		m_bUpdateWorldAABB(false),
		m_kMinWorldExtend(DiVec3::ZERO),
		m_kMaxWorldExtend(DiVec3::ZERO),
		m_bHasExtents(false),
		m_bKeepLocal(DEFAULT_KEEP_LOCAL),
		m_kParticleSystemScale(DiVec3::UNIT_SCALE),
		m_fParticleSystemScaleVelocity(1.0),
		m_fMaxVelocity(DEFAULT_MAX_VELOCITY),
		m_bMaxVelocitySet(false),
		m_uiMaxNumVisualParticles(0),
		m_uiMaxNumEmitterParticles(0),
		m_uiMaxNumTechniqueParticles(0),
		m_uiMaxNumAffectorParticles(0),
		m_uiMaxNumSystemParticles(0)
	{
		particleType = PT_UNUSED;
		SetMaterialName("BaseWhite");
		m_kPool.SetParentElement(this);
	}
	
	DiParticleElement::~DiParticleElement(void)
	{
		m_bSuppressNotifyEmissionChange = true;
		DestroyAllEmitters();
		DestroyAllControllers();
		DestroyRenderer();
	}
	
	void DiParticleElement::InitParticleForEmission(DiParticle* particle)
	{
		if (!m_kElementListenerList.empty())
		{
			ElementListenerIterator it;
			ElementListenerIterator itEnd = m_kElementListenerList.end();
			for (it = m_kElementListenerList.begin(); it != itEnd; ++it)
			{
				(*it)->ParticleEmitted(this, particle);
			}
		}
	}
	
	void DiParticleElement::InitForEmission(void)
	{
		DiParticle::InitForEmission();

		NotifyStart();

		m_kPool.LockAllParticles();
	}
	
	void DiParticleElement::InitForExpiration(DiParticleElement* technique, float timeElapsed)
	{
		DiParticle::InitForExpiration(technique, timeElapsed);
		NotifyStop();
	}
	
	void DiParticleElement::MarkForEmission(void)
	{
		ResetMarkForEmission();

		ParticleEmitterList::iterator emitterIt;
		ParticleEmitterList::iterator emitterItEnd = m_kEmitters.end();

		for (emitterIt = m_kEmitters.begin(); emitterIt != emitterItEnd; ++emitterIt)
		{
			MarkForEmission(*emitterIt);
		}
	}
	
	void DiParticleElement::MarkForEmission(DiParticleEmitter* emitter, bool mark)
	{
	}
	
	void DiParticleElement::ResetMarkForEmission(void)
	{
		ParticleAffectorIterator affectorIt;
		ParticleAffectorIterator affectorItEnd = m_kControllers.end();
		for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
		{
			(*affectorIt)->SetMarkedForEmission(false);
		}
	}
	
	void DiParticleElement::NotifyUpdateBounds()
	{
		if (m_kPool.IsEmpty())
		{
			ResetBounds();
			m_bUpdateWorldAABB = false;
		}
		else
		{
			m_bUpdateWorldAABB = true;
		}
	}
	
	void DiParticleElement::ResetBounds()
	{
		m_kWorldAABB.SetNull();
		DiVec3 position = GetDerivedPosition();
		m_kMinWorldExtend = position;
		m_kMaxWorldExtend = position;
		m_bHasExtents = false;
	}
	
	void DiParticleElement::NotifyRescaled(const DiVec3& scale)
	{
		m_kParticleSystemScale = scale;

		ParticleEmitterList::iterator itEmitter;
		ParticleEmitterList::iterator itEmitterEnd = m_kEmitters.end();
		for (itEmitter = m_kEmitters.begin(); itEmitter != itEmitterEnd; ++itEmitter)
		{
			(*itEmitter)->NotifyRescaled(scale);
		}
		
		ParticleAffectorIterator itAffector;
		ParticleAffectorIterator itAffectorEnd = m_kControllers.end();
		for (itAffector = m_kControllers.begin(); itAffector != itAffectorEnd; ++itAffector)
		{
			(*itAffector)->NotifyRescaled(scale);
		}

		if (m_pkRenderer)
		{
			m_pkRenderer->NotifyRescaled(scale);
		}
	}
	
	void DiParticleElement::NotifyVelocityRescaled(const float& scaleVelocity)
	{
		m_fParticleSystemScaleVelocity = scaleVelocity;
	}
	
	size_t DiParticleElement::GetVisualParticleQuota(void) const 
	{
		return m_uiVisualParticleQuota;
	}
	
	void DiParticleElement::SetVisualParticleQuota(size_t quota) 
	{
		m_uiVisualParticleQuota = quota;
		m_bVisualParticlePoolIncreased = false;
	}
	
	size_t DiParticleElement::GetEmittedEmitterQuota(void) const
	{
		return m_uiEmittedEmitterQuota;
	}
	
	void DiParticleElement::SetEmittedEmitterQuota(size_t quota)
	{
		m_uiEmittedEmitterQuota = quota;
		//mParticleEmitterPoolIncreased = false;
	}
	
	size_t DiParticleElement::GetEmittedTechniqueQuota(void) const
	{
		return m_uiEmittedTechniqueQuota;
	}
	
	void DiParticleElement::SetEmittedTechniqueQuota(size_t quota)
	{
		m_uiEmittedTechniqueQuota = quota;
		//mParticleTechniquePoolIncreased = false;
	}
	
	size_t DiParticleElement::GetEmittedAffectorQuota(void) const
	{
		return m_uiEmittedAffectorQuota;
	}
	
	void DiParticleElement::SetEmittedAffectorQuota(size_t quota)
	{
		m_uiEmittedAffectorQuota = quota;
		//mParticleAffectorPoolIncreased = false;
	}
	
	size_t DiParticleElement::GetEmittedSystemQuota(void) const
	{
		return m_uiEmittedSystemQuota;
	}
	
	void DiParticleElement::SetEmittedSystemQuota(size_t quota)
	{
		m_uiEmittedSystemQuota = quota;
		//mParticleSystemPoolIncreased = false;
	}
	
	const float DiParticleElement::GetDefaultWidth(void) const
	{
		return m_fDefaultWidth;
	}
	
	void DiParticleElement::SetDefaultWidth(const float width)
	{
		m_fDefaultWidth = width;
		if (m_pkRenderer)
		{
			m_pkRenderer->NotifyDefaultDimensions(m_kParticleSystemScale.x * m_fDefaultWidth, 
				m_kParticleSystemScale.y * m_fDefaultHeight, 
				m_kParticleSystemScale.z * m_fDefaultDepth);
		}
	}
	
	const float DiParticleElement::GetDefaultHeight(void) const
	{
		return m_fDefaultHeight;
	}
	
	void DiParticleElement::SetDefaultHeight(const float height)
	{
		m_fDefaultHeight = height;
		if (m_pkRenderer)
		{
			m_pkRenderer->NotifyDefaultDimensions(m_kParticleSystemScale.x * m_fDefaultWidth, 
				m_kParticleSystemScale.y * m_fDefaultHeight, 
				m_kParticleSystemScale.z * m_fDefaultDepth);
		}
	}
	
	const float DiParticleElement::GetDefaultDepth(void) const
	{
		return m_fDefaultDepth;
	}
	
	void DiParticleElement::SetDefaultDepth(const float depth)
	{
		m_fDefaultDepth = depth;
		if (m_pkRenderer)
		{
			m_pkRenderer->NotifyDefaultDimensions(m_kParticleSystemScale.x * m_fDefaultWidth, 
				m_kParticleSystemScale.y * m_fDefaultHeight, 
				m_kParticleSystemScale.z * m_fDefaultDepth);
		}
	}
	
	void DiParticleElement::SuppressNotifyEmissionChange(bool suppress)
	{
		m_bSuppressNotifyEmissionChange = suppress;
	}
	
	const DiString& DiParticleElement::GetMaterialName(void) const
	{
		return m_sMaterialName;
	}
	
	const DiMaterialPtr DiParticleElement::GetMaterial(void) const
	{
		return DiAssetManager::GetInstance().GetAsset(m_sMaterialName,ASSET_MATERIAL);
	}
	
	void DiParticleElement::SetMaterialName(const DiString& materialName)
	{
		m_sMaterialName = materialName;
		if (m_pkRenderer)
		{
			m_pkRenderer->SetMaterialName(m_sMaterialName);
		}
	}
	
	DiParticleEmitter* DiParticleElement::CreateEmitter(const DiString& emitterType)
	{
		MT_ASSERT(emitterType != DiString::BLANK);
		DiParticleEmitter* emitter = GetParentSystem()->GetEffectManager()->CreateEmitter(emitterType);
		AddEmitter(emitter);
		return emitter;
	}
	
	void DiParticleElement::AddEmitter (DiParticleEmitter* emitter)
	{
		MT_ASSERT(emitter);
		m_kEmitters.push_back(emitter);
		emitter->SetParentElement(this);
		m_bPrepareEmitter = true;
		NotifyEmissionChange();
	}
	
	void DiParticleElement::RemoveEmitter(DiParticleEmitter* emitter)
	{
		MT_ASSERT(emitter);
		ParticleEmitterList::iterator it;
		ParticleEmitterList::iterator itEnd = m_kEmitters.end();
		bool notify = false;
		for (it = m_kEmitters.begin(); it != itEnd; ++it)
		{
			if (*it == emitter)
			{
				notify = emitter->GetEmitsName() != DiString::BLANK;

				m_kEmitters.erase(it);
				break;
			}
		}

		emitter->SetParentElement(0);

		if (notify)
		{
			NotifyEmissionChange();
		}
	}
	
	DiParticleEmitter* DiParticleElement::GetEmitter (size_t index) const
	{
		MT_ASSERT(index < m_kEmitters.size());
		return m_kEmitters[index];
	}
	
	DiParticleEmitter* DiParticleElement::GetEmitter (const DiString& emitterName) const
	{
		if (emitterName == DiString::BLANK)
		{
			return 0;
		}

		ParticleEmitterIterator it;
		ParticleEmitterIterator itEnd = m_kEmitters.end();
		for (it = m_kEmitters.begin(); it != itEnd; ++it)
		{
			if ((*it)->GetName() == emitterName)
			{
				return *it;
			}
		}
		
		return 0;
	}
	
	size_t DiParticleElement::GetNumEmitters (void) const
	{
		return m_kEmitters.size();
	}
	
	size_t DiParticleElement::GetNumEmittedEmitters (void) const
	{
		return 0;
	}
	
	void DiParticleElement::DestroyEmitter(DiParticleEmitter* emitter)
	{
		MT_ASSERT(emitter);
		ParticleEmitterList::iterator it;
		ParticleEmitterList::iterator itEnd = m_kEmitters.end();
		bool notify = false;
		for (it = m_kEmitters.begin(); it != itEnd; ++it)
		{
			if (*it == emitter)
			{
				notify = emitter->GetEmitsName() != DiString::BLANK;

				GetParentSystem()->GetEffectManager()->DestroyEmitter(*it);
				m_kEmitters.erase(it);
				break;
			}
		}

		if (notify)
		{
			NotifyEmissionChange();
		}
	}
	
	void DiParticleElement::DestroyEmitter (size_t index)
	{
		DestroyEmitter(GetEmitter(index));
	}
	
	void DiParticleElement::DestroyAllEmitters(void)
	{
		ParticleEmitterList::iterator it;
		ParticleEmitterList::iterator itEnd = m_kEmitters.end();
		for (it = m_kEmitters.begin(); it != itEnd; ++it)
		{
			GetParentSystem()->GetEffectManager()->DestroyEmitter(*it);
		}
		m_kEmitters.clear();
	}

	
	DiParticleController* DiParticleElement::CreateController(const DiString& affectorType)
	{
		MT_ASSERT(affectorType != DiString::BLANK && "affectorType is empty!");
		DiParticleController* affector = GetParentSystem()->GetEffectManager()->CreateController(affectorType);
		AddControlle(affector);
		return affector;
	}
	
	void DiParticleElement::AddControlle (DiParticleController* affector)
	{
		MT_ASSERT(affector);
		m_kControllers.push_back(affector);
		affector->SetParentElement(this);
		m_bPrepareController = true;
	}
	
	void DiParticleElement::RemoveController (DiParticleController* affector)
	{
		MT_ASSERT(affector);
		ParticleControllerList::iterator it;
		ParticleControllerList::iterator itEnd = m_kControllers.end();
		for (it = m_kControllers.begin(); it != itEnd; ++it)
		{
			if (*it == affector)
			{
				m_kControllers.erase(it);
				break;
			}
		}

		affector->SetParentElement(NULL);
	}
	
	DiParticleController* DiParticleElement::GetController (size_t index) const
	{
		MT_ASSERT(index < m_kControllers.size());
		return m_kControllers[index];
	}
	
	DiParticleController* DiParticleElement::GetController (const DiString& controllerName) const
	{
		if (controllerName == DiString::BLANK)
		{
			return 0;
		}

		ParticleAffectorIterator it;
		ParticleAffectorIterator itEnd = m_kControllers.end();
		for (it = m_kControllers.begin(); it != itEnd; ++it)
		{
			if ((*it)->GetName() == controllerName)
			{
				return *it;
			}
		}
		
		return 0;
	}
	
	size_t DiParticleElement::GetNumControllers (void) const
	{
		return m_kControllers.size();
	}
	
	size_t DiParticleElement::GetNumEmittedControllers (void) const
	{
		ParticleAffectorIterator it;
		ParticleAffectorIterator itEnd = m_kControllers.end();
		size_t count = 0;
		for (it = m_kControllers.begin(); it != itEnd; ++it)
		{
			if ((*it)->IsMarkedForEmission())
			{
				count++;
			}
		}

		return count;
	}
	
	void DiParticleElement::DestroyController(DiParticleController* affector)
	{
		MT_ASSERT(affector);
		ParticleControllerList::iterator it;
		ParticleControllerList::iterator itEnd = m_kControllers.end();
		for (it = m_kControllers.begin(); it != itEnd; ++it)
		{
			if (*it == affector)
			{
				GetParentSystem()->GetEffectManager()->DestroyController(*it);
				m_kControllers.erase(it);
				break;
			}
		}
	}
	
	void DiParticleElement::DestroyController (size_t index)
	{
		DestroyController(GetController(index));
	}
	
	void DiParticleElement::DestroyAllControllers(void)
	{
		ParticleAffectorIterator it;
		ParticleAffectorIterator itEnd = m_kControllers.end();
		for (it = m_kControllers.begin(); it != itEnd; ++it)
		{
			GetParentSystem()->GetEffectManager()->DestroyController(*it);
		}
		m_kControllers.clear();
	}

	DiParticleRenderer* DiParticleElement::GetRenderer(void) const
	{
		return m_pkRenderer;
	}
	
	void DiParticleElement::SetRenderer(const DiString& rendererType)
	{
		if (m_pkRenderer)
		{
			DestroyRenderer();
		}

		if (rendererType != DiString::BLANK)
		{
			m_pkRenderer = GetParentSystem()->GetEffectManager()->CreateRenderer(rendererType);
			m_pkRenderer->SetParentElement(this);
			m_pkRenderer->SetRendererInitialised(false);
		}
	}
	
	void DiParticleElement::SetRenderer(DiParticleRenderer* renderer)
	{
		if (!renderer)
		{
			return;
		}

		if (m_pkRenderer)
		{
			DestroyRenderer();
		}

		m_pkRenderer = renderer;
		m_pkRenderer->SetParentElement(this);
		m_pkRenderer->SetRendererInitialised(false);
	}
	
	void DiParticleElement::RemoveRenderer(DiParticleRenderer* renderer)
	{
		m_pkRenderer = NULL;
		renderer->SetParentElement(NULL);
	}
	
	void DiParticleElement::DestroyRenderer(void)
	{
		if (m_pkRenderer)
		{
			GetParentSystem()->GetEffectManager()->DestroyRenderer(m_pkRenderer);
			m_pkRenderer = 0;
		}
	}
	
	void DiParticleElement::UpdateBatchGroup(DiRenderBatchGroup* queue,DiCamera* cam)
	{
		if (m_pkRenderer && m_pkRenderer->IsRendererInitialised())
		{
			if (m_bEnabled || m_pkParentSystem->IsSmoothLod())
			{
				m_pkRenderer->UpdateBatchGroup(queue, cam, &m_kPool);
			}
		}
	}
	
	void DiParticleElement::SetBatchGroupID(uint8 queueId)
	{
		if (m_pkRenderer)
		{
			m_pkRenderer->SetBatchGroupID(queueId);
		}
	}
	
	void DiParticleElement::Prepare(void)
	{
		PrepareRenderer();
		PrepareEmitters();
		PrepareAffectors();
		PrepareTechnique();
		PrepareSystem();
		PrepareVisualParticles();

		NotifyRescaled(m_kParticleSystemScale);
		NotifyVelocityRescaled(m_fParticleSystemScaleVelocity);
	}
	
	void DiParticleElement::PrepareSystem(void)
	{
	}
	
	void DiParticleElement::UnprepareSystem(void)
	{
	}
	
	void DiParticleElement::PrepareTechnique(void)
	{
	}
	
	void DiParticleElement::UnprepareTechnique(void)
	{
	}
	
	void DiParticleElement::PrepareVisualParticles(void)
	{
		if (!m_bVisualParticlePoolIncreased)
		{
			m_kPool.IncreasePool(DiParticle::PT_VISUAL, m_uiVisualParticleQuota, this);
			m_bVisualParticlePoolIncreased = true;
		}
	}
	
	void DiParticleElement::UnprepareVisualParticles(void)
	{
		m_kPool.DestroyParticles(DiParticle::PT_VISUAL);
		m_bVisualParticlePoolIncreased = false;
	}
	
	void DiParticleElement::PrepareRenderer(void)
	{
		if (m_pkRenderer && !m_pkRenderer->IsRendererInitialised())
		{
			m_pkRenderer->Prepare(this);
			m_pkRenderer->SetRendererInitialised(true);
		}
	}
	
	void DiParticleElement::UnprepareRenderer(void)
	{
		if (m_pkRenderer && m_pkRenderer->IsRendererInitialised())
		{
			m_pkRenderer->Unprepare(this);
			m_pkRenderer->SetRendererInitialised(false);
		}
	}
	
	void DiParticleElement::PrepareEmitters(void)
	{
	}
	
	void DiParticleElement::UnprepareEmitters(void)
	{
	}
	
	void DiParticleElement::PrepareAffectors(void)
	{
	}
	
	void DiParticleElement::UnprepareAffectors(void)
	{
	}
	
	void DiParticleElement::Update(float timeElapsed)
	{
		if (!m_bEnabled)
		{
			if (!m_pkParentSystem->IsSmoothLod())
			{
				return;
			}
			else if (m_kPool.IsEmpty())
			{
				return;
			}
		}

		Prepare();

		if (m_pkParentSystem && m_pkParentSystem->HasTightBoundingBox())
		{
			ResetBounds();
		}

		EmitParticles(timeElapsed);

		PreProcessParticles(timeElapsed);

		ProcessParticles(timeElapsed);

		PostProcessParticles(timeElapsed);

		latestPosition = GetDerivedPosition();
	}
	
	void DiParticleElement::NotifyEmissionChange(void)
	{
		if (m_bSuppressNotifyEmissionChange)
		{
			return;
		}

		if (GetParentSystem())
		{
			GetParentSystem()->NotifyEmissionChange();
		}
		else
		{
			MarkForEmission();
		}
	}
	
	void DiParticleElement::NotifyAttached(DiNode* parent)
	{
		if (m_pkRenderer && m_pkRenderer->IsRendererInitialised())
		{
			m_pkRenderer->NotifyAttached(parent);
		}
	}
	
	void DiParticleElement::NotifyCurrentCamera(DiCamera* camera)
	{
		if (m_pkRenderer && m_pkRenderer->IsRendererInitialised())
		{
			if (m_pkRenderer->IsSorted())
			{
				SortVisualParticles(camera);
			}

			m_pkRenderer->NotifyCurrentCamera(camera);
		}
	}
	
	DiParticleElement::DirectionSorter::DirectionSorter(const DiVec3& direction) : sortDirection(direction)
	{
	}
	
	float DiParticleElement::DirectionSorter::operator()(DiParticle* p) const
	{
		return sortDirection.dotProduct(p->position);
	}
	
	DiParticleElement::DistanceSorter::DistanceSorter(const DiVec3& position) : sortPosition(position)
	{
	}
	
	float DiParticleElement::DistanceSorter::operator()(DiParticle* p) const
	{
		return - (sortPosition - p->position).squaredLength();
	}
	
	void DiParticleElement::SortVisualParticles(DiCamera* camera)
	{
		if (m_pkRenderer)
        {
			DiSortMode sortMode = m_pkRenderer->GetSortMode();
			if (sortMode == SM_DIRECTION)
			{
				DiVec3 cameraDirection = camera->GetDerivedDirection();
				m_kRadixSorter.Sort(m_kPool.GetVisualParticlesList(), DirectionSorter(- cameraDirection));
			}
			else if (sortMode == SM_DISTANCE)
			{
				DiVec3 cameraPosition = camera->GetDerivedPosition();
				m_kRadixSorter.Sort(m_kPool.GetVisualParticlesList(), DistanceSorter(cameraPosition));
			}
		}
	}
	
	void DiParticleElement::NotifyParticleResized(void)
	{
		if (m_pkRenderer)
		{
			m_pkRenderer->NotifyParticleResized();
		}
	}
	
	void DiParticleElement::NotifyStart (void)
	{
        latestPosition = GetDerivedPosition();

		m_pkRenderer->NotifyStart();

		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission())
				{
					(*affectorIt)->NotifyStart();
				}
			}
		}

		NotifyStartPooledComponents();

		SetEnabled(m_bOriginalEnabled);
	}
	
	void DiParticleElement::NotifyStartPooledComponents(void)
	{
		if (m_kPool.IsEmpty())
		{
			return;
		}

		DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
		while (!m_kPool.End())
		{
			particle = static_cast<DiParticle*>(m_kPool.GetNext());
		}
	}
	
	void DiParticleElement::NotifyStop (void)
	{
		m_pkRenderer->NotifyStop();

		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission())
				{
					(*affectorIt)->NotifyStop();
				}
			}
		}

		NotifyStopPooledComponents();

		InitAllParticlesForExpiration();

		ResetBounds();
	}
	
	void DiParticleElement::NotifyStopPooledComponents(void)
	{
		if (m_kPool.IsEmpty())
		{
			return;
		}

		DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
		while (!m_kPool.End())
		{
			particle = static_cast<DiParticle*>(m_kPool.GetNext());
		}
	}
	
	void DiParticleElement::NotifyPause (void)
	{
		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission())
				{
					(*affectorIt)->NotifyPause();
				}
			}
		}

		NotifyPausePooledComponents();
	}
	
	void DiParticleElement::NotifyPausePooledComponents(void)
	{
		if (m_kPool.IsEmpty())
		{
			return;
		}

		DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
		while (!m_kPool.End())
		{
			particle = static_cast<DiParticle*>(m_kPool.GetNext());
		}
	}
	
	void DiParticleElement::NotifyResume (void)
	{
		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission())
				{
					(*affectorIt)->NotifyResume();
				}
			}
		}

		NotifyResumePooledComponents();
	}
	
	void DiParticleElement::NotifyResumePooledComponents(void)
	{
		if (m_kPool.IsEmpty())
		{
			return;
		}

		DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
		while (!m_kPool.End())
		{
			particle = static_cast<DiParticle*>(m_kPool.GetNext());
		}
	}
	
	void DiParticleElement::ProcessParticles(float timeElapsed)
	{
		if (m_kPool.IsEmpty())
		{
			return;
		}

		DiParticle* particle = m_kPool.GetFirst();
		bool firstParticle = true; 
		bool firstActiveParticle = true; 
		while (!m_kPool.End())
		{
			if (particle)
			{
				if (!IsExpired(particle, timeElapsed))
				{
					ProcessParticleSelf(particle, timeElapsed, firstActiveParticle);
					ProcessControllers(particle, timeElapsed, firstActiveParticle);
					ProcessRenderer(particle, timeElapsed, firstActiveParticle);

					firstActiveParticle = false;

					particle->latestPosition = particle->position;

					ProcessMotion(particle, timeElapsed, firstActiveParticle);
				}
				else
				{
					InitParticleForExpiration(particle, timeElapsed);

					m_kPool.LockLatestParticle();
				}

				if (particle->HasEventFlags(PEF_EXPIRED))
				{
					particle->SetEventFlags(0);
					particle->AddEventFlags(PEF_EXPIRED);
				}
				else
				{
					particle->SetEventFlags(0);
				}

				particle->timeToLive -= timeElapsed;
			}

			firstParticle = false;
			particle = m_kPool.GetNext();
		}
	}

	void DiParticleElement::ProcessControllers(DiParticle* particle, float timeElapsed, bool firstParticle)
	{
		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission() && (*affectorIt)->IsEnabled())
				{
					(*affectorIt)->ProcessParticle(this, particle, timeElapsed, firstParticle);
				}
			}
		}
	}
	
	void DiParticleElement::PreProcessParticles(float timeElapsed)
	{
		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission() && (*affectorIt)->IsEnabled())
				{
					(*affectorIt)->PreProcessParticles(this, timeElapsed);
				}
			}
		}
		
	}	
	
	void DiParticleElement::PostProcessParticles(float timeElapsed)
	{
		m_bUpdateWorldAABB = false;
		if (m_bHasExtents)
		{
			m_kWorldAABB.SetExtents(m_kMinWorldExtend, m_kMaxWorldExtend);
		}

		if (!m_kControllers.empty())
		{
			ParticleAffectorIterator affectorIt;
			ParticleAffectorIterator affectorItEnd = m_kControllers.end();
			for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
			{
				if (!(*affectorIt)->IsMarkedForEmission() && (*affectorIt)->IsEnabled())
				{
					(*affectorIt)->PostProcessParticles(this, timeElapsed);
				}
			}
		}
	}
	
	void DiParticleElement::ProcessRenderer(DiParticle* particle, float timeElapsed, bool firstParticle)
	{
		if (!m_pkRenderer)
		{
			return;
		}

		m_pkRenderer->ProcessParticle(this, particle, timeElapsed, firstParticle);
	}
	
	void DiParticleElement::ProcessParticleSelf(DiParticle* particle, float timeElapsed, bool firstParticle)
	{
		particle->Process(this, timeElapsed);

		if (m_bUpdateWorldAABB && particle->particleType == DiParticle::PT_VISUAL)
		{
			DiVisualParticle* p = static_cast<DiVisualParticle*>(particle);
			float maxDim = 0;
			DiVec3 padding = DiVec3::ZERO;
			if (p->ownDimensions)
			{
				maxDim = DiMath::Max(p->width, p->height);
				maxDim = DiMath::Max(maxDim, p->depth);
			}
			else
			{
				maxDim = DiMath::Max(m_fDefaultWidth, m_fDefaultHeight);
				maxDim = DiMath::Max(maxDim, m_fDefaultDepth);
			}

			padding = HALFSCALE * maxDim;
			if (m_bHasExtents)
			{
				m_kMinWorldExtend.makeFloor(p->position - padding);
				m_kMaxWorldExtend.makeCeil(p->position + padding);
			}
			else
			{
				m_kMinWorldExtend = p->position - padding;
				m_kMaxWorldExtend = p->position + padding;
				m_bHasExtents = true;
			}
		}
	}
	
	void DiParticleElement::InitParticleForExpiration(DiParticle* particle, float timeElapsed)
	{
		particle->InitForExpiration(this, timeElapsed);

		if (!m_kElementListenerList.empty())
		{
			ElementListenerIterator it;
			ElementListenerIterator itEnd = m_kElementListenerList.end();
			for (it = m_kElementListenerList.begin(); it != itEnd; ++it)
			{
				(*it)->ParticleExpired(this, particle);
			}
		}
	}
	
	bool DiParticleElement::IsExpired(DiParticle* particle, float timeElapsed)
	{
		bool expired = particle->timeToLive < timeElapsed;
		if (expired)
		{
			particle->AddEventFlags(DiParticle::PEF_EXPIRED);
		}

		return expired;
	}
	
	void DiParticleElement::EmitParticles(float timeElapsed)
	{
		if (!m_bEnabled)
		{
			return;
		}

		if (m_kEmitters.empty())
		{
			return;
		}

		ParticleEmitterIterator itEmitter;
		ParticleEmitterIterator itEmitterBegin = m_kEmitters.begin();
		ParticleEmitterIterator itEmitterEnd = m_kEmitters.end();
		for (itEmitter = itEmitterBegin; itEmitter != itEmitterEnd; ++itEmitter)
		{
			ExecuteEmitParticles(*itEmitter, (*itEmitter)->CalculateRequestedParticles(timeElapsed), timeElapsed);
		}
	}
	
	void DiParticleElement::ForceEmission(DiParticleEmitter* emitter, unsigned requested)
	{
		if (!m_bEnabled)
		{
			return;
		}

		ExecuteEmitParticles(emitter, requested, 0);
	}
	
	void DiParticleElement::ForceEmission(const DiParticle::ParticleType particleType, unsigned requested)
	{
		if (!m_bEnabled)
		{
			return;
		}

		if (m_kEmitters.empty())
		{
			return;
		}

		ParticleEmitterIterator emitterIt;
		ParticleEmitterIterator emitterItEnd = m_kEmitters.end();
		for (emitterIt = m_kEmitters.begin(); emitterIt != emitterItEnd; ++emitterIt)
		{
			if ((*emitterIt)->GetEmitsType() == particleType)
			{
				ExecuteEmitParticles(*emitterIt, requested, 0);
				return;
			}
		}
	}
	
	void DiParticleElement::ExecuteEmitParticles(DiParticleEmitter* emitter, unsigned requested, float timeElapsed)
	{
		if (!(m_bEnabled && emitter->IsEnabled()))
		{
			return;
		}

		float timePoint = 0.0f;
		float timeInc = timeElapsed / requested;
		for (unsigned int j = 0; j < requested; ++j)
		{
			DiParticle* particle = m_kPool.ReleaseParticle(emitter->GetEmitsType(), emitter->GetEmitsName());

			if (!particle)
			{
				return;
			}

			particle->InitForEmission();

			emitter->InitParticleForEmission(particle);

			particle->direction = (GetParentSystem()->GetDerivedOrientation() * particle->direction);
			particle->originalDirection = (GetParentSystem()->GetDerivedOrientation() * particle->originalDirection);

			if (!m_kControllers.empty())
			{
				ParticleAffectorIterator affectorIt;
				ParticleAffectorIterator affectorItEnd = m_kControllers.end();
				for (affectorIt = m_kControllers.begin(); affectorIt != affectorItEnd; ++affectorIt)
				{
					if ((*affectorIt)->IsEnabled())
					{
						(*affectorIt)->InitParticleForEmission(particle);
					}
				}
			}

			InitParticleForEmission(particle);

			particle->position += (particle->direction * m_fParticleSystemScaleVelocity * timePoint);

			timePoint += timeInc;
		}
	}
	
	const DiVec3& DiParticleElement::GetDerivedPosition(void)
	{
		if (m_bMarkedForEmission)
		{
			m_kDerivedPosition = position;
		}
		else
		{
			if (m_pkParentSystem)
			{
				m_kDerivedPosition = m_pkParentSystem->GetDerivedPosition() + GetParentSystem()->GetDerivedOrientation() * (m_kParticleSystemScale * position);
			}
		}
		return m_kDerivedPosition;
	}
	
	void DiParticleElement::ProcessMotion(DiParticle* particle, float timeElapsed, bool firstParticle)
	{
		if (particle->IsFreezed())
		{
			return;
		}

		if (!particle->parentEmitter->MakeParticleLocal(particle))
		{
			if (!MakeParticleLocal(particle))
			{
				GetParentSystem()->MakeParticleLocal(particle);
			}
		}

		if (GetParentSystem()->IsKeepLocal() || m_bKeepLocal)
		{
			if (!m_pkRenderer->autoRotate)
			{
				GetParentSystem()->RotationOffset(particle->position);
			}
		}

		if (particle->HasEventFlags(DiParticle::PEF_EMITTED))
		{
			return;
		}

		if (m_bMaxVelocitySet && particle->CalculateVelocity() > m_fMaxVelocity)
		{
			particle->direction *= (m_fMaxVelocity / particle->direction.length());
		}

		particle->position += (particle->direction * m_fParticleSystemScaleVelocity * timeElapsed);
	}
	
	size_t DiParticleElement::GetNumberOfEmittedParticles(void)
	{
		size_t total = m_kPool.GetSize();
		return total;
	}
	
	size_t DiParticleElement::GetNumberOfEmittedParticles(DiParticle::ParticleType particleType)
	{
		size_t total = m_kPool.GetSize(particleType);
		return total;
	}
	
	void DiParticleElement::InitAllParticlesForExpiration(void)
	{
		if (!m_kPool.IsEmpty())
		{
			DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
			while (!m_kPool.End())
			{
				if (particle)
				{
					InitParticleForExpiration(particle, 0);
				}
			
				particle = static_cast<DiParticle*>(m_kPool.GetNext());
			}
		}

		m_kPool.LockAllParticles();
	}
	
	void DiParticleElement::LockAllParticles(void)
	{
		m_kPool.LockAllParticles();
	}
	
	void DiParticleElement::InitVisualDataInPool(void)
	{
		m_kPool.ReleaseAllParticles();
		DiParticle* particle = static_cast<DiParticle*>(m_kPool.GetFirst());
		while (!m_kPool.End())
		{
			if (particle)
			{
				particle->visualData = 0;
			}
			particle = static_cast<DiParticle*>(m_kPool.GetNext());
		}
		m_kPool.LockAllParticles();
	}
	
	DiParticlePool* DiParticleElement::GetParticlePool(void)
	{
		return &m_kPool;
	}
	
	bool DiParticleElement::IsKeepLocal(void) const
	{
		return m_bKeepLocal;
	}
	
	void DiParticleElement::SetKeepLocal(bool keepLocal)
	{
		m_bKeepLocal = keepLocal;
	}
	
	bool DiParticleElement::MakeParticleLocal(DiParticle* particle)
	{
		if (!particle)
		{
			return true;
		}

		if (!m_bKeepLocal || HasEventFlags(DiParticle::PEF_EXPIRED))
			return false;

		DiVec3 diff = GetDerivedPosition() - latestPosition; // diff of the technique
		particle->position += diff;
		return true;
	}
	
	float DiParticleElement::GetMaxVelocity(void) const
	{
		return m_fMaxVelocity;
	}
	
	void DiParticleElement::SetMaxVelocity(float maxVelocity)
	{
		m_fMaxVelocity = maxVelocity;
		m_bMaxVelocitySet = true;
	}
	
	void DiParticleElement::AddElementListener (DiElementListener* elementListener)
	{
		m_kElementListenerList.push_back(elementListener);
	}
	
	void DiParticleElement::RemoveElementListener (DiElementListener* elementListener)
	{
		MT_ASSERT(elementListener && "DiElementListener is null!");
		 ElementListenerList::iterator it;
		 ElementListenerList::iterator itEnd = m_kElementListenerList.end();
		for (it = m_kElementListenerList.begin(); it != itEnd; ++it)
		{
			if (*it == elementListener)
			{
				m_kElementListenerList.erase(it);
				break;
			}
		}
	}
	
	float DiParticleElement::GetParticleSystemScaleVelocity(void) const
	{
		return m_fParticleSystemScaleVelocity;
	}
	
	void DiParticleElement::PushElementEvent(EventType eventType)
	{
		ParticleUniverseEvent evt;
		evt.eventType = eventType;
		evt.componentType = CT_TECHNIQUE;
		evt.componentName = GetName();
		evt.technique = this;
		evt.emitter = 0;
		PushEvent(evt);
	}
	
	void DiParticleElement::PushEvent(ParticleUniverseEvent& particleUniverseEvent)
	{
		if (m_pkParentSystem)
		{
			m_pkParentSystem->PushEvent(particleUniverseEvent);
		}
	}
	
	void DiParticleElement::CopyTo (DiParticleElement* technique)
	{
		technique->m_pkParentSystem = m_pkParentSystem;

		technique->DestroyAllEmitters();
		technique->DestroyAllControllers();
		technique->DestroyRenderer();

		DiParticle::CopyTo(technique);

		technique->m_kName = m_kName;
		technique->m_bVisualParticlePoolIncreased = false;
		technique->m_uiVisualParticleQuota = m_uiVisualParticleQuota;
		technique->m_uiEmittedEmitterQuota = m_uiEmittedEmitterQuota;
		technique->m_uiEmittedTechniqueQuota = m_uiEmittedTechniqueQuota;
		technique->m_uiEmittedAffectorQuota = m_uiEmittedAffectorQuota;
		technique->m_uiEmittedSystemQuota = m_uiEmittedSystemQuota;
		technique->m_sMaterialName = m_sMaterialName;
		technique->m_fDefaultWidth = m_fDefaultWidth;
		technique->m_fDefaultHeight = m_fDefaultHeight;
		technique->m_fDefaultDepth = m_fDefaultDepth;
		technique->m_usLodIndex = m_usLodIndex;
		technique->m_bKeepLocal = m_bKeepLocal;
		technique->m_fMaxVelocity = m_fMaxVelocity;
		technique->m_bMaxVelocitySet = m_bMaxVelocitySet;
		technique->m_kParticleSystemScale = m_kParticleSystemScale;

		DiParticleRenderer* clonedRenderer = GetParentSystem()->GetEffectManager()->CloneRenderer(m_pkRenderer);
		technique->SetRenderer(clonedRenderer);

		DiParticleEmitter* clonedEmitter = 0;
		ParticleEmitterIterator itEmitter;
		ParticleEmitterIterator itEmitterEnd = m_kEmitters.end();
		for (itEmitter = m_kEmitters.begin(); itEmitter != itEmitterEnd; ++itEmitter)
		{
			clonedEmitter = GetParentSystem()->GetEffectManager()->CloneEmitter(*itEmitter);
			technique->AddEmitter(clonedEmitter);
		}

		DiParticleController* clonedAffector = 0;
		ParticleAffectorIterator itAffector;
		ParticleAffectorIterator itAffectorEnd = m_kControllers.end();
		for (itAffector = m_kControllers.begin(); itAffector != itAffectorEnd; ++itAffector)
		{
			clonedAffector = GetParentSystem()->GetEffectManager()->CloneController(*itAffector);
			technique->AddControlle(clonedAffector);
		}
	}
}

