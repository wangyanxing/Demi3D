
/**********************************************************************
This source file is a part of Demi3D
   __  ___  __  __  __
  |  \|_ |\/||   _)|  \ 
  |__/|__|  ||  __)|__/ 

Copyright (c) 2013-2014 Demi team
https://github.com/wangyanxing/Demi3D

Released under the MIT License
https://github.com/wangyanxing/Demi3D/blob/master/License.txt
***********************************************************************/

/****************************************************
  This module was originally from Particle Universe
  Repo: https://github.com/scrawl/particleuniverse
  License: MIT 
****************************************************/

#ifndef ParticlePoolBase_h__
#define ParticlePoolBase_h__

#include "FxPrerequisites.h"

namespace Demi
{
	template <typename T>
	class DEMI_FX_API DiParticlePoolBase
	{
	public:
		typedef std::list<T*> PoolList;
		typedef typename PoolList::iterator PoolIterator;
		PoolIterator mPoolIterator;

		
		DiParticlePoolBase (bool managed = false) : m_bManaged(managed)
		{
			if (m_bManaged)
			{
			}
		}
		
		virtual ~DiParticlePoolBase (void)
		{
			if (m_bManaged)
			{
			}
		}
		
		inline bool			IsEmpty(void)
		{
			return m_kReleased.empty();
		}
		
		inline size_t		GetSize(void)
		{
			return m_kReleased.size();
		}
		
		inline void			ResetIterator (void)
		{
			mPoolIterator = m_kReleased.begin();
		}
		
		inline T*			GetFirst (void)
		{
			ResetIterator();
			if (End())
			{
				return 0;
			}

			return *mPoolIterator;
		}
		
		inline T*			GetNext (void)
		{
			if (End())
			{
				return 0;
			}

			mPoolIterator++;
			if (End())
			{
				return 0;
			}

			return *mPoolIterator;
		}
		
		inline bool			End (void)
		{
			return mPoolIterator == m_kReleased.end();
		}
		
		inline void			Clear (void)
		{
			m_kLocked.clear();
			m_kReleased.clear();
		}
	
		inline void			AddElement (T* element)
		{
			if (m_bManaged)
			{
                DI_WARNING("Managing, cannot add element");
                return;
			}

			m_kLocked.push_back(element);
		}
		
		inline T*			ReleaseElement (void)
		{
			if (m_kLocked.empty())
			{
				return 0;
			}

			T* t = m_kLocked.front();
			m_kReleased.splice(m_kReleased.end(), m_kLocked, m_kLocked.begin());
			return t;
		}
		
		inline void			ReleaseAllElements (void)
		{
			m_kReleased.splice(m_kReleased.end(), m_kLocked);
			ResetIterator();
		}
		
		inline void			LockLatestElement (void)
		{
			m_kLocked.push_back(*mPoolIterator);
			mPoolIterator = m_kReleased.erase(mPoolIterator);
			if (mPoolIterator != m_kReleased.begin() && mPoolIterator != m_kReleased.end())
			{
				mPoolIterator--;
			}
		}
		
		inline void			LockAllElements (void)
		{
			m_kLocked.splice(m_kLocked.end(), m_kReleased);
			ResetIterator();
		}

		inline PoolList&	GetActiveElementsList(void)
		{
			return m_kReleased;
		}

	protected:
		bool		m_bManaged;

		PoolList	m_kReleased;

		PoolList	m_kLocked;
	};
}

#endif // ParticlePoolBase_h__
